package constant

const DEBUG = false

const FOOD_ID_STOCK = "food:id:stock"
const INIT_TIME = "INIT_TIME"
const TIMESTAMP = "timestamp"
const FOOD_LAST_UPDATE_TIME = "food:last_update_time"

const TIME_BASE = 10000000
