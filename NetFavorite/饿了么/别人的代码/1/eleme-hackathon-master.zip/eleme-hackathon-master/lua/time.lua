-- delete this file if you don't need redis time
return redis.call('time')