package me.ele.panicbuying.utils;

/**
 * Created by xczhang on 15/11/27 下午8:03.
 */
public class Order {
    public String cart_id;
}
