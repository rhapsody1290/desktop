package me.ele.panicbuying.utils;

/**
 * Created by xczhang on 15/11/26 下午5:22.
 */
public class FoodPost {
    public int food_id;
    public int count;
}
