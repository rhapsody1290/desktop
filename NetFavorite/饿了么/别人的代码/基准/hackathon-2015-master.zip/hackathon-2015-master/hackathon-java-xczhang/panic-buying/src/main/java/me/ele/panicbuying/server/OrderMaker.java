package me.ele.panicbuying.server;

/**
 * Created by xczhang on 15/11/12 下午5:08.
 */
public class OrderMaker {
}
