package me.ele.panicbuying.utils;

/**
 * Created by xczhang on 15/11/27 下午7:58.
 */
public class User {
    public String username;
    public String password;

}
