# Hackathon 2015 Java Implementation

Java 基准实现之一

Sample Benchmark Stats

```
Stats
Concurrency level:         1000
Time taken for tests:      14750ms
Complete requests:         302967
Failed requests:           0
Complete orders:           50000
Failed orders:             0
Time per request:          48.14ms
Time per order:            291.72ms
Request per second:        25465 (max)  15906 (min)  20220(mean)
Order per second:          4233 (max)  2722 (min)  3343 (mean)

Percentage of orders made within a certain time (ms)
50%     248
75%     369
80%     407
90%     529
95%     655
98%     811
100%    1977
```
PS: 偷懒没用lua 感兴趣的同学可以加下试试
