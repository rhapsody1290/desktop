# Hackathon 2015 Python Implementation

Python 基准实现

Sample Benchmark Stats

```
Stats
Concurrency level:         1000
Time taken for tests:      18196ms
Complete requests:         302126
Failed requests:           0
Complete orders:           50000
Failed orders:             0
Time per request:          59.36ms
Time per order:            358.66ms
Request per second:        19048 (max)  14235 (min)  16561(mean)
Order per second:          3186 (max)  2324 (min)  2745 (mean)

Percentage of orders made within a certain time (ms)
50%     156
75%     612
80%     673
90%     796
95%     907
98%     1781
100%    3225
```
