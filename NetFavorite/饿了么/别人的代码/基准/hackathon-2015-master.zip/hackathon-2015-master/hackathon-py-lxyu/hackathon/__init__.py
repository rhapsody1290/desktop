# coding: utf-8

import meinheld
meinheld.server.set_access_logger(None)
meinheld.set_keepalive(30)
