# Hackathon 2015 Go Implementation

Go 基准实现

Sample Benchmark Stats

```
Stats
Concurrency level:         1000
Time taken for tests:      10199ms
Complete requests:         303308
Failed requests:           79
Complete orders:           49921
Failed orders:             79
Time per request:          33.20ms
Time per order:            201.72ms
Request per second:        30385 (max)  29649 (min)  29691(mean)
Order per second:          5059 (max)  4843 (min)  4899 (mean)

Percentage of orders made within a certain time (ms)
50%     194
75%     232
80%     242
90%     271
95%     301
98%     350
100%    1339
```
