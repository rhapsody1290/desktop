# Hackathon 2015 Java Implementation

Java 基准实现之一

```
Stats
Concurrency level:         1000
Time taken for tests:      11343ms
Complete requests:         303324
Failed requests:           0
Complete orders:           50000
Failed orders:             0
Time per request:          37.03ms
Time per order:            224.67ms
Request per second:        29765 (max)  25640 (min)  26557(mean)
Order per second:          4960 (max)  4271 (min)  4393 (mean)

Percentage of orders made within a certain time (ms)
50%     190
75%     254
80%     279
90%     398
95%     527
98%     655
100%    1646
```
