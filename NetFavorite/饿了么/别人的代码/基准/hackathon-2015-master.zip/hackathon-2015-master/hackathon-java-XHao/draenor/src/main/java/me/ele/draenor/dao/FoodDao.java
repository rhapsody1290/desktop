package me.ele.draenor.dao;

import me.ele.draenor.http.Response;

public interface FoodDao {

	public Response queryFoodStock();

}
