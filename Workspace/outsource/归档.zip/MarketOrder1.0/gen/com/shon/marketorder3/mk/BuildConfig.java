/** Automatically generated file. DO NOT MODIFY */
package com.shon.marketorder3.mk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}