package com.shon.marketorder3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import com.shon.marketorder3.mk.R;

public class SearchList extends Activity {
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        
        setContentView(R.layout.searchlist); 
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
		
        
        Button buttonOrderList = (Button)findViewById(R.id.buttonOrderList);
        buttonOrderList.setOnClickListener(buttonOnClickListener);
        Button buttonPickList = (Button)findViewById(R.id.buttonPickList);
        buttonPickList.setOnClickListener(buttonOnClickListener);
        Button buttonOrderIssue = (Button)findViewById(R.id.buttonOrderIssue);
        buttonOrderIssue.setOnClickListener(buttonOnClickListener);
        Button buttonOrderPay = (Button)findViewById(R.id.buttonOrderPay);
        buttonOrderPay.setOnClickListener(buttonOnClickListener);
        Button buttonOrderTrace = (Button)findViewById(R.id.buttonOrderTrace);
        buttonOrderTrace.setOnClickListener(buttonOnClickListener);
        Button buttonRebList = (Button)findViewById(R.id.buttonRebList);
        buttonRebList.setOnClickListener(buttonOnClickListener);
        Button buttonPlanList = (Button)findViewById(R.id.buttonRebList);
        buttonPlanList.setOnClickListener(buttonOnClickListener);

		if (user != null)
		{
//			if (!user.author_ORDLIST)
//				buttonOrderList.setVisibility(View.GONE);
//			if (!user.author_PICKLIST)
//				buttonPickList.setVisibility(View.GONE);
//			if (!user.author_ORDISSUE)
//				buttonOrderIssue.setVisibility(View.GONE);
//			if (!user.author_ORDPAY)
//				buttonOrderPay.setVisibility(View.GONE);
//			if (!user.author_ORDTRACE)
//				buttonOrderTrace.setVisibility(View.GONE);
//			if (!user.author_REBLIST)
//				buttonRebList.setVisibility(View.GONE);
//			if (!user.author_PLANLIST)
//				buttonPlanList.setVisibility(View.GONE);
		}

        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				SearchList.this.setResult(FunctionList.MenuResult);
				SearchList.this.finish();
			}
        });
    }
    
    private OnClickListener buttonOnClickListener = new OnClickListener()
    {

		@Override
		public void onClick(View v) {
			String searchType = "";
			switch (v.getId())
			{
			case R.id.buttonOrderList:
				searchType = "ORDERLIST";
				break;
			case R.id.buttonPickList:
				searchType = "PICKLIST";
				break;
			case R.id.buttonOrderIssue:
				searchType = "ORDERISSUE";
				break;
			case R.id.buttonOrderPay:
				searchType = "ORDERPAY";
				break;
			case R.id.buttonOrderTrace:
				searchType = "ORDERTRACE";
				break;
			case R.id.buttonRebList:
				searchType = "REBATELIST";
				break;
//			case R.id.buttonPlanList:
//				searchType = "PLANLIST";
//				break;
			}
        	Intent SearchListIntent = new Intent(SearchList.this, SearchView.class);
        	SearchListIntent.putExtra(SearchList.this.getString(R.string.string_key_searchType), searchType);
        	SearchList.this.startActivityForResult(SearchListIntent, 0);
		}
    	
    };

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == FunctionList.MenuResult)
		{
			SearchList.this.setResult(FunctionList.MenuResult);
			SearchList.this.finish();
		}
		else if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString("result");


			Intent returnIntent = new Intent();
			Bundle returnBundle = new Bundle();
			returnBundle.putString("result", returnResult);
			returnIntent.putExtras(returnBundle);
			SearchList.this.setResult(RESULT_OK, returnIntent);
			SearchList.this.finish();
		}
	}
}
