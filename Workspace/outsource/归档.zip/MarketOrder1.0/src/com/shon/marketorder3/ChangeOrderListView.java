package com.shon.marketorder3;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import com.shon.marketorder3.BaseListView.ItemClickEvent;
import com.shon.marketorder3.TableAdapter.TableCell;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.TableAdapter.TableRowView;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

public class ChangeOrderListView extends Activity {
	
	private ListView listView;
	private boolean isEnableEdit = false;
//	public List<TableRow> table;
	@Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        
        setContentView(R.layout.baselistview);  
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
		
		isEnableEdit = this.getIntent().getBooleanExtra(this.getString(R.string.string_key_isEnableEdit), true);
		
		ListView lvTitle = (ListView)this.findViewById(R.id.TitleListView);
    	ArrayList<TableRow>tableTitle = new ArrayList<TableRow>(); 
        TableCell[] cells = new TableCell[12];  
        cells[0] = new TableCell("��Ʒ����",128,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[1] = new TableCell("�� ��",42,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[2] = new TableCell("��������",72,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
        cells[3] = new TableCell("��ש��(Ƭ)",104,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
        cells[4] = new TableCell("�ӹ���(Ƭ)",104,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
        cells[5] = new TableCell("�ܽ��",130,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
        cells[6] = new TableCell("��;",240,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[7] = new TableCell("��װ��",90,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
        cells[8] = new TableCell("��ע",420,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);  
        cells[9] = new TableCell("�Ƿ���Ʒ",130,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);  
        cells[10] = new TableCell("��Ʒ����",260,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[11] = new TableCell("����(����)",175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
    	
        tableTitle.add(new TableRow(cells)); 
		
        TableAdapter tableTitleAdapter = new TableAdapter(ChangeOrderListView.this, tableTitle, isEnableEdit, true);
        lvTitle.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        lvTitle.setAdapter(tableTitleAdapter); 
		
        listView = (ListView) this.findViewById(R.id.BaseListView);  
        
        setDate();
	    //���ӵ���¼� 
	    listView.setOnItemClickListener(new ListViewItemClickEvent());
	    listView.setOnItemLongClickListener(new ListViewItemLongClickEvent());

        Button buttonDelete = (Button)findViewById(R.id.buttonDelete);
		if (ChangeOrderCustomerInfo.listStatus.contentEquals("������"))
			buttonDelete.setVisibility(View.GONE);
		else
			buttonDelete.setVisibility(View.VISIBLE);
        buttonDelete.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View arg0) {

	        	PublicMethod.displayToast(ChangeOrderListView.this, "ɾ�����гɹ�");
	        	for (int i = 0; i < ChangeOrderCustomerInfo.orderTable.size(); )
				{
					TableRow tableRow = ChangeOrderCustomerInfo.orderTable.get(i);
					
					if (tableRow.isChecked)
					{
						ChangeOrderCustomerInfo.orderTable.remove(i);
						continue;
					}
					
					i++;
				}
//	        	Inventory.saveShoppingCartTable(ChangeOrderListView.this);
				setDate();
			}
			
        	
        });  

		Button buttonBack = (Button)findViewById(R.id.buttonBack);
		buttonBack.setVisibility(View.VISIBLE);
		buttonBack.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) {
				ChangeOrderListView.this.finish();
			}
        });
		
        Button button = (Button)findViewById(R.id.buttonGotoShoppingCart);
		if (ChangeOrderCustomerInfo.listStatus.contentEquals("������"))
			button.setVisibility(View.GONE);
		else
			button.setVisibility(View.VISIBLE);
        button.setText("����");
        button.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View arg0) {
    			Intent mIntent = new Intent(ChangeOrderListView.this,Inventory.class);
    			mIntent.putExtra("codition", "addOrderList");
    			mIntent.putExtra(ChangeOrderListView.this.getString(R.string.string_key_storage), "OWNER");
		        startActivityForResult(mIntent, EnterConditionView.EnterConditionResult);
				
			}
        	
        });  

//		if (user != null)
//		{
//			if (!user.author_ORDCRT)
//				button.setVisibility(View.GONE);
//		}


        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				ChangeOrderListView.this.setResult(FunctionList.MenuResult);
				ChangeOrderListView.this.finish();
			}
        });
    }  
	
	public void setDate()
	{
//        ["��Ʒ����","��Ʒ����","�� ��","�� ��","�� ��","WDR��","��װ��","Ƭ��","����"]
		TableAdapter tableAdapter = new TableAdapter(ChangeOrderListView.this,
				ChangeOrderCustomerInfo.orderTable, isEnableEdit, false);
	    listView.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
	    listView.setAdapter(tableAdapter);  
	}

    class ListViewItemClickEvent implements AdapterView.OnItemClickListener {  
        @Override  
        public void onItemClick(AdapterView<?> arg0, View tableRowView, int index,  
                long arg3) {  
//        	int count = index + 1;
//        	if (index == 0)
//        		count = ChangeOrderCustomerInfo.orderTable.size()+1;
//        	
//        	for (int i = index; i < count; i++)
//        	{
//        		if (i != 0)
//	        	{	
//        			TableRow selectTableRow = ChangeOrderCustomerInfo.orderTable.get(i-1);
//        			selectTableRow.isChecked = !selectTableRow.isChecked;
//	        	}
//        		
//	        	TableRowView selectTableRowView = (TableRowView)listView.getItemAtPosition(i);//tableRowView;
//				selectTableRowView.setChecked(!selectTableRowView.getChecked());
//        	}
        }  
    }  

    class ListViewItemLongClickEvent implements AdapterView.OnItemLongClickListener {

		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View tableRowView,
				int index, long arg3) {
//			if (!isEnableEdit)
//				return false;
				
        			TableRow selectTableRow = ChangeOrderCustomerInfo.orderTable.get(index);
        			Intent mIntent = new Intent(ChangeOrderListView.this,EnterConditionView.class);
        			mIntent.putExtra("codition", "orderChange");
        			mIntent.putExtra("coditionId", index);
        			mIntent.putExtra(ChangeOrderListView.this.getString(R.string.string_key_isEnableEdit), isEnableEdit);
    		        EnterConditionView.selectTableRow = selectTableRow;
    		          
    		        startActivityForResult(mIntent, EnterConditionView.EnterConditionResult);
        	return false;
		}
    }  


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		//����ɨ�������ڽ�������ʾ��
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString("result");


			Intent returnIntent = new Intent();
			Bundle returnBundle = new Bundle();
			returnBundle.putString("result", returnResult);
			returnIntent.putExtras(returnBundle);
			ChangeOrderListView.this.setResult(RESULT_OK, returnIntent);
			ChangeOrderListView.this.finish();
		}
		else if (resultCode == EnterConditionView.ChangeConditionResult)
			setDate();

		else if(resultCode == FunctionList.MenuResult)
		{
			ChangeOrderListView.this.setResult(FunctionList.MenuResult);
			ChangeOrderListView.this.finish();
		}
	}

}
