package com.shon.marketorder3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.shon.marketorder3.TableAdapter.TableCell;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class ChangeOrderCustomerInfo extends Activity {
	private String returnResult = "";
	public static String listStatus = "ʵ��";
	private String listnumber = "";
	private boolean isEnableEdit = false;
	public static ArrayList<TableRow> orderTable = new ArrayList<TableRow>();

	final String strJsonKey_type = "type";
	final String strJsonKey_title = "title";
	final String strJsonKey_mandatory = "mandatory";
	final String strJsonKey_isOnlyRead = "isOnlyRead";
	final String strJsonKey_defaultvalue = "defaultvalue";
	final String strJsonKey_isNotSubmit = "isNotSubmit";
	final String strJsonKey_selectItem = "selectItem";
	final String strJsonKey_condition = "condition";

	final String strType_text = "text";
	final String strType_date = "date";
	final String strType_radio = "radio";
	
    Spinner spinner;  
    ArrayAdapter<String> adapter; 
	EditText editTextCustomerName;
	EditText editTextCustomerPhone;
	EditText editTextCustomerAddress;
	DatePicker datePickerPlanDate;
	EditText editTextComment;
	EditText editTextCity;
	EditText editTextCounty;
	EditText editTextLinkman;
	EditText editTextLinkmanPhone;
	EditText editTextFirstCode;
	EditText editTextFirstLinkman;
	EditText editTextParticipateActivity;
	EditText editTextDecorateArea;
	EditText editTextPropertyClassification;
	EditText editTextDecorateExperience;
	EditText editTextUseCount;
	EditText editTextGender;
	EditText editTextAgeRange;
	EditText editTextJob;
	EditText editTextDecider;
	EditText editTextVillage;
	//��ѡ��ť����һ�飩
	RadioButton radioButtonActual;
	RadioButton radioButtonPurpose;

    ConditionRadio CommunityName;
    private LinearLayout mAddconditionLinearLayout;
	
	@Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        
        setContentView(R.layout.customerinfo);  
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);

		spinner = (Spinner) findViewById(R.id.SpinnerOrderType); 
		spinner.setClickable(false);
        
		editTextCustomerName = (EditText)findViewById(R.id.editTextCustomerName);
		editTextCustomerPhone = (EditText)findViewById(R.id.editTextCustomerPhone);
		editTextCustomerAddress = (EditText)findViewById(R.id.editTextCustomerAddress);
		datePickerPlanDate = (DatePicker)findViewById(R.id.datePickerPlanDate);
		editTextComment = (EditText)findViewById(R.id.editTextComment);
		editTextCity = (EditText)findViewById(R.id.editTextCity);
		editTextCounty = (EditText)findViewById(R.id.editTextCounty);
		editTextLinkman = (EditText)findViewById(R.id.editTextLinkman);
		editTextLinkmanPhone = (EditText)findViewById(R.id.editTextLinkmanPhone);
		radioButtonActual = (RadioButton)findViewById(R.id.radioButtonActual);
		radioButtonPurpose = (RadioButton)findViewById(R.id.radioButtonPurpose);
		TextView textViewFirstCode = (TextView)findViewById(R.id.textViewFirstCode);
		textViewFirstCode.setVisibility(View.VISIBLE);
		editTextFirstCode = (EditText)findViewById(R.id.editTextFirstCode);
		editTextFirstCode.setVisibility(View.VISIBLE);
		TextView textViewFirstLinkman = (TextView)findViewById(R.id.textViewFirstLinkman);
		textViewFirstLinkman.setVisibility(View.VISIBLE);
		editTextFirstLinkman = (EditText)findViewById(R.id.editTextFirstLinkman);
		editTextFirstLinkman.setVisibility(View.VISIBLE);
//		TextView textViewParticipateActivity = (TextView)findViewById(R.id.textViewParticipateActivity);
//		textViewParticipateActivity.setVisibility(View.GONE);
//		editTextParticipateActivity = (EditText)findViewById(R.id.editTextParticipateActivity);
//		editTextParticipateActivity.setVisibility(View.GONE);
//		TextView textViewDecorateArea = (TextView)findViewById(R.id.textViewDecorateArea);
//		textViewDecorateArea.setVisibility(View.GONE);
//		editTextDecorateArea = (EditText)findViewById(R.id.editTextDecorateArea);
//		editTextDecorateArea.setVisibility(View.GONE);
//		TextView textViewPropertyClassification = (TextView)findViewById(R.id.textViewPropertyClassification);
//		textViewPropertyClassification.setVisibility(View.GONE);
//		editTextPropertyClassification = (EditText)findViewById(R.id.editTextPropertyClassification);
//		editTextPropertyClassification.setVisibility(View.GONE);
//		TextView textViewDecorateExperience = (TextView)findViewById(R.id.textViewDecorateExperience);
//		textViewDecorateExperience.setVisibility(View.GONE);
//		editTextDecorateExperience = (EditText)findViewById(R.id.editTextDecorateExperience);
//		editTextDecorateExperience.setVisibility(View.GONE);
//		TextView textViewUseCount = (TextView)findViewById(R.id.textViewUseCount);
//		textViewUseCount.setVisibility(View.GONE);
//		editTextUseCount = (EditText)findViewById(R.id.editTextUseCount);
//		editTextUseCount.setVisibility(View.GONE);
//		TextView textViewGender = (TextView)findViewById(R.id.textViewGender);
//		textViewGender.setVisibility(View.GONE);
//		editTextGender = (EditText)findViewById(R.id.editTextGender);
//		editTextGender.setVisibility(View.GONE);
//		TextView textViewAgeRange = (TextView)findViewById(R.id.textViewAgeRange);
//		textViewAgeRange.setVisibility(View.GONE);
//		editTextAgeRange = (EditText)findViewById(R.id.editTextAgeRange);
//		editTextAgeRange.setVisibility(View.GONE);
//		TextView textViewJob = (TextView)findViewById(R.id.textViewJob);
//		textViewJob.setVisibility(View.GONE);
//		editTextJob = (EditText)findViewById(R.id.editTextJob);
//		editTextJob.setVisibility(View.GONE);
//		TextView textViewDecider = (TextView)findViewById(R.id.textViewDecider);
//		textViewDecider.setVisibility(View.GONE);
//		editTextDecider = (EditText)findViewById(R.id.editTextDecider);
//		editTextDecider.setVisibility(View.GONE);
//		TextView textViewVillage = (TextView)findViewById(R.id.textViewVillage);
//		textViewVillage.setVisibility(View.GONE);
//		editTextVillage = (EditText)findViewById(R.id.editTextVillage);
//		editTextVillage.setVisibility(View.GONE);

		TextView textViewCustomerStatus = (TextView)findViewById(R.id.textViewCustomerStatus);
		Button buttonEditOrderList = (Button)findViewById(R.id.buttonEditOrderList);
		Button buttonDeleteOrder = (Button)findViewById(R.id.buttonDeleteOrder);
		RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioGroup1);

        String orderContent = this.getIntent().getStringExtra(getString(R.string.string_key_listcontent));
        listnumber = this.getIntent().getStringExtra(getString(R.string.string_key_orderCode));

		TextView textViewOrderCode = (TextView)findViewById(R.id.textViewOrderCode);
		textViewOrderCode.setVisibility(View.VISIBLE);
		textViewOrderCode.setText("�����ţ�" + listnumber);
        
		JSONArray listJSON = null;
	    try {
	    	listJSON = new JSONArray(orderContent); 
	    	JSONArray orderCustomerInfo = listJSON.getJSONArray(1);
	        //����ѡ������ArrayAdapter��������  
	    	String[] orderType = {orderCustomerInfo.getString(12)};
	        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,orderType);
	        //���������б��ķ��  
	        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
	        //��adapter ���ӵ�spinner��  
	        spinner.setAdapter(adapter);   
	    	editTextCustomerName.setText(orderCustomerInfo.getString(0));
	    	editTextCustomerPhone.setText(orderCustomerInfo.getString(1));
	    	editTextCustomerAddress.setText(orderCustomerInfo.getString(2));
	    	String date = orderCustomerInfo.getString(3);
	    	String year = date.substring(0, 4);
	    	String monthOfYear = date.substring(4, 6);
	    	String dayOfMonth = date.substring(6, 8);
	    	datePickerPlanDate.init(Integer.parseInt(year), Integer.parseInt(monthOfYear) - 1, Integer.parseInt(dayOfMonth),null);
	    	editTextComment.setText(orderCustomerInfo.getString(4));
	    	editTextCity.setText(orderCustomerInfo.getString(5));
	    	editTextCounty.setText(orderCustomerInfo.getString(6));
	    	editTextLinkman.setText(orderCustomerInfo.getString(7));
	    	editTextLinkmanPhone.setText(orderCustomerInfo.getString(8));
	    	editTextFirstCode.setText(orderCustomerInfo.getString(10));
	    	editTextFirstLinkman.setText(orderCustomerInfo.getString(11));
//	    	editTextParticipateActivity.setText(orderCustomerInfo.getString(13));
//	    	editTextDecorateArea.setText(orderCustomerInfo.getString(13));
//	    	editTextPropertyClassification.setText(orderCustomerInfo.getString(13));
//	    	editTextDecorateExperience.setText(orderCustomerInfo.getString(14));
//	    	editTextUseCount.setText(orderCustomerInfo.getString(15));
//	    	editTextGender.setText(orderCustomerInfo.getString(16));
//	    	editTextAgeRange.setText(orderCustomerInfo.getString(17));
//	    	editTextJob.setText(orderCustomerInfo.getString(18));
//	    	editTextDecider.setText(orderCustomerInfo.getString(19));
//	    	editTextVillage.setText(orderCustomerInfo.getString(20));
	    	
	    	if (orderCustomerInfo.getString(9).contentEquals("����"))
	    	{
	    		isEnableEdit = true;
	    		radioButtonActual.setChecked(false);
	    		radioButtonPurpose.setChecked(true);
	    		listStatus = "����";
	    		radioGroup.setVisibility(View.VISIBLE);
	    		buttonEditOrderList.setVisibility(View.VISIBLE);
	    		buttonDeleteOrder.setVisibility(View.VISIBLE);
	    	}
	    	else if (orderCustomerInfo.getString(9).contentEquals("����"))
	    	{
	    		isEnableEdit = true;
	    		radioButtonActual.setChecked(true);
	    		radioButtonPurpose.setChecked(false);
	    		listStatus = "ʵ��";
	    		textViewCustomerStatus.setText("״̬������");
	    		radioGroup.setVisibility(View.GONE);
	    		buttonEditOrderList.setVisibility(View.VISIBLE);
	    		buttonDeleteOrder.setVisibility(View.VISIBLE);
	    	}
	    	else if (orderCustomerInfo.getString(9).contentEquals("������"))
	    	{
	    		isEnableEdit = false;
	    		listStatus = "������";
	    		textViewCustomerStatus.setText("״̬��������");
	    		radioGroup.setVisibility(View.GONE);
	    		buttonEditOrderList.setVisibility(View.VISIBLE);
	    		buttonDeleteOrder.setVisibility(View.GONE);
	    	}
	    	
			// ����ɱ���
			mAddconditionLinearLayout = (LinearLayout)findViewById(R.id.addconditionLinearLayout);
			JSONArray paramsHeader = new JSONArray();
			JSONArray params = PublicMethod.postParam(this.getApplicationContext(), "ORDERSEL", paramsHeader);
			String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());//"[\,\"\",[\"\",\"95322\",\"OWNER\",\"AA\"]]");
			if (result == null || result.isEmpty())
			{
	        	PublicMethod.displayToast(this.getApplicationContext(), "error while " + "ORDERSEL" + " :" + result);
				return;
			}
			
	    	try {
	    		JSONObject jsonCheckResult = new JSONObject(result);
		        if (jsonCheckResult.has("ERROR"))
		        {
		        	PublicMethod.displayToast(this.getApplicationContext(), jsonCheckResult.getString("ERROR"));
		        	return;
		        }
		        layoutSearchCondition(result);

				//С����
				CommunityName.setText(orderCustomerInfo.getString(13));
		        //�ɱ�
				ConditionInterface conditionInterface;
				for (int linearLayoutLeftIndex = 0; linearLayoutLeftIndex < mAddconditionLinearLayout.getChildCount(); linearLayoutLeftIndex++)
				{
					String value = orderCustomerInfo.getString(14+linearLayoutLeftIndex);
					conditionInterface = (ConditionInterface) mAddconditionLinearLayout.getChildAt(linearLayoutLeftIndex);
					if (conditionInterface.getClass().equals(ConditionText.class))
						((ConditionText)conditionInterface).setText(value);
					else if (conditionInterface.getClass().equals(ConditionRadio.class))
						((ConditionRadio)conditionInterface).setText(value);
					else if (conditionInterface.getClass().equals(ConditionDate.class))
						((ConditionDate)conditionInterface).setDate(value);
				}
		    } catch (JSONException e) {  
		    	Log.e(FullscreenActivity.TAG, "error while login:" + e.getMessage());
	        	return;
		    }

	    	orderTable.clear();
	        String title[] = {"��Ʒ����", "�ȼ�", "Ƭ��", "�ɽ���", "�ӹ��۸�(Ƭ)", "�ܽ��", "��;", "��װ��","��ע","�Ƿ���Ʒ", "��Ʒ����", "����(����)", "ʣ��Ƭ��"};
	        int gravity[] = {Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.RIGHT};
	        int width[] = {128, 42, 72, 104, 104, 130, 240, 90, 420, 130, 260, 175, 72};
	        float totalMoney = 0;
	        float totalWeight = 0;
	        // �ѱ���������ӵ�����  
	        for (int i = 2; i < listJSON.length(); i++)  
	        {
	            // ÿ�е�����  
		    	JSONArray rawJSON = listJSON.getJSONArray(i);
	            TableCell[] cells = new TableCell[rawJSON.length()-1]; 
	            cells[0] = new TableCell(rawJSON.getString(3), width[0], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[0]); 
	            cells[1] = new TableCell(rawJSON.getString(5), width[1], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[1]); 
	            cells[2] = new TableCell(rawJSON.getString(6), width[2], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[2]); 
	            cells[3] = new TableCell(rawJSON.getString(7), width[3], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[3]); 
	            cells[4] = new TableCell(rawJSON.getString(11), width[4], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[4]);
	            cells[5] = new TableCell(rawJSON.getString(8), width[5], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[5]); 
	            cells[6] = new TableCell(rawJSON.getString(1), width[6], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[6]); 
	            cells[7] = new TableCell(rawJSON.getString(4), width[7], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[7]); 
	            cells[8] = new TableCell(rawJSON.getString(9), width[8], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[8]); 
	            String value = rawJSON.getString(10);
	            value = value.contentEquals("0")? "��":"��"; 
	            cells[9] = new TableCell(value, width[9], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[9]); 
	            cells[10] = new TableCell(rawJSON.getString(2), width[10], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[10]); 
	            cells[11] = new TableCell(rawJSON.getString(12), width[11], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[11]); 
//	            cells[12] = new TableCell(rawJSON.getString(13), width[12], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[12]); 
	            orderTable.add(new TableRow(cells)); 
	            
	            totalMoney += Float.valueOf(rawJSON.getString(8));
	            totalWeight += Float.valueOf(rawJSON.getString(12));
				BigDecimal b = new BigDecimal(totalMoney);  
				totalMoney  = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue(); 
	        }

			TextView textViewTotalMoney = (TextView) findViewById(R.id.textViewTotalMoney);
			if (totalMoney != 0)
			{
				textViewTotalMoney.setText("�ܽ�" + String.format("%.02f", totalMoney));
			}
			else 
				textViewTotalMoney.setVisibility(View.GONE);

			TextView textViewTotalWeight = (TextView) findViewById(R.id.textViewTotalWeight);
			if (totalMoney != 0)
			{
				textViewTotalWeight.setText("�������������" + String.format("%.03f", totalWeight));
			}
			else 
				textViewTotalWeight.setVisibility(View.GONE);
	    } catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    buttonEditOrderList.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) {
				Intent mIntent = new Intent(ChangeOrderCustomerInfo.this,ChangeOrderListView.class);
				mIntent.putExtra(ChangeOrderCustomerInfo.this.getString(R.string.string_key_isEnableEdit), isEnableEdit);
				startActivityForResult(mIntent, EnterConditionView.EnterConditionResult);
			}
        });
	    
	    buttonDeleteOrder.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) {
				
				JSONArray paramsHeader = new JSONArray();
				paramsHeader.put(listnumber);
				JSONArray params = PublicMethod.postParam(ChangeOrderCustomerInfo.this, "ORDCANCEL", paramsHeader);

				String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
				if (result == null || result.isEmpty())
					return ;

				if (result.contains("ERROR"))
		        {
		        	PublicMethod.displayToast(ChangeOrderCustomerInfo.this.getApplicationContext(), result);
		        	return;
		        }
				
		    	try {
		    		JSONArray jsonCheckResult = new JSONArray(result);
			        if (jsonCheckResult.length() < 2 || jsonCheckResult.getString(0).contains("ERROR"))
			        {
			        	if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).length() >=1)
			        		PublicMethod.displayToast(ChangeOrderCustomerInfo.this, jsonCheckResult.getJSONArray(1).getString(0));
			        	return ;
			        }
			        else
			        {
			        	PublicMethod.displayToast(ChangeOrderCustomerInfo.this, "����������");
						ChangeOrderCustomerInfo.this.setResult(FunctionList.MenuResult);
						ChangeOrderCustomerInfo.this.finish();
			        }
			    } catch (JSONException e) {  
			    	Log.e(FullscreenActivity.DEBUG_TAG, "error while buttonSearchBook OnClickListener:" + e.getMessage());
			    }
			}
        });
        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				ChangeOrderCustomerInfo.this.setResult(FunctionList.MenuResult);
				ChangeOrderCustomerInfo.this.finish();
			}
        });
        
		radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
		    
		    @Override
		    public void onCheckedChanged(RadioGroup arg0, int checkID) {
			if(radioButtonActual.getId() == checkID) {
				listStatus = "ʵ��";
			}else if(radioButtonPurpose.getId() == checkID) {
				listStatus = "����";
			}
		    }
		});
        
		Button buttonCreatBook = (Button)findViewById(R.id.buttonCreatBook);
		buttonCreatBook.setText("���涩��");
		buttonCreatBook.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
//				JSONArray params = new JSONArray();
//				params.put("ORDERCRT");
//				params.put("");

				JSONArray paramsHeader = new JSONArray();

//				MarketorderApplication app = (MarketorderApplication)CustomerInfo.this.getApplicationContext();
//				User user = app.getUser();
//				if (user != null && user.isLogin == User.TRUE)
//					paramsHeader.put(user.name);
//				else
//					paramsHeader.put("");
				paramsHeader.put(listnumber);
				paramsHeader.put(editTextCustomerName.getText().toString().trim());
				paramsHeader.put(editTextCustomerPhone.getText().toString().trim());
				paramsHeader.put(editTextCustomerAddress.getText().toString().trim());
				datePickerPlanDate.clearFocus();
				paramsHeader.put(String.format("%04d%02d%02d", datePickerPlanDate.getYear(), datePickerPlanDate.getMonth()+1,datePickerPlanDate.getDayOfMonth()));
				paramsHeader.put(editTextComment.getText().toString().trim());
				paramsHeader.put(editTextCity.getText().toString().trim());
				paramsHeader.put(editTextCounty.getText().toString().trim());
				paramsHeader.put(editTextLinkman.getText().toString().trim());
				paramsHeader.put(editTextLinkmanPhone.getText().toString().trim());
				paramsHeader.put(listStatus);
				paramsHeader.put(editTextFirstCode.getText().toString().trim());
				paramsHeader.put(editTextFirstLinkman.getText().toString().trim());
//				paramsHeader.put(editTextParticipateActivity.getText().toString().trim());
//				paramsHeader.put(editTextDecorateArea.getText().toString().trim());
//				paramsHeader.put(editTextPropertyClassification.getText().toString().trim());
//				paramsHeader.put(editTextDecorateExperience.getText().toString().trim());
//				paramsHeader.put(editTextUseCount.getText().toString().trim());
//				paramsHeader.put(editTextGender.getText().toString().trim());
//				paramsHeader.put(editTextAgeRange.getText().toString().trim());
//				paramsHeader.put(editTextJob.getText().toString().trim());
//				paramsHeader.put(editTextDecider.getText().toString().trim());
//				paramsHeader.put(editTextVillage.getText().toString().trim());
//				params.put(paramsHeader);
				if (editTextCustomerName.getText().length() == 0 || editTextCustomerName.getText().toString().trim() == "")
				{
					PublicMethod.displayToast(ChangeOrderCustomerInfo.this, "�ͻ����Ʋ��ܿ�");
		        	return ;
				}
				if (editTextCustomerPhone.getText().length() == 0 || editTextCustomerPhone.getText().toString().trim() == "")
				{
					PublicMethod.displayToast(ChangeOrderCustomerInfo.this, "�ͻ��绰���ܿ�");
		        	return ;
				}
				if (editTextCustomerAddress.getText().length() == 0 || editTextCustomerAddress.getText().toString().trim() == "")
				{
					PublicMethod.displayToast(ChangeOrderCustomerInfo.this, "�ͻ���ַ���ܿ�");
		        	return ;
				}

				//С����
				paramsHeader.put(CommunityName.getText());
				
				//�ɱ�
				ConditionInterface conditionInterface;
				for (int linearLayoutLeftIndex = 0; linearLayoutLeftIndex < mAddconditionLinearLayout.getChildCount(); linearLayoutLeftIndex++)
				{
					conditionInterface = (ConditionInterface) mAddconditionLinearLayout.getChildAt(linearLayoutLeftIndex);
					if (!conditionInterface.checkMandatory())
						return;
					if (!conditionInterface.getIsNotSubmit())
						paramsHeader.put(conditionInterface.getText());
				}
					
				JSONArray params = PublicMethod.postParam(ChangeOrderCustomerInfo.this, "ORDERCHG", paramsHeader);
				int line = 1;
				for (int i = 0; i < orderTable.size(); i++)
				{
					TableRow tableRow = orderTable.get(i);
					
//					if (!tableRow.isChecked)
//						continue;
					
					JSONArray paramsRow = new JSONArray();
					paramsRow.put(String.valueOf(line));
					paramsRow.put(tableRow.getCellValue(6).value);
					paramsRow.put(tableRow.getCellValue(10).value);
					paramsRow.put(tableRow.getCellValue(0).value);
					paramsRow.put(tableRow.getCellValue(7).value);
					paramsRow.put(tableRow.getCellValue(1).value);
					paramsRow.put(tableRow.getCellValue(2).value);
					paramsRow.put(tableRow.getCellValue(3).value);
					paramsRow.put(tableRow.getCellValue(5).value);
					paramsRow.put(tableRow.getCellValue(8).value);
					paramsRow.put(tableRow.getCellValue(9).value.toString().contentEquals("��")? "1" : "0");
					paramsRow.put(tableRow.getCellValue(4).value);

					params.put(paramsRow);
					line++;
				}
//				if (line == 1)
//				{	
//					PublicMethod.displayToast(ChangeOrderCustomerInfo.this, "��ѡ��Ҫ���빺�ﳵ����");
//					return ;
//				}
				String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
				if (result == null || result.isEmpty())
					return ;
				
				if (result.contains("ERROR"))
		        {
		        	PublicMethod.displayToast(ChangeOrderCustomerInfo.this.getApplicationContext(), result);
		        	return;
		        }
				
		    	try {
		    		JSONArray jsonCheckResult = new JSONArray(result);
			        if (jsonCheckResult.length() < 2 || jsonCheckResult.getString(0).contains("ERROR"))
			        {
			        	if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).length() >=1)
			        		PublicMethod.displayToast(ChangeOrderCustomerInfo.this, jsonCheckResult.getJSONArray(1).getString(0));
			        	return ;
			        }
//			        else if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).getString(0).equals("0"))
//			        {
//			        	PublicMethod.displayToast(CustomerInfo.this, jsonCheckResult.getJSONArray(1).getString(1));
//			        	return ;
//			        }
			        else
			        {
			        	returnResult = jsonCheckResult.getJSONArray(1).getString(0);
			        	Dialog dialog = new AlertDialog.Builder(ChangeOrderCustomerInfo.this)
			        					.setTitle(R.string.string_prompt)
			        					.setMessage( String.format("�����ţ�%s���Ƿ��ѯ,%s", returnResult, jsonCheckResult.getJSONArray(1).getString(1)))
			        					.setPositiveButton(R.string.string_ok, 
			        							new DialogInterface.OnClickListener() {
			    			
			    									@Override
			    									public void onClick(DialogInterface dialog, int which) {
			    										// TODO Auto-generated method stub
			    										Intent resultIntent = new Intent();
			    										Bundle bundle = new Bundle();
			    										bundle.putString("result", returnResult);
			    										resultIntent.putExtras(bundle);
			    										ChangeOrderCustomerInfo.this.setResult(RESULT_OK, resultIntent);
			    										ChangeOrderCustomerInfo.this.finish();
			    									}
			    								})
			    								.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			    			
			    									@Override
			    									public void onClick(DialogInterface dialog, int which) {
			    										ChangeOrderCustomerInfo.this.setResult(FunctionList.MenuResult);
			    										ChangeOrderCustomerInfo.this.finish();
			    									}
			    								}).create();
			        	dialog.show();
//			        	Inventory.tableShoppingCart.clear();
//			        	PublicMethod.displayToast(ChangeOrderCustomerInfo.this, "���������ɹ�");
//			        	for (int i = 0; i < ChangeOrderCustomerInfo.orderTable.size(); )
//						{
//							TableRow tableRow = ChangeOrderCustomerInfo.orderTable.get(i);
//							
//							if (tableRow.isChecked)
//							{
//								ChangeOrderCustomerInfo.orderTable.remove(i);
//								continue;
//							}
//							
//							i++;
//						}
//			        	Inventory.saveShoppingCartTable(ChangeOrderCustomerInfo.this);
			        }
			    } catch (JSONException e) {  
			    	Log.e(FullscreenActivity.DEBUG_TAG, "error while buttonCreatBook OnClickListener:" + e.getMessage());
			    }
			}
        	
        });
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString(SearchListView.returnKey);
			try {
				SharedPreferences settings = ChangeOrderCustomerInfo.this.getSharedPreferences("login", 0);  
    			String XQLISTString = settings.getString("XQLIST", "");
    			final JSONObject XQLISTObject = new JSONObject(XQLISTString);
				JSONArray array = XQLISTObject.getJSONArray(returnResult);
				//С����
				CommunityName.setText(returnResult);
				//����
				editTextCity.setText(array.getString(2));
				//����
				editTextCounty.setText(array.getString(3));
				//��ַ
				editTextCustomerAddress.setText(array.getString(4));
				ConditionInterface conditionInterface;
				for (int linearLayoutLeftIndex = 0; linearLayoutLeftIndex < mAddconditionLinearLayout.getChildCount() && linearLayoutLeftIndex < 4; linearLayoutLeftIndex++)
				{
					String value = array.getString(5 + linearLayoutLeftIndex);
					conditionInterface = (ConditionInterface) mAddconditionLinearLayout.getChildAt(linearLayoutLeftIndex);
					if (conditionInterface.getClass().equals(ConditionText.class))
						((ConditionText)conditionInterface).setText(value);
					else if (conditionInterface.getClass().equals(ConditionRadio.class))
						((ConditionRadio)conditionInterface).setText(value);
					else if (conditionInterface.getClass().equals(ConditionDate.class))
						((ConditionDate)conditionInterface).setDate(value);
				}
				return ;
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return ;
			}
		}
		if(resultCode == FunctionList.MenuResult)
		{
			ChangeOrderCustomerInfo.this.setResult(FunctionList.MenuResult);
			ChangeOrderCustomerInfo.this.finish();
		}
		
		float totalMoney = 0;
		float totalWeight = 0;
		for (int i=0; i<orderTable.size(); i++)
		{
			TableRow tablerow = orderTable.get(i);
            totalWeight += Float.valueOf(tablerow.getCellValue(11).value.toString());
			totalMoney += (Float.valueOf(tablerow.getCellValue(3).value.toString()) + Float.valueOf(tablerow.getCellValue(4).value.toString()))*Float.valueOf(tablerow.getCellValue(2).value.toString());
			BigDecimal b = new BigDecimal(totalMoney);  
			totalMoney  = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
		}

		TextView textViewTotalMoney = (TextView) findViewById(R.id.textViewTotalMoney);
		if (totalMoney != 0)
		{
			textViewTotalMoney.setText("�ܽ�" + String.format("%.02f", totalMoney));
		} 

		TextView textViewTotalWeight = (TextView) findViewById(R.id.textViewTotalWeight);
		if (totalMoney != 0)
		{
			textViewTotalWeight.setText("�������������" + String.format("%.03f", totalWeight));
		} 
        
	}

	private void layoutSearchCondition(String strConditionSearch)
	{
        JSONArray conditionList;
		String type;
		String title;
		LinearLayout conditionLinearLayout = null;
		ConditionInterface conditionInterface = null;
		ConditionText conditionText;
		ConditionDate conditionDate;
		ConditionRadio conditionRadio;
		
		try {
			JSONObject conditionSearchObject = new JSONObject(strConditionSearch);
//			strConditionSearchType = conditionSearchObject.getString(strJsonKey_type);
			conditionList = conditionSearchObject.getJSONArray(strJsonKey_condition);
			
			JSONObject itemObject;
			JSONArray selectItem;
	        for (int conditionListIndex=0; conditionListIndex<conditionList.length(); conditionListIndex++)
	        {
	        	itemObject = conditionList.getJSONObject(conditionListIndex);
	        	
	        	// type
	        	type = itemObject.getString(strJsonKey_type);
	        	//text
	        	if (strType_text.contentEquals(type))
	        	{
	        		conditionText = new ConditionText(this);
	        		conditionLinearLayout = conditionText;
	        		conditionInterface = conditionText;
	        		
		        	// defaultvalue
		        	if (itemObject.has(strJsonKey_defaultvalue))
		        	{
		        		conditionText.setText(itemObject.getString(strJsonKey_defaultvalue));
		        	}

		        	// isMandatory
		        	if (itemObject.has(strJsonKey_mandatory))
		        		conditionText.isMandatory = itemObject.getBoolean(strJsonKey_mandatory);
		        	
		        	// isOnlyRead
		        	if (itemObject.has(strJsonKey_isOnlyRead))
		        		conditionText.setEnable(!itemObject.getBoolean(strJsonKey_isOnlyRead));
	        	}
	        	//date
	        	else if (strType_date.contentEquals(type))
	        	{
	        		conditionDate = new ConditionDate(this);
	        		conditionLinearLayout = conditionDate;
	        		conditionInterface = conditionDate;

		        	// defaultvalue
		        	if (itemObject.has(strJsonKey_defaultvalue))
		        	{
		        		String defaultValue = itemObject.getString(strJsonKey_defaultvalue);
		        		conditionDate.setDate(defaultValue);
		        	}
	        	}
	        	//radio
	        	else if (strType_radio.contentEquals(type))
	        	{
	        		conditionRadio = new ConditionRadio(this);
	        		conditionLinearLayout = conditionRadio;
	        		conditionInterface = conditionRadio;
	        		if (itemObject.getString(strJsonKey_title).contentEquals("С������"))
	        		{
		        		CommunityName = conditionRadio;

	        			selectItem = new JSONArray();
	        			SharedPreferences settings = ChangeOrderCustomerInfo.this.getSharedPreferences("login", 0);  
	        			String XQLISTString = settings.getString("XQLIST", "");
	        			final JSONObject XQLISTObject = new JSONObject(XQLISTString);
	        			@SuppressWarnings("unchecked")
						Iterator<String> it = XQLISTObject.keys();
	                    while(it.hasNext()){
	                    	selectItem.put(it.next().toString());
	                    }
	                    conditionRadio.setOnClickListener(new OnClickListener(){
	            			@Override
	            			public void onClick(View v) { 
	            				Intent ChangeSaveIntent = new Intent(ChangeOrderCustomerInfo.this, SearchListView.class);
	            				ChangeOrderCustomerInfo.this.startActivityForResult(ChangeSaveIntent, EnterConditionView.ChangeConditionResult);
	            			}
	            			
	            		});
	        		}
	        		else
	        			selectItem = itemObject.getJSONArray(strJsonKey_selectItem);
	        		List<String> selectList = new ArrayList<String>();
	        		for (int selectItemIndex=0; selectItemIndex < selectItem.length(); selectItemIndex++)
	        			selectList.add(selectItem.getString(selectItemIndex));
	        		conditionRadio.setSelectItem(selectList);

		        	// defaultvalue
		        	if (itemObject.has(strJsonKey_defaultvalue))
		        		conditionRadio.setText(itemObject.getString(strJsonKey_defaultvalue));
	        	}

	        	// title
	        	title = itemObject.getString(strJsonKey_title);
	        	conditionInterface.setTitle(title);
	        	
	        	// isNotSubmit
	        	if (itemObject.has(strJsonKey_isNotSubmit))
	        		conditionInterface.setIsNotSubmit(itemObject.getBoolean(strJsonKey_isNotSubmit));
	        	
	        	// addview
	        	if (itemObject.getString(strJsonKey_title).contentEquals("С������"))
	        	{
	        		LinearLayout FixedLinearLayout = (LinearLayout)findViewById(R.id.FixedLinearLayout);
	        		FixedLinearLayout.addView(conditionLinearLayout, 11);
	        	}
	        	else
	        		mAddconditionLinearLayout.addView(conditionLinearLayout);
	        }
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
