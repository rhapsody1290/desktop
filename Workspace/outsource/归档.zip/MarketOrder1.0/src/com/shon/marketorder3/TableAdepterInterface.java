package com.shon.marketorder3;

public interface TableAdepterInterface {
	void CheckboxOnClick(boolean isCheck);
}
