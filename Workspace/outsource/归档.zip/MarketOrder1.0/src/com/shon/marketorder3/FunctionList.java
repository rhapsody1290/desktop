package com.shon.marketorder3;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.shon.marketorder3.Inventory;
import com.shon.marketorder3.mk.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.view.View.OnClickListener;



//{
//    "page": "mainmenu",
//    "title": "���˵�",
//    "submenu": [
//        {
//            "pagetype": "inventory",
//            "page": "OWNER",
//            "title": "���п��"
//        },
//        {
//            "pagetype": "inventory",
//            "page": "PLANT",
//            "title": "�������"
//        },
//        {
//            "pagetype": "shoppingcart",
//            "page": "ANDR.ORDCRT",
//            "title": "��������"
//        },
//        {
//            "page": "",
//            "title": "���۱���",
//            "submenu": [
//                {
//                    "pagetype": "conditionsearch",
//                    "page": "P80100",
//                    "title": "�������ѯ"
//                },
//                {
//                    "pagetype": "conditionsearch",
//                    "page": "P80200",
//                    "title": "��������"
//                }
//            ]
//        },
//        {
//            "page": "",
//            "title": "�տ��ѯ",
//            "submenu": [
//                {
//                    "pagetype": "conditionsearch",
//                    "page": "P80300",
//                    "title": "�����տ��ѯ"
//                }
//            ]
//        },
//        {
//            "pagetype": "searchimage",
//            "page": "ANDR.ORDCRT",
//            "title": "��������"
//        }
//    ]
//}


public class FunctionList extends Activity {
	static public final int MenuResult = 30001;
	static int tier = 0;

	final String strJsonKey_submenu = "submenu";
	final String strJsonKey_title = "title";
	final String strJsonKey_page = "page";
	final String strJsonKey_pagetype = "pagetype";
	final String strJsonKey_number = "number";
	
	JSONArray menulist;
	private String thisPage;
    
    private ListView listView;  
    private FunctionListViewAdapter adapter;  
    //��Ϊ����Դ��ʹ��  
    private List<FunctionListViewAdapterData> data = null; 
    //�������� ����
    private TextView waitNumberTextView = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);

		Inventory.getShoppingCartTable(this);

        setContentView(R.layout.functionlist);  
        initComponent();  
        
        String strMenu = this.getIntent().getStringExtra(getString(R.string.string_key_FunctionList_menu));
        data = new ArrayList<FunctionListViewAdapterData>();
		try {
			JSONObject mainmenu = new JSONObject(strMenu);
			thisPage = mainmenu.getString(strJsonKey_page);
	        menulist = mainmenu.getJSONArray(strJsonKey_submenu);
	        String number;
	        String pagetype;
	        for (int i=0; i<menulist.length(); i++)
	        {
		        number = "0";
		        if (menulist.getJSONObject(i).has(strJsonKey_number))
		        	number = menulist.getJSONObject(i).getString(strJsonKey_number);
		        if (menulist.getJSONObject(i).has(strJsonKey_submenu))
		        	pagetype = FunctionListViewAdapterData.type_folder;
		        // ������ѯ
				else if(menulist.getJSONObject(i).has(strJsonKey_page)
						&& menulist.getJSONObject(i).has(strJsonKey_pagetype)
						&& menulist.getJSONObject(i).getString(strJsonKey_pagetype).contentEquals(SearchCondition.page_tag)
						)
		        	pagetype = FunctionListViewAdapterData.type_table;
				else
	        		pagetype = FunctionListViewAdapterData.type_approval;
		        data.add(new FunctionListViewAdapterData(menulist.getJSONObject(i).getString(strJsonKey_title), number, pagetype));
	        }
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        adapter = new FunctionListViewAdapter(FunctionList.this);  
        listView.setAdapter(adapter);  
        listView.setOnItemClickListener(new ItemClickEvent());
        
        Button buttonLogout = (Button)this.findViewById(R.id.buttonLogOut);
		if (!thisPage.contentEquals("mainmenu"))
			buttonLogout.setText("����");
        buttonLogout.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (thisPage.contentEquals("mainmenu"))
				{
					MarketorderApplication app = (MarketorderApplication)FunctionList.this.getApplicationContext();
					app.getUser().logout();
				}
				FunctionList.this.finish();
			}
        	
        });
    }  
      
    private void initComponent(){  
        listView = (ListView)findViewById(R.id.listView1);  
          
    }  

    class ItemClickEvent implements AdapterView.OnItemClickListener {  
        @SuppressLint("NewApi")
		@Override  
        public void onItemClick(AdapterView<?> arg0, View tableRowView, int index,  
                long arg3) {  
        	try {
				JSONObject mainmenu = menulist.getJSONObject(index);
				
				// �Ӳ˵�
				if (mainmenu.has(strJsonKey_submenu))
				{
		            Intent FunctionListIntent = new Intent(FunctionList.this, FunctionList.class);
		            FunctionListIntent.putExtra(FunctionList.this.getString(R.string.string_key_FunctionList_menu), mainmenu.toString());
		            FunctionList.this.startActivity(FunctionListIntent);
		            return;
				}
				// ������ѯ
				else if(mainmenu.has(strJsonKey_page)
						&& mainmenu.has(strJsonKey_pagetype)
						&& mainmenu.getString(strJsonKey_pagetype).contentEquals(SearchCondition.page_tag))
				{
					ConditionSearchClick(mainmenu.getString(strJsonKey_page), null);
					return;
				}
				//����ѯ
				else if(mainmenu.has(strJsonKey_page)
						&& mainmenu.has(strJsonKey_pagetype)
						&& mainmenu.getString(strJsonKey_pagetype).contentEquals(Inventory.page_tag))
				{
					String storage = null;
					if(mainmenu.has(strJsonKey_page))
						storage = mainmenu.getString(strJsonKey_page);
					Intent InventoryIntent = new Intent(FunctionList.this, Inventory.class);
	            	InventoryIntent.putExtra(strJsonKey_page, mainmenu.getString(strJsonKey_page));
	            	InventoryIntent.putExtra(FunctionList.this.getString(R.string.string_key_storage), storage);
	            	FunctionList.this.startActivityForResult(InventoryIntent, 0);
	            	return;
				}
				//���ﳵ
				else if(mainmenu.has(strJsonKey_page)
						&& mainmenu.has(strJsonKey_pagetype)
						&& mainmenu.getString(strJsonKey_pagetype).contentEquals(ShoppingCartListView.page_tag))
				{
					Intent ShoppingCartIntent = new Intent(FunctionList.this, ShoppingCartListView.class);
	            	FunctionList.this.startActivityForResult(ShoppingCartIntent, 0);
	            	return;
				}
				//ͼƬ��ѯ
				else if(mainmenu.has(strJsonKey_page)
						&& mainmenu.has(strJsonKey_pagetype)
						&& mainmenu.getString(strJsonKey_pagetype).contentEquals(SearchImageView.page_tag))
				{
	            	Intent SearchImageViewIntent = new Intent(FunctionList.this, SearchImageView.class);
	            	FunctionList.this.startActivity(SearchImageViewIntent);
				}
//				// ��������
//				else if(mainmenu.has(strJsonKey_page)
//						&& mainmenu.getString(strJsonKey_page).contentEquals(ApprovalList.page_tag))
//				{
//					String result = ApprovalList.approvalListRequest(FunctionList.this.getApplicationContext(), mainmenu.getString(strJsonKey_page));
//					if (result == null || result.isEmpty())
//					{
//			        	PublicMethod.displayToast(FunctionList.this.getApplicationContext(), "error while " + mainmenu.getString(strJsonKey_page) + " :" + result);
//						return;
//					}
//					
//			    	try {
//			    		JSONObject jsonCheckResult = new JSONObject(result);
//				        if (jsonCheckResult.has("ERROR"))
//				        {
//				        	PublicMethod.displayToast(FunctionList.this.getApplicationContext(), jsonCheckResult.getString("ERROR"));
//				        	return;
//				        }
//
//			            Intent ApprovalListIntent = new Intent(FunctionList.this, ApprovalList.class);
//			            ApprovalListIntent.putExtra(FunctionList.this.getString(R.string.string_key_ApprovalList_result), result);
//			            ApprovalListIntent.putExtra(FunctionList.this.getString(R.string.string_key_ApprovalList_requestType), mainmenu.getString(strJsonKey_page));
//			            FunctionList.this.startActivityForResult(ApprovalListIntent, ApprovalList.ApprovalList_Result);
//			            
//				    } catch (JSONException e) {  
//				    	Log.e(Login.TAG, "error while login:" + e.getMessage());
//			        	return;
//				    }
//				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }  
    }  
	
    private void ConditionSearchClick(String page, String orderid)
    {
		JSONArray paramsHeader = new JSONArray();
		JSONArray params = PublicMethod.postParam(FunctionList.this.getApplicationContext(), page, paramsHeader);
		String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());//"[\,\"\",[\"\",\"95322\",\"OWNER\",\"AA\"]]");
		if (result == null || result.isEmpty())
		{
        	PublicMethod.displayToast(FunctionList.this.getApplicationContext(), "error while " + page + " :" + result);
			return;
		}
		
    	try {
    		JSONObject jsonCheckResult = new JSONObject(result);
	        if (jsonCheckResult.has("ERROR"))
	        {
	        	PublicMethod.displayToast(FunctionList.this.getApplicationContext(), jsonCheckResult.getString("ERROR"));
	        	return;
	        }

            Intent SearchConditionIntent = new Intent(FunctionList.this, SearchCondition.class);
            SearchConditionIntent.putExtra(FunctionList.this.getString(R.string.string_key_SearchCondition_condition), result);
            if (orderid != null)
                SearchConditionIntent.putExtra(FunctionList.this.getString(R.string.string_key_SearchCondition_orderid), orderid);
            FunctionList.this.startActivity(SearchConditionIntent);
            
	    } catch (JSONException e) {  
	    	Log.e(FullscreenActivity.TAG, "error while login:" + e.getMessage());
        	return;
	    }
	}
//	private View.OnClickListener mButtonClickListener = new OnClickListener()
//	{
//		public void onClick(View v)
//		{
//			String searchType = "";
//			switch (v.getId())
//			{
//			case R.id.buttonLogOut:
//				MarketorderApplication app = (MarketorderApplication)FunctionList.this.getApplicationContext();
//				User user = app.getUser();
//				if (user != null)
//					user.logout();
//				FunctionList.this.finish();
//				return;
//			case R.id.buttonSelfInventory:
//			{
//            	Intent InventoryIntent = new Intent(FunctionList.this, Inventory.class);
//            	InventoryIntent.putExtra(FunctionList.this.getString(R.string.string_key_storage), "OWNER");
//            	FunctionList.this.startActivityForResult(InventoryIntent, 0);
//            	return;
//			}
//			case R.id.buttonCompanyInventory:
//			{
//            	Intent InventoryIntent = new Intent(FunctionList.this, Inventory.class);
//            	InventoryIntent.putExtra(FunctionList.this.getString(R.string.string_key_storage), "PLANT");
//            	FunctionList.this.startActivityForResult(InventoryIntent, 0);
//            	return;
//			}
//			case R.id.buttonGotoShoppingCart:
//			{
//				Intent intent = new Intent(FunctionList.this,ShoppingCartListView.class);
//				startActivityForResult(intent, 0);
//            	return;
//			}
//				
////			case R.id.buttonOrder:
////			{
////            	Intent SearchListIntent = new Intent(FunctionList.this, SearchList.class);
////            	SearchListIntent.putExtra(FunctionList.this.getString(R.string.string_key_storage), "PLANT");
////            	FunctionList.this.startActivity(SearchListIntent);
////				break;
////			}
	// case R.id.buttonSearchImage:
//            	Intent SearchImageViewIntent = new Intent(FunctionList.this, SearchImageView.class);
//            	FunctionList.this.startActivity(SearchImageViewIntent);
//				return;
//			case R.id.buttonPlanList:
//				searchType = "PLANLIST";
//				break;
//			case R.id.buttonOrderList:
//				searchType = "ORDERLIST";
//				break;
//			case R.id.buttonPickList:
//				searchType = "PICKLIST";
//				break;
//			case R.id.buttonOrderIssue:
//				searchType = "ORDERISSUE";
//				break;
//			case R.id.buttonOrderPay:
//				searchType = "ORDERPAY";
//				break;
//			case R.id.buttonOrderTrace:
//				searchType = "ORDERTRACE";
//				break;
//			case R.id.buttonRebList:
//				searchType = "REBATELIST";
//				break;
//				
//            	
//			}
//        	Intent SearchListIntent = new Intent(FunctionList.this, SearchView.class);
//        	SearchListIntent.putExtra(FunctionList.this.getString(R.string.string_key_searchType), searchType);
//        	FunctionList.this.startActivity(SearchListIntent);
//		}
//	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		//����ɨ�������ڽ�������ʾ��
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString("result");

//        	Intent SearchListIntent = new Intent(FunctionList.this, SearchView.class);
//        	SearchListIntent.putExtra(FunctionList.this.getString(R.string.string_key_searchType), "ORDERLIST");
//        	SearchListIntent.putExtra(FunctionList.this.getString(R.string.string_key_orderCode), returnResult);
//        	FunctionList.this.startActivity(SearchListIntent);

			ConditionSearchClick("P80000", returnResult);
		}
		else if(resultCode == MenuResult)
		{
			
		}
	}
	
//	@Override
	protected void onDestroy()
	{
		Inventory.tableShoppingCart.clear();
		super.onDestroy();
	}

	public void updateWaitNumber(int number)
	{
		if (waitNumberTextView == null)
			return;
		
		waitNumberTextView.setText(Integer.valueOf(number).toString());
	}
	
	class FunctionListViewAdapterData{
		final static String type_folder = "folder";
		final static String type_table = "table";
		final static String type_approval = "approval";
		public String title;
		public String number;
		public String type;
		public FunctionListViewAdapterData(String title, String number, String type) {  
            this.title = title;  
            this.number = number;
            this.type = type;
		}
	}
	public class FunctionListViewAdapter extends BaseAdapter {
        private LayoutInflater mInflater;        
        public FunctionListViewAdapter(Context context){
            this.mInflater = LayoutInflater.from(context);
        }
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return data.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub                
			convertView = mInflater.inflate(R.layout.functionlistview, null);
			TextView title = (TextView)convertView.findViewById(R.id.ItemText);
			title.setText(data.get(position).title);
			if (!data.get(position).number.contentEquals("0"))
			{
				TextView number = (TextView)convertView.findViewById(R.id.textViewHint);
				number.setText(data.get(position).number);
				number.setVisibility(View.VISIBLE);
				waitNumberTextView = number;
			}
			ImageView arrowsImageView = (ImageView)convertView.findViewById(R.id.imageViewArrows);
			ImageView iconImageView = (ImageView)convertView.findViewById(R.id.imageViewIcon);
			if (data.get(position).type.contentEquals(FunctionListViewAdapterData.type_folder))
			{
				iconImageView.setImageResource(R.drawable.folder);
				arrowsImageView.setVisibility(View.VISIBLE);
			}
			else if (data.get(position).type.contentEquals(FunctionListViewAdapterData.type_table))
				iconImageView.setImageResource(R.drawable.table);
			else if (data.get(position).type.contentEquals(FunctionListViewAdapterData.type_approval))
				iconImageView.setImageResource(R.drawable.approval);
			return convertView;
		}
	
	}
}
