package com.shon.marketorder3;

import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.shon.marketorder3.SearchResultView.FWKLISTItemClickEvent;
import com.shon.marketorder3.SearchResultView.ORDERLISTItemClickEvent;
import com.shon.marketorder3.SearchResultView.changeRowItemClickEvent;
import com.shon.marketorder3.TableAdapter.TableCell;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.SearchView;  

public class SearchListView extends Activity implements SearchView.OnQueryTextListener  {

	private SearchView searchView;
	private ListView lvTitle; 
    private ListView lv; 
    private ArrayList<TableRow> table; 
    private TableCell[] titles;
    private int selectOrderIndex;

	final String strJsonKey_header = "header";
	final String strJsonKey_title = "title";
	final String strJsonKey_width = "width";
	final String strJsonKey_align = "align";
	final String strJsonKey_body = "body";
	public final static String returnKey = "SearchListView_returnKey";
	
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        
    setContentView(R.layout.searchlistview);  
	User user = ((MarketorderApplication)getApplication()).getUser();
	if (user != null)
		this.setTitle(this.getString(R.string.app_name)  + "-" + user.name);
	  
	searchView = (SearchView) findViewById(R.id.search_view);  
    searchView.setOnQueryTextListener(this);  
    searchView.setSubmitButtonEnabled(false); 
	
    //����title
    JSONArray paramsHeader = new JSONArray();
    JSONArray params = PublicMethod.postParam(this.getApplicationContext(), "ORDERSEL", paramsHeader);
	

	lvTitle = (ListView)this.findViewById(R.id.TitleListView);
    lv = (ListView) this.findViewById(R.id.SearchResultListView); 
    
    SharedPreferences settings = SearchListView.this.getSharedPreferences("login", 0);
	String XQLIST_header = settings.getString("XQLIST_header", "");
	String XQLIST = settings.getString("XQLIST", "");
    
    
    if (XQLIST_header.contentEquals("") || XQLIST.contentEquals(""))
    	return ;
    
    JSONObject listJSON = null;
    try {
        table = new ArrayList<TableRow>(); 
    	JSONArray headerJson = new JSONArray(XQLIST_header);
    	JSONObject headerItem;
    	int tGravity;
        ArrayList<TableRow>tableTitle = new ArrayList<TableRow>(); 
        titles = new TableCell[headerJson.length()-1];
        
        for (int i = 0; i<headerJson.length()-1; i++)
        {
        	headerItem =  headerJson.getJSONObject(i+1);
            tGravity = Gravity.LEFT;
            if (headerItem.getString(strJsonKey_align).contentEquals("right"))
            	tGravity = Gravity.RIGHT;
            else if (headerItem.getString(strJsonKey_align).contentEquals("center"))
            	tGravity = Gravity.CENTER;
        	titles[i] = new TableCell(headerItem.getString(strJsonKey_title), 
        			headerItem.getInt(strJsonKey_width),
        			LayoutParams.FILL_PARENT,
        			TableCell.STRING,
        			tGravity);
        }
        tableTitle.add(new TableRow(titles)); 
		
        TableAdapter tableTitleAdapter = new TableAdapter(SearchListView.this, tableTitle, false, true);
        lvTitle.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        lvTitle.setAdapter(tableTitleAdapter); 
        
        //body
		final JSONObject XQLISTObject = new JSONObject(XQLIST);
		@SuppressWarnings("unchecked")
		Iterator<String> it = XQLISTObject.keys();
		JSONArray bodyRow;
    	TableCell[] cells;
    	
    	while(it.hasNext()){
    		bodyRow = XQLISTObject.getJSONArray(it.next().toString());
            cells = new TableCell[bodyRow.length()-1];  
            for (int j = 0; j < cells.length; j++) {
	        	headerItem =  headerJson.getJSONObject(j+1);
                tGravity = Gravity.LEFT;
                if (headerItem.getString(strJsonKey_align).contentEquals("right"))
                	tGravity = Gravity.RIGHT;
                else if (headerItem.getString(strJsonKey_align).contentEquals("center"))
                	tGravity = Gravity.CENTER;
                
                cells[j] = new TableCell(bodyRow.getString(j+1),
                						headerItem.getInt(strJsonKey_width),   
                                        LayoutParams.FILL_PARENT,   
                                        TableCell.STRING,
                                        tGravity);  
            }
        	table.add(new TableRow(cells)); 
        }
		
        TableAdapter tableAdapter = new TableAdapter(SearchListView.this, table, false, false);
        lv.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        lv.setAdapter(tableAdapter);  
        lv.setTextFilterEnabled(true);  

        lv.setOnItemClickListener(new itemClickEvent());
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}      
	

    findViewById(R.id.buttonBack).setOnClickListener(new OnClickListener()
    {

		@Override
		public void onClick(View v) {
//			SearchResultView.this.setResult(FunctionList.MenuResult);
			SearchListView.this.finish();
		}
    });
}
class itemClickEvent implements AdapterView.OnItemClickListener {  
        

		@Override  
        public void onItemClick(AdapterView<?> arg0, View tableRowView, int index,  
                long arg3) {  
			selectOrderIndex = index;
        	String name = ((TableAdapter)lv.getAdapter()).getItem(index).getCellValue(0).value.toString();
			Intent resultIntent = new Intent();
			Bundle newbundle = new Bundle();
			newbundle.putString(SearchListView.returnKey, name);
			resultIntent.putExtras(newbundle);
			SearchListView.this.setResult(RESULT_OK, resultIntent);
			SearchListView.this.finish();
        }  
        
    }
@Override
public boolean onQueryTextChange(String newText) {
	if (TextUtils.isEmpty(newText)) {  
        // Clear the text filter.  
        lv.clearTextFilter();  
    } else {  
        // Sets the initial value for the text filter.  
    	lv.setFilterText(newText.toString());  
    }  
    return false;
}
@Override
public boolean onQueryTextSubmit(String query) {
	// TODO Auto-generated method stub
	return false;
}
}
