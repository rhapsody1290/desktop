package com.shon.marketorder3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Spinner; 

public class CustomerInfo extends Activity {
	private String returnResult = "";
	private String listStatus = "����";
    private Spinner spinner;  
    private ArrayAdapter<String> adapter; 
    private static int selectOrderTypeID = 0;
    private String[] orderTypeID;
    private String[] orderTypeName;
    private LinearLayout mAddconditionLinearLayout;
    EditText editTextCustomerAddress;
    EditText editTextCity;
    EditText editTextCounty;
    ConditionRadio CommunityName;

	final String strJsonKey_type = "type";
	final String strJsonKey_title = "title";
	final String strJsonKey_mandatory = "mandatory";
	final String strJsonKey_isOnlyRead = "isOnlyRead";
	final String strJsonKey_defaultvalue = "defaultvalue";
	final String strJsonKey_isNotSubmit = "isNotSubmit";
	final String strJsonKey_selectItem = "selectItem";
	final String strJsonKey_condition = "condition";

	final String strType_text = "text";
	final String strType_date = "date";
	final String strType_radio = "radio";
	
	@Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        
        setContentView(R.layout.customerinfo);  
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);

		JSONArray params = PublicMethod.postParam(CustomerInfo.this, "ORDTYPE", new JSONArray());

		String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
		if (result == null || result.isEmpty())
			return;

    	try {
    		JSONArray jsonCheckResult = new JSONArray(result);
	        if (jsonCheckResult.length() < 2 || jsonCheckResult.getString(0).contains("ERROR"))
	        {
	        	if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).length() >=1)
	        		PublicMethod.displayToast(CustomerInfo.this, jsonCheckResult.getJSONArray(1).getString(0));
	        	return;
	        }
	        else if (jsonCheckResult.length() >= 2 || jsonCheckResult.getJSONArray(1).length() >= 2)
	        {
	        	orderTypeID = new String[jsonCheckResult.length()-2];
	        	orderTypeName = new String[jsonCheckResult.length()-2];
	        	for (int i = 2; i<jsonCheckResult.length(); i++)
	        	{
	        		orderTypeID[i-2] = jsonCheckResult.getJSONArray(i).getString(0);
	        		orderTypeName[i-2] = jsonCheckResult.getJSONArray(i).getString(1);
	        	}
	        }
	    } catch (JSONException e) {  
//	    	Log.e(CustomerInfo.DEBUG_TAG, "error while buttonSearch OnClickListener:" + e.getMessage());
	    	return;
	    }

		spinner = (Spinner) findViewById(R.id.SpinnerOrderType);
        //����ѡ������ArrayAdapter��������  
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,orderTypeName);  
          
        //���������б��ķ��  
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
          
        //��adapter ���ӵ�spinner��  
        spinner.setAdapter(adapter);  
          
        //�����¼�Spinner�¼�����    
        spinner.setOnItemSelectedListener(new SpinnerSelectedListener()); 
		
        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				CustomerInfo.this.setResult(FunctionList.MenuResult);
				CustomerInfo.this.finish();
			}
        });


		editTextCustomerAddress = (EditText)findViewById(R.id.editTextCustomerAddress);
		editTextCity = (EditText)findViewById(R.id.editTextCity);
		editTextCounty = (EditText)findViewById(R.id.editTextCounty);
		RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioGroup1);
		
		//��ѡ��ť����һ�飩
		final RadioButton radioButtonActual = (RadioButton)findViewById(R.id.radioButtonActual);
		final RadioButton radioButtonPurpose = (RadioButton)findViewById(R.id.radioButtonPurpose);
		
		radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
		    
		    @Override
		    public void onCheckedChanged(RadioGroup arg0, int checkID) {
			if(radioButtonActual.getId() == checkID) {
				listStatus = "ʵ��";
			}else if(radioButtonPurpose.getId() == checkID) {
				listStatus = "����";
			}
		    }
		});
        
		TextView textViewTotalMoney = (TextView) findViewById(R.id.textViewTotalMoney);
		String totalMoney = this.getIntent().getStringExtra(this.getString(R.string.string_key_totalMoney));
		if (totalMoney != null)
		{
			textViewTotalMoney.setText("�ܽ�" + totalMoney);
		}
		else 
			textViewTotalMoney.setVisibility(View.GONE);

		TextView textViewTotalWeight = (TextView) findViewById(R.id.textViewTotalWeight);
		String totalWeight = this.getIntent().getStringExtra(this.getString(R.string.string_key_totalWeight));
		if (totalWeight != null)
		{
			textViewTotalWeight.setVisibility(View.VISIBLE);
			textViewTotalWeight.setText("������(����)��" + totalWeight);
		}
		else 
			textViewTotalWeight.setVisibility(View.GONE);
		
		// ����ɱ���
		mAddconditionLinearLayout = (LinearLayout)findViewById(R.id.addconditionLinearLayout);
		JSONArray paramsHeader = new JSONArray();
		params = PublicMethod.postParam(this.getApplicationContext(), "ORDERSEL", paramsHeader);
		result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());//"[\,\"\",[\"\",\"95322\",\"OWNER\",\"AA\"]]");
		if (result == null || result.isEmpty())
		{
        	PublicMethod.displayToast(this.getApplicationContext(), "error while " + "ORDERSEL" + " :" + result);
			return;
		}
		
    	try {
    		JSONObject jsonCheckResult = new JSONObject(result);
	        if (jsonCheckResult.has("ERROR"))
	        {
	        	PublicMethod.displayToast(this.getApplicationContext(), jsonCheckResult.getString("ERROR"));
	        	return;
	        }
	        layoutSearchCondition(result);
            
	    } catch (JSONException e) {  
	    	Log.e(FullscreenActivity.TAG, "error while login:" + e.getMessage());
        	return;
	    }
    	
		
        findViewById(R.id.buttonCreatBook).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				JSONArray paramsHeader = new JSONArray();
				EditText editTextCustomerName = (EditText)findViewById(R.id.editTextCustomerName);
				paramsHeader.put(editTextCustomerName.getText().toString().trim());
				EditText editTextCustomerPhone = (EditText)findViewById(R.id.editTextCustomerPhone);
				paramsHeader.put(editTextCustomerPhone.getText().toString().trim());
				paramsHeader.put(editTextCustomerAddress.getText().toString().trim());
				DatePicker datePickerPlanDate = (DatePicker)findViewById(R.id.datePickerPlanDate);
				datePickerPlanDate.clearFocus();
				paramsHeader.put(String.format("%04d%02d%02d", datePickerPlanDate.getYear(), datePickerPlanDate.getMonth()+1,datePickerPlanDate.getDayOfMonth()));
				EditText editTextComment = (EditText)findViewById(R.id.editTextComment);
				paramsHeader.put(editTextComment.getText().toString().trim());
				paramsHeader.put(editTextCity.getText().toString().trim());
				paramsHeader.put(editTextCounty.getText().toString().trim());
				EditText editTextLinkman = (EditText)findViewById(R.id.editTextLinkman);
				paramsHeader.put(editTextLinkman.getText().toString().trim());
				EditText editTextLinkmanPhone = (EditText)findViewById(R.id.editTextLinkmanPhone);
				paramsHeader.put(editTextLinkmanPhone.getText().toString().trim());
				paramsHeader.put(listStatus);
				TextView textViewFirstCode = (TextView)findViewById(R.id.textViewFirstCode);
				textViewFirstCode.setVisibility(View.VISIBLE);
				EditText editTextFirstCode = (EditText)findViewById(R.id.editTextFirstCode);
				editTextFirstCode.setVisibility(View.VISIBLE);
				TextView textViewFirstLinkman = (TextView)findViewById(R.id.textViewFirstLinkman);
				textViewFirstLinkman.setVisibility(View.VISIBLE);
				EditText editTextFirstLinkman = (EditText)findViewById(R.id.editTextFirstLinkman);
				editTextFirstLinkman.setVisibility(View.VISIBLE);
				paramsHeader.put(editTextFirstCode.getText().toString().trim());
				paramsHeader.put(editTextFirstLinkman.getText().toString().trim());
				paramsHeader.put(orderTypeID[selectOrderTypeID].trim());

//				TextView textViewParticipateActivity = (TextView)findViewById(R.id.textViewParticipateActivity);
//				textViewParticipateActivity.setVisibility(View.VISIBLE);
//				EditText editTextParticipateActivity = (EditText)findViewById(R.id.editTextParticipateActivity);
//				editTextParticipateActivity.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextParticipateActivity.getText().toString().trim());
//				TextView textViewDecorateArea = (TextView)findViewById(R.id.textViewDecorateArea);
//				textViewDecorateArea.setVisibility(View.VISIBLE);
//				EditText editTextDecorateArea = (EditText)findViewById(R.id.editTextDecorateArea);
//				editTextDecorateArea.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextDecorateArea.getText().toString().trim());
//				TextView textViewPropertyClassification = (TextView)findViewById(R.id.textViewPropertyClassification);
//				textViewPropertyClassification.setVisibility(View.VISIBLE);
//				EditText editTextPropertyClassification = (EditText)findViewById(R.id.editTextPropertyClassification);
//				editTextPropertyClassification.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextPropertyClassification.getText().toString().trim());
//				TextView textViewDecorateExperience = (TextView)findViewById(R.id.textViewDecorateExperience);
//				textViewDecorateExperience.setVisibility(View.VISIBLE);
//				EditText editTextDecorateExperience = (EditText)findViewById(R.id.editTextDecorateExperience);
//				editTextDecorateExperience.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextDecorateExperience.getText().toString().trim());
//				TextView textViewUseCount = (TextView)findViewById(R.id.textViewUseCount);
//				textViewUseCount.setVisibility(View.VISIBLE);
//				EditText editTextUseCount = (EditText)findViewById(R.id.editTextUseCount);
//				editTextUseCount.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextUseCount.getText().toString().trim());
//				TextView textViewGender = (TextView)findViewById(R.id.textViewGender);
//				textViewGender.setVisibility(View.VISIBLE);
//				EditText editTextGender = (EditText)findViewById(R.id.editTextGender);
//				editTextGender.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextGender.getText().toString().trim());
//				
//				TextView textViewAgeRange = (TextView)findViewById(R.id.textViewAgeRange);
//				textViewAgeRange.setVisibility(View.VISIBLE);
//				EditText editTextAgeRange = (EditText)findViewById(R.id.editTextAgeRange);
//				editTextAgeRange.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextAgeRange.getText().toString().trim());
//				TextView textViewJob = (TextView)findViewById(R.id.textViewJob);
//				textViewJob.setVisibility(View.VISIBLE);
//				EditText editTextJob = (EditText)findViewById(R.id.editTextJob);
//				editTextJob.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextJob.getText().toString().trim());
//				TextView textViewDecider = (TextView)findViewById(R.id.textViewDecider);
//				textViewDecider.setVisibility(View.VISIBLE);
//				EditText editTextDecider = (EditText)findViewById(R.id.editTextDecider);
//				editTextDecider.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextDecider.getText().toString().trim());
//				TextView textViewVillage = (TextView)findViewById(R.id.textViewVillage);
//				textViewVillage.setVisibility(View.VISIBLE);
//				EditText editTextVillage = (EditText)findViewById(R.id.editTextVillage);
//				editTextVillage.setVisibility(View.VISIBLE);
//				paramsHeader.put(editTextVillage.getText().toString().trim());
//				params.put(paramsHeader);
				if (editTextCustomerName.getText().length() == 0 || editTextCustomerName.getText().toString().trim() == "")
				{
					PublicMethod.displayToast(CustomerInfo.this, "�ͻ����Ʋ��ܿ�");
		        	return ;
				}
				if (editTextCustomerPhone.getText().length() == 0 || editTextCustomerPhone.getText().toString().trim() == "")
				{
					PublicMethod.displayToast(CustomerInfo.this, "�ͻ��绰���ܿ�");
		        	return ;
				}
				if (editTextCustomerAddress.getText().length() == 0 || editTextCustomerAddress.getText().toString().trim() == "")
				{
					PublicMethod.displayToast(CustomerInfo.this, "�ͻ���ַ���ܿ�");
		        	return ;
				}

				//С����
				paramsHeader.put(CommunityName.getText());
				
				//�ɱ�
				ConditionInterface conditionInterface;
				for (int linearLayoutLeftIndex = 0; linearLayoutLeftIndex < mAddconditionLinearLayout.getChildCount(); linearLayoutLeftIndex++)
				{
					conditionInterface = (ConditionInterface) mAddconditionLinearLayout.getChildAt(linearLayoutLeftIndex);
					if (!conditionInterface.checkMandatory())
						return;
					if (!conditionInterface.getIsNotSubmit())
						paramsHeader.put(conditionInterface.getText());
				}
					
				JSONArray params = PublicMethod.postParam(CustomerInfo.this, "ORDERCRT", paramsHeader);
				int line = 1;
				for (int i = 0; i < Inventory.tableShoppingCart.size(); i++)
				{
					TableRow tableRow = Inventory.tableShoppingCart.get(i);
					
					if (!tableRow.isChecked)
						continue;
					
					JSONArray paramsRow = new JSONArray();
					paramsRow.put(String.valueOf(line));
					paramsRow.put(tableRow.purpose);
					paramsRow.put(tableRow.getCellValue(1).value);
					paramsRow.put(tableRow.getCellValue(2).value);
					paramsRow.put(tableRow.getCellValue(9).value);
					paramsRow.put(tableRow.getCellValue(3).value);
					paramsRow.put(tableRow.quantity);
					paramsRow.put(tableRow.price);
					float totalPrice = 0;
					if (!tableRow.quantity.isEmpty() && !tableRow.price.isEmpty())
					{
						totalPrice = (Float.valueOf(tableRow.price).floatValue()+Float.valueOf(tableRow.getCellValue(6).value.toString()))*Float.valueOf(tableRow.quantity).intValue();
						BigDecimal b = new BigDecimal(totalPrice);  
						totalPrice  = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();  
					}
					paramsRow.put(String.format("%.02f", totalPrice));
					paramsRow.put(tableRow.remark);
					paramsRow.put(tableRow.isGift);
					paramsRow.put(tableRow.getCellValue(6).value);

					params.put(paramsRow);
					line++;
				}
				if (line == 1)
				{	
					PublicMethod.displayToast(CustomerInfo.this, "��ѡ��Ҫ���빺�ﳵ����");
					return ;
				}
				String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
				if (result == null || result.isEmpty())
					return ;

		    	try {
		    		JSONArray jsonCheckResult = new JSONArray(result);
			        if (jsonCheckResult.length() < 2 || jsonCheckResult.getString(0).contains("ERROR"))
			        {
			        	if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).length() >=1)
			        		PublicMethod.displayToast(CustomerInfo.this, jsonCheckResult.getJSONArray(1).getString(0));
			        	return ;
			        }
//			        else if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).getString(0).equals("0"))
//			        {
//			        	PublicMethod.displayToast(CustomerInfo.this, jsonCheckResult.getJSONArray(1).getString(1));
//			        	return ;
//			        }
			        else
			        {
			        	returnResult = jsonCheckResult.getJSONArray(1).getString(0);
			        	Dialog dialog = new AlertDialog.Builder(CustomerInfo.this)
			        					.setTitle(R.string.string_prompt)
			        					.setMessage( String.format("�����ţ�%s���Ƿ��ѯ,%s", returnResult, jsonCheckResult.getJSONArray(1).getString(1)))
			        					.setPositiveButton(R.string.string_ok, 
			        							new DialogInterface.OnClickListener() {
			    			
			    									@Override
			    									public void onClick(DialogInterface dialog, int which) {
			    										// TODO Auto-generated method stub
			    										Intent resultIntent = new Intent();
			    										Bundle bundle = new Bundle();
			    										bundle.putString("result", returnResult);
			    										resultIntent.putExtras(bundle);
			    										CustomerInfo.this.setResult(RESULT_OK, resultIntent);
			    										CustomerInfo.this.finish();
			    									}
			    								})
			    								.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			    			
			    									@Override
			    									public void onClick(DialogInterface dialog, int which) {
			    										// TODO Auto-generated method stub
//			    										Intent resultIntent = new Intent();
//			    										Bundle bundle = new Bundle();
//			    										bundle.putString("result", returnResult);
//			    										resultIntent.putExtras(bundle);
			    										CustomerInfo.this.setResult(EnterConditionView.ChangeConditionResult);
			    										CustomerInfo.this.finish();
			    									}
			    								}).create();
			        	dialog.show();
//			        	Inventory.tableShoppingCart.clear();
			        	PublicMethod.displayToast(CustomerInfo.this, "���������ɹ�");
			        	for (int i = 0; i < Inventory.tableShoppingCart.size(); )
						{
							TableRow tableRow = Inventory.tableShoppingCart.get(i);
							
							if (tableRow.isChecked)
							{
								Inventory.tableShoppingCart.remove(i);
								continue;
							}
							
							i++;
						}
			        	Inventory.saveShoppingCartTable(CustomerInfo.this);
			        }
			    } catch (JSONException e) {  
			    	Log.e(FullscreenActivity.DEBUG_TAG, "error while buttonCreatBook OnClickListener:" + e.getMessage());
			    }
			}
        	
        });
	}
	private void layoutSearchCondition(String strConditionSearch)
	{
        JSONArray conditionList;
		String type;
		String title;
		LinearLayout conditionLinearLayout = null;
		ConditionInterface conditionInterface = null;
		ConditionText conditionText;
		ConditionDate conditionDate;
		ConditionRadio conditionRadio;
		
		try {
			JSONObject conditionSearchObject = new JSONObject(strConditionSearch);
//			strConditionSearchType = conditionSearchObject.getString(strJsonKey_type);
			conditionList = conditionSearchObject.getJSONArray(strJsonKey_condition);
			
			JSONObject itemObject;
			JSONArray selectItem;
	        for (int conditionListIndex=0; conditionListIndex<conditionList.length(); conditionListIndex++)
	        {
	        	itemObject = conditionList.getJSONObject(conditionListIndex);
	        	
	        	// type
	        	type = itemObject.getString(strJsonKey_type);
	        	//text
	        	if (strType_text.contentEquals(type))
	        	{
	        		conditionText = new ConditionText(this);
	        		conditionLinearLayout = conditionText;
	        		conditionInterface = conditionText;
	        		
		        	// defaultvalue
		        	if (itemObject.has(strJsonKey_defaultvalue))
		        	{
		        		conditionText.setText(itemObject.getString(strJsonKey_defaultvalue));
		        	}

		        	// isMandatory
		        	if (itemObject.has(strJsonKey_mandatory))
		        		conditionText.isMandatory = itemObject.getBoolean(strJsonKey_mandatory);
		        	
		        	// isOnlyRead
		        	if (itemObject.has(strJsonKey_isOnlyRead))
		        		conditionText.setEnable(!itemObject.getBoolean(strJsonKey_isOnlyRead));
	        	}
	        	//date
	        	else if (strType_date.contentEquals(type))
	        	{
	        		conditionDate = new ConditionDate(this);
	        		conditionLinearLayout = conditionDate;
	        		conditionInterface = conditionDate;

		        	// defaultvalue
		        	if (itemObject.has(strJsonKey_defaultvalue))
		        	{
		        		String defaultValue = itemObject.getString(strJsonKey_defaultvalue);
		        		conditionDate.setDate(defaultValue);
		        	}
	        	}
	        	//radio
	        	else if (strType_radio.contentEquals(type))
	        	{
	        		conditionRadio = new ConditionRadio(this);
	        		conditionLinearLayout = conditionRadio;
	        		conditionInterface = conditionRadio;
	        		if (itemObject.getString(strJsonKey_title).contentEquals("С������"))
	        		{
		        		CommunityName = conditionRadio;

	        			selectItem = new JSONArray();
	        			SharedPreferences settings = CustomerInfo.this.getSharedPreferences("login", 0);  
	        			String XQLISTString = settings.getString("XQLIST", "");
	        			final JSONObject XQLISTObject = new JSONObject(XQLISTString);
	        			@SuppressWarnings("unchecked")
						Iterator<String> it = XQLISTObject.keys();
	                    while(it.hasNext()){
	                    	selectItem.put(it.next().toString());
	                    }
	                    conditionRadio.setOnClickListener(new OnClickListener(){
	            			@Override
	            			public void onClick(View v) { 
	            				Intent ChangeSaveIntent = new Intent(CustomerInfo.this, SearchListView.class);
	            	            CustomerInfo.this.startActivityForResult(ChangeSaveIntent, EnterConditionView.ChangeConditionResult);
	            			}
	            			
	            		});
	        		}
	        		else
	        			selectItem = itemObject.getJSONArray(strJsonKey_selectItem);
	        		List<String> selectList = new ArrayList<String>();
	        		for (int selectItemIndex=0; selectItemIndex < selectItem.length(); selectItemIndex++)
	        			selectList.add(selectItem.getString(selectItemIndex));
	        		conditionRadio.setSelectItem(selectList);

		        	// defaultvalue
		        	if (itemObject.has(strJsonKey_defaultvalue))
		        		conditionRadio.setText(itemObject.getString(strJsonKey_defaultvalue));
	        	}

	        	// title
	        	title = itemObject.getString(strJsonKey_title);
	        	conditionInterface.setTitle(title);
	        	
	        	// isNotSubmit
	        	if (itemObject.has(strJsonKey_isNotSubmit))
	        		conditionInterface.setIsNotSubmit(itemObject.getBoolean(strJsonKey_isNotSubmit));

	        	// addview
	        	if (itemObject.getString(strJsonKey_title).contentEquals("С������"))
	        	{
	        		LinearLayout FixedLinearLayout = (LinearLayout)findViewById(R.id.FixedLinearLayout);
	        		FixedLinearLayout.addView(conditionLinearLayout, 11);
	        	}
	        	else
	        		mAddconditionLinearLayout.addView(conditionLinearLayout);
	        }
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

    //ʹ��������ʽ����  
    class SpinnerSelectedListener implements OnItemSelectedListener{  
  
		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			CustomerInfo.selectOrderTypeID = arg2;
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}  
    }  

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString(SearchListView.returnKey);
			try {
				SharedPreferences settings = CustomerInfo.this.getSharedPreferences("login", 0);  
    			String XQLISTString = settings.getString("XQLIST", "");
    			final JSONObject XQLISTObject = new JSONObject(XQLISTString);
				JSONArray array = XQLISTObject.getJSONArray(returnResult);
				//С����
				CommunityName.setText(returnResult);
				//����
				editTextCity.setText(array.getString(2));
				//����
				editTextCounty.setText(array.getString(3));
				//��ַ
				editTextCustomerAddress.setText(array.getString(4));
				ConditionInterface conditionInterface;
				for (int linearLayoutLeftIndex = 0; linearLayoutLeftIndex < mAddconditionLinearLayout.getChildCount() && linearLayoutLeftIndex < 4; linearLayoutLeftIndex++)
				{
					String value = array.getString(5 + linearLayoutLeftIndex);
					conditionInterface = (ConditionInterface) mAddconditionLinearLayout.getChildAt(linearLayoutLeftIndex);
					if (conditionInterface.getClass().equals(ConditionText.class))
						((ConditionText)conditionInterface).setText(value);
					else if (conditionInterface.getClass().equals(ConditionRadio.class))
						((ConditionRadio)conditionInterface).setText(value);
					else if (conditionInterface.getClass().equals(ConditionDate.class))
						((ConditionDate)conditionInterface).setDate(value);
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
