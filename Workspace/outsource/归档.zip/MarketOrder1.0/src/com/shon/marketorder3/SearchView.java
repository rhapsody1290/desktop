package com.shon.marketorder3;

import org.json.JSONArray;
import org.json.JSONException;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.shon.marketorder3.mk.R;

public class SearchView extends Activity {
	
	private String searchType = "";
	private EditText editTextOrderNumber;
	private EditText editTextPickNumber;
	private EditText editTextOrderIssueNumber;
	private EditText editTextOrderPayNumber;
	private EditText editTextCustomerName;
	private EditText editTextCustomerPhone;
	private EditText editTextCustomerAddress;
	private EditText editTextProductCode;
	private EditText editTextProductName;
	private EditText editTextProductNumber;
	private DatePicker datePickerBeginDate;
	private DatePicker datePickerEndDate;
	private EditText editTextLinkman;
	private EditText editTextLinkmanPhone;
	private RadioGroup radioGroupStatus;
	
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        searchType = this.getIntent().getStringExtra(this.getString(R.string.string_key_searchType));
        setContentView(R.layout.searchview); 
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
		
        
        Button buttonSearchBook = (Button)findViewById(R.id.buttonSearchBook);
        buttonSearchBook.setOnClickListener(buttonOnClickListener);
        
        editTextOrderNumber = (EditText)findViewById(R.id.editTextOrderNumber);
        String string_key_orderCode = this.getIntent().getStringExtra(this.getString(R.string.string_key_orderCode));
        if (string_key_orderCode != null)
        	editTextOrderNumber.setText(string_key_orderCode);
        
        TextView textViewPickNumber = (TextView)findViewById(R.id.textViewPickNumber);
        editTextPickNumber = (EditText)findViewById(R.id.editTextPickNumber);
        TextView textViewOrderIssueNumber = (TextView)findViewById(R.id.textViewOrderIssueNumber);
        editTextOrderIssueNumber = (EditText)findViewById(R.id.editTextOrderIssueNumber);
        TextView textViewOrderPayNumber = (TextView)findViewById(R.id.textViewOrderPayNumber);
        editTextOrderPayNumber = (EditText)findViewById(R.id.editTextOrderPayNumber);
        editTextCustomerName = (EditText)findViewById(R.id.editTextCustomerName);
        editTextCustomerPhone = (EditText)findViewById(R.id.editTextCustomerPhone);
        editTextCustomerAddress = (EditText)findViewById(R.id.editTextCustomerAddress);
        TextView textViewProductCode = (TextView )findViewById(R.id.textViewProductCode);
        editTextProductCode = (EditText)findViewById(R.id.editTextProductCode);
        TextView textViewProductName = (TextView )findViewById(R.id.textViewProductName);
        editTextProductName = (EditText)findViewById(R.id.editTextProductName);
        TextView textViewProductNumber = (TextView )findViewById(R.id.textViewProductNumber);
        editTextProductNumber = (EditText)findViewById(R.id.editTextProductNumber);
        datePickerBeginDate = (DatePicker)findViewById(R.id.datePickerBeginDate);
        datePickerEndDate = (DatePicker)findViewById(R.id.datePickerEndDate);
        editTextLinkman = (EditText)findViewById(R.id.editTextLinkman);
        editTextLinkmanPhone = (EditText)findViewById(R.id.editTextLinkmanPhone);
        radioGroupStatus = (RadioGroup)findViewById(R.id.radioGroupStatus);
        
        if (searchType.contentEquals("ORDERLIST"))
        {
        	textViewPickNumber.setVisibility(View.GONE);
        	editTextPickNumber.setVisibility(View.GONE);
        	textViewOrderIssueNumber.setVisibility(View.GONE);
        	editTextOrderIssueNumber.setVisibility(View.GONE);
        	textViewOrderPayNumber.setVisibility(View.GONE);
        	editTextOrderPayNumber.setVisibility(View.GONE);
        	textViewProductCode.setVisibility(View.VISIBLE);
        	editTextProductCode.setVisibility(View.VISIBLE);
        	textViewProductName.setVisibility(View.VISIBLE);
        	editTextProductName.setVisibility(View.VISIBLE);
        	textViewProductNumber.setVisibility(View.GONE);
        	editTextProductNumber.setVisibility(View.GONE);
        	radioGroupStatus.setVisibility(View.VISIBLE);
        }
        else if (searchType.contentEquals("PICKLIST"))
        {
        	textViewPickNumber.setVisibility(View.VISIBLE);
        	editTextPickNumber.setVisibility(View.VISIBLE);
        	textViewOrderIssueNumber.setVisibility(View.GONE);
        	editTextOrderIssueNumber.setVisibility(View.GONE);
        	textViewOrderPayNumber.setVisibility(View.GONE);
        	editTextOrderPayNumber.setVisibility(View.GONE);
        	textViewProductCode.setVisibility(View.VISIBLE);
        	editTextProductCode.setVisibility(View.VISIBLE);
        	textViewProductName.setVisibility(View.VISIBLE);
        	editTextProductName.setVisibility(View.VISIBLE);
        	textViewProductNumber.setVisibility(View.VISIBLE);
        	editTextProductNumber.setVisibility(View.VISIBLE);
        	radioGroupStatus.setVisibility(View.GONE);
        }
        else if (searchType.contentEquals("ORDERISSUE"))
        {
        	textViewPickNumber.setVisibility(View.VISIBLE);
        	editTextPickNumber.setVisibility(View.VISIBLE);
        	textViewOrderIssueNumber.setVisibility(View.VISIBLE);
        	editTextOrderIssueNumber.setVisibility(View.VISIBLE);
        	textViewOrderPayNumber.setVisibility(View.GONE);
        	editTextOrderPayNumber.setVisibility(View.GONE);
        	textViewProductCode.setVisibility(View.VISIBLE);
        	editTextProductCode.setVisibility(View.VISIBLE);
        	textViewProductName.setVisibility(View.VISIBLE);
        	editTextProductName.setVisibility(View.VISIBLE);
        	textViewProductNumber.setVisibility(View.GONE);
        	editTextProductNumber.setVisibility(View.GONE);
        	radioGroupStatus.setVisibility(View.GONE);
        }
        else if (searchType.contentEquals("ORDERPAY"))
        {
        	textViewPickNumber.setVisibility(View.GONE);
        	editTextPickNumber.setVisibility(View.GONE);
        	textViewOrderIssueNumber.setVisibility(View.GONE);
        	editTextOrderIssueNumber.setVisibility(View.GONE);
        	textViewOrderPayNumber.setVisibility(View.VISIBLE);
        	editTextOrderPayNumber.setVisibility(View.VISIBLE);
        	textViewProductCode.setVisibility(View.GONE);
        	editTextProductCode.setVisibility(View.GONE);
        	textViewProductName.setVisibility(View.GONE);
        	editTextProductName.setVisibility(View.GONE);
        	textViewProductNumber.setVisibility(View.GONE);
        	editTextProductNumber.setVisibility(View.GONE);
        	radioGroupStatus.setVisibility(View.GONE);
        }
        else if (searchType.contentEquals("ORDERTRACE"))
        {
        	textViewPickNumber.setVisibility(View.GONE);
        	editTextPickNumber.setVisibility(View.GONE);
        	textViewOrderIssueNumber.setVisibility(View.GONE);
        	editTextOrderIssueNumber.setVisibility(View.GONE);
        	textViewOrderPayNumber.setVisibility(View.GONE);
        	editTextOrderPayNumber.setVisibility(View.GONE);
        	textViewProductCode.setVisibility(View.GONE);
        	editTextProductCode.setVisibility(View.GONE);
        	textViewProductName.setVisibility(View.GONE);
        	editTextProductName.setVisibility(View.GONE);
        	textViewProductNumber.setVisibility(View.GONE);
        	editTextProductNumber.setVisibility(View.GONE);
        	radioGroupStatus.setVisibility(View.VISIBLE);
        }
        else if (searchType.contentEquals("REBATELIST"))
        {
        	TextView textViewOrderNumber = (TextView )findViewById(R.id.textViewOrderNumber);
        	textViewOrderNumber.setText("��������");
        	textViewPickNumber.setText("�ŵ�");
        	textViewOrderIssueNumber.setVisibility(View.GONE);
        	editTextOrderIssueNumber.setVisibility(View.GONE);
        	textViewOrderPayNumber.setVisibility(View.GONE);
        	editTextOrderPayNumber.setVisibility(View.GONE);
        	textViewProductCode.setVisibility(View.GONE);
        	editTextProductCode.setVisibility(View.GONE);
        	textViewProductName.setVisibility(View.GONE);
        	editTextProductName.setVisibility(View.GONE);
        	textViewProductNumber.setVisibility(View.GONE);
        	editTextProductNumber.setVisibility(View.GONE);
        	TextView textViewLinkman = (TextView )findViewById(R.id.textViewLinkman);
        	textViewLinkman.setText("�����ֻ�");
        	TextView textViewLinkmanPhone = (TextView )findViewById(R.id.textViewLinkmanPhone);
        	textViewLinkmanPhone.setText("״̬");
        	radioGroupStatus.setVisibility(View.GONE);
        }
        else if (searchType.contentEquals("PLANLIST"))
        {			
        	radioGroupStatus.setVisibility(View.GONE);
        	TextView textViewOrderNumber = (TextView )findViewById(R.id.textViewOrderNumber);
        	textViewOrderNumber.setText("����");
        	textViewPickNumber.setText("������");
        	textViewOrderIssueNumber.setVisibility(View.VISIBLE);
        	textViewOrderIssueNumber.setText("Ʒ��");
        	editTextOrderIssueNumber.setVisibility(View.VISIBLE);
        	textViewOrderPayNumber.setVisibility(View.VISIBLE);
        	textViewOrderPayNumber.setText("��Ʒϵ��");
        	editTextOrderPayNumber.setVisibility(View.VISIBLE);
        	TextView textViewCustomerName = (TextView )findViewById(R.id.textViewCustomerName);
        	textViewCustomerName.setText("��Ʒ���");
        	TextView textViewCustomerPhone = (TextView )findViewById(R.id.textViewCustomerPhone);
        	textViewCustomerPhone.setText("��Ʒ����");
        	TextView textViewCustomerAddress = (TextView )findViewById(R.id.textViewCustomerAddress);
        	textViewCustomerAddress.setVisibility(View.GONE);
        	editTextCustomerAddress.setVisibility(View.GONE);
        	textViewProductCode.setVisibility(View.GONE);
        	editTextProductCode.setVisibility(View.GONE);
        	textViewProductName.setVisibility(View.GONE);
        	editTextProductName.setVisibility(View.GONE);
        	textViewProductNumber.setVisibility(View.GONE);
        	editTextProductNumber.setVisibility(View.GONE);
        	TextView textViewBeginDate = (TextView )findViewById(R.id.textViewBeginDate);
        	textViewBeginDate.setVisibility(View.GONE);
        	datePickerBeginDate.setVisibility(View.GONE);
        	TextView textViewEndDate = (TextView )findViewById(R.id.textViewEndDate);
        	textViewEndDate.setVisibility(View.GONE);
        	datePickerEndDate.setVisibility(View.GONE);
        	TextView textViewLinkman = (TextView )findViewById(R.id.textViewLinkman);
        	textViewLinkman.setVisibility(View.GONE);
        	editTextLinkman.setVisibility(View.GONE);
        	TextView textViewLinkmanPhone = (TextView )findViewById(R.id.textViewLinkmanPhone);
        	textViewLinkmanPhone.setVisibility(View.GONE);
        	editTextLinkmanPhone.setVisibility(View.GONE);
        }
        

        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				SearchView.this.setResult(FunctionList.MenuResult);
				SearchView.this.finish();
			}
        });
         
    }
    
    private OnClickListener buttonOnClickListener = new OnClickListener()
    {

		@Override
		public void onClick(View v) {
			JSONArray paramsHeader = new JSONArray();
			if (searchType.contentEquals("PLANLIST"))
			{
				paramsHeader.put(editTextOrderNumber.getText().toString().trim());
				paramsHeader.put(editTextPickNumber.getText().toString().trim());
				paramsHeader.put(editTextOrderIssueNumber.getText().toString().trim());
				paramsHeader.put(editTextOrderPayNumber.getText().toString().trim());
				paramsHeader.put(editTextCustomerName.getText().toString().trim());
				paramsHeader.put(editTextCustomerPhone.getText().toString().trim());
			}
			else 
			{
				paramsHeader.put(editTextOrderNumber.getText().toString().trim());
				if (editTextPickNumber.getVisibility() == View.VISIBLE)
					paramsHeader.put(editTextPickNumber.getText().toString().trim());
				if (editTextOrderIssueNumber.getVisibility() == View.VISIBLE)
					paramsHeader.put(editTextOrderIssueNumber.getText().toString().trim());
				if (editTextOrderPayNumber.getVisibility() == View.VISIBLE)
					paramsHeader.put(editTextOrderPayNumber.getText().toString().trim());
				paramsHeader.put(editTextCustomerName.getText().toString().trim());
				paramsHeader.put(editTextCustomerPhone.getText().toString().trim());
				paramsHeader.put(editTextCustomerAddress.getText().toString().trim());
				if (editTextProductCode.getVisibility() == View.VISIBLE)
					paramsHeader.put(editTextProductCode.getText().toString().trim());
				if (editTextProductName.getVisibility() == View.VISIBLE)
					paramsHeader.put(editTextProductName.getText().toString().trim());
				datePickerBeginDate.clearFocus();
				datePickerEndDate.clearFocus();
				paramsHeader.put(String.format("%04d%02d%02d", datePickerBeginDate.getYear(), datePickerBeginDate.getMonth()+1,datePickerBeginDate.getDayOfMonth()));
				paramsHeader.put(String.format("%04d%02d%02d", datePickerEndDate.getYear(), datePickerEndDate.getMonth()+1,datePickerEndDate.getDayOfMonth()));
				paramsHeader.put(editTextLinkman.getText().toString().trim());
				paramsHeader.put(editTextLinkmanPhone.getText().toString().trim());
				if (radioGroupStatus.getVisibility() == View.VISIBLE)
				{
					RadioButton radioButton = (RadioButton)findViewById(R.id.radioButtonAll);
					if (!radioButton.isChecked())
					{
						radioButton = (RadioButton)findViewById(R.id.radioButtonPurpose);
						if (!radioButton.isChecked())
						{
							radioButton = (RadioButton)findViewById(R.id.radioButtonActual);
							if (!radioButton.isChecked())
							{
								radioButton = (RadioButton)findViewById(R.id.radioButtonApprove);
								if (!radioButton.isChecked())
									radioButton = (RadioButton)findViewById(R.id.radioButtonComplete);
							}
						}
					}
					paramsHeader.put(radioButton.getText().toString().trim());
				}
				if (editTextProductNumber.getVisibility() == View.VISIBLE)
					paramsHeader.put(editTextProductNumber.getText().toString().trim());
			}
			JSONArray params = PublicMethod.postParam(SearchView.this, searchType, paramsHeader);

			String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
			if (result == null || result.isEmpty())
				return ;

	    	try {
	    		JSONArray jsonCheckResult = new JSONArray(result);
		        if (jsonCheckResult.length() < 2 || jsonCheckResult.getString(0).contains("ERROR"))
		        {
		        	if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).length() >=1)
		        		PublicMethod.displayToast(SearchView.this, jsonCheckResult.getJSONArray(1).getString(0));
		        	return ;
		        }
		        else
		        {
		        	Intent SearchViewIntent = new Intent(SearchView.this, SearchResultView.class);
		        	SearchViewIntent.putExtra(SearchView.this.getString(R.string.string_key_listcontent), result);
		        	SearchView.this.startActivityForResult(SearchViewIntent, 0);
		        }
		    } catch (JSONException e) {  
		    	Log.e(FullscreenActivity.DEBUG_TAG, "error while buttonSearchBook OnClickListener:" + e.getMessage());
		    }
		}
    	
    };

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString(getString(R.string.string_key_orderCode));
			if (returnResult != null)
	        	editTextOrderNumber.setText(returnResult);
			String returnSearchType = bundle.getString(getString(R.string.string_key_searchType));
			if (returnSearchType != null)
				searchType = returnSearchType;
		}
		else if(resultCode == FunctionList.MenuResult)
		{
			SearchView.this.setResult(FunctionList.MenuResult);
			SearchView.this.finish();
		}
	}
}
