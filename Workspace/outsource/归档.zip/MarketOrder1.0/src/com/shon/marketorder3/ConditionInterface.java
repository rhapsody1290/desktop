package com.shon.marketorder3;

public interface ConditionInterface {
	public void setTitle(String str);
	public String getText();
	// ������
	public boolean checkMandatory();
	public void setIsNotSubmit(boolean isNotSubmit);
	public boolean getIsNotSubmit();
	public String getTitle();
	
}
