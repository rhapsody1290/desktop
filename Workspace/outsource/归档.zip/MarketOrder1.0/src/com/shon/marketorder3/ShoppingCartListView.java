package com.shon.marketorder3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import com.shon.marketorder3.BaseListView.ItemClickEvent;
import com.shon.marketorder3.TableAdapter.TableCell;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.TableAdapter.TableRowView;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

public class ShoppingCartListView extends Activity implements TableAdepterInterface{
	public final static String page_tag = "shoppingcart";
	
	private ListView listView;
	private List<TableRow> table;
	private TableAdapter tableAdapter;
	@Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        
        setContentView(R.layout.baselistview);  
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
		
		ListView lvTitle = (ListView)this.findViewById(R.id.TitleListView);
    	ArrayList<TableRow>tableTitle = new ArrayList<TableRow>(); 
        TableCell[] cells = new TableCell[13];  
        cells[0] = new TableCell("��;",300,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[1] = new TableCell("��Ʒ����",260,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[2] = new TableCell("��Ʒ����",300,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[3] = new TableCell("�� ��",100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[4] = new TableCell("��������",130,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
        cells[5] = new TableCell("��ש��(Ƭ)",130,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
        cells[6] = new TableCell("�ӹ���(Ƭ)",130,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
        cells[7] = new TableCell("��ע",420,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[8] = new TableCell("�� ��",260,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
//        cells[8] = new TableCell("�� ��",500,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
//        cells[9] = new TableCell("WDR��",200,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT); 
        cells[9] = new TableCell("��װ��",100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
        cells[10] = new TableCell("Ƭ��",100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
        cells[11] = new TableCell("��׼��",200,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
        cells[12] = new TableCell("������(����)",175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);  
    	
        tableTitle.add(new TableRow(cells)); 
		
        TableAdapter tableTitleAdapter = new TableAdapter(ShoppingCartListView.this, tableTitle, true, true);
        lvTitle.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        lvTitle.setAdapter(tableTitleAdapter); 
		
        listView = (ListView) this.findViewById(R.id.BaseListView);  
        
        setDate();
	    //���ӵ���¼� 
	    listView.setOnItemClickListener(new ListViewItemClickEvent());
	    listView.setOnItemLongClickListener(new ListViewItemLongClickEvent());

        Button buttonDelete = (Button)findViewById(R.id.buttonDelete);
        buttonDelete.setVisibility(View.VISIBLE);
        buttonDelete.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View arg0) {

	        	PublicMethod.displayToast(ShoppingCartListView.this, "ɾ�������ɹ�");
	        	for (int i = 0; i < Inventory.tableShoppingCart.size(); )
				{
					TableRow tableRow = Inventory.tableShoppingCart.get(i);
					
					if (tableRow.isChecked)
					{
						Inventory.tableShoppingCart.remove(i);
						continue;
					}
					
					i++;
				}
	        	Inventory.saveShoppingCartTable(ShoppingCartListView.this);
				setDate();
			}
			
        	
        });  

        Button button = (Button)findViewById(R.id.buttonGotoShoppingCart);
        button.setText("��������");
        button.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View arg0) {
				boolean isChecked = false;
				float totalMoney = 0;
				float totalWeight = 0;
	        	for (int i = 0; i < Inventory.tableShoppingCart.size(); )
				{
					TableRow tableRow = Inventory.tableShoppingCart.get(i);
					
					if (tableRow.isChecked)
					{
						isChecked = true;
						float totalPrice = 0;
						if (!tableRow.quantity.isEmpty() && !tableRow.price.isEmpty())
						{
							totalPrice = (Float.valueOf(tableRow.price).floatValue()+Float.valueOf(tableRow.getCellValue(6).value.toString()).floatValue())*Float.valueOf(tableRow.quantity).intValue();
							BigDecimal b = new BigDecimal(totalPrice);  
							totalPrice  = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
						}
						totalMoney += totalPrice;

						float weight = 0;
						if (!tableRow.quantity.isEmpty() && !tableRow.getCellValue(12).value.toString().isEmpty())
						{
							weight = (Float.valueOf(tableRow.getCellValue(12).value.toString()).floatValue());
							BigDecimal b = new BigDecimal(weight);  
							weight  = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
						}
						totalWeight += weight;
					}
					
					i++;
				}
	        	if (isChecked)
				{
					Intent scintent = new Intent(ShoppingCartListView.this,CustomerInfo.class);
					scintent.putExtra(ShoppingCartListView.this.getString(R.string.string_key_totalMoney), String.format("%.02f", totalMoney));
					scintent.putExtra(ShoppingCartListView.this.getString(R.string.string_key_totalWeight), String.format("%.02f", totalWeight));
					startActivityForResult(scintent, EnterConditionView.ChangeConditionResult);
					return;
				}
	        	PublicMethod.displayToast(ShoppingCartListView.this, "û�й�ѡ����");
			}
        	
        });  

//		if (user != null)
//		{
//			if (!user.author_ORDCRT)
//				button.setVisibility(View.GONE);
//		}


        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				ShoppingCartListView.this.setResult(FunctionList.MenuResult);
				ShoppingCartListView.this.finish();
			}
        });
    }  
	
	
	public void setDate()
	{

    	if (table != null)
    		table.clear();
        table = new ArrayList<TableRow>();
        table.addAll(Inventory.tableShoppingCart);
        
//        ["��Ʒ����","��Ʒ����","�� ��","�� ��","�� ��","WDR��","��װ��","Ƭ��","����"]
		tableAdapter = new TableAdapter(ShoppingCartListView.this,
				table, true, false);
	    listView.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
	    listView.setAdapter(tableAdapter);  
	}

    class ListViewItemClickEvent implements AdapterView.OnItemClickListener {  
        @Override  
        public void onItemClick(AdapterView<?> arg0, View tableRowView, int index,  
                long arg3) {  
//        	int count = index + 1;
//        	if (index == 0)
//        		count = Inventory.tableShoppingCart.size()+1;
//        	
//        	for (int i = index; i < count; i++)
//        	{
//        		if (i != 0)
//	        	{	
//        			TableRow selectTableRow = Inventory.tableShoppingCart.get(i-1);
//        			selectTableRow.isChecked = !selectTableRow.isChecked;
//	        	}
//        		
//	        	TableRowView selectTableRowView = (TableRowView)listView.getItemAtPosition(i);//tableRowView;
//				selectTableRowView.setChecked(!selectTableRowView.getChecked());
//        	}
        }  
    }  

    class ListViewItemLongClickEvent implements AdapterView.OnItemLongClickListener {

		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View tableRowView,
				int index, long arg3) {
        			TableRow selectTableRow = Inventory.tableShoppingCart.get(index);
        			Intent mIntent = new Intent(ShoppingCartListView.this,EnterConditionView.class);
        			mIntent.putExtra("codition", "change");
        			mIntent.putExtra("coditionId", index);
    		        EnterConditionView.selectTableRow = selectTableRow;
    		          
    		        startActivityForResult(mIntent, EnterConditionView.EnterConditionResult);
        	return false;
		}
    }  


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		//����ɨ�������ڽ�������ʾ��
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString("result");


			Intent returnIntent = new Intent();
			Bundle returnBundle = new Bundle();
			returnBundle.putString("result", returnResult);
			returnIntent.putExtras(returnBundle);
			ShoppingCartListView.this.setResult(RESULT_OK, returnIntent);
			ShoppingCartListView.this.finish();
			return;
		}
		else if (resultCode == EnterConditionView.ChangeConditionResult)
		{
			setDate();
			return;
		}
		else if(resultCode == FunctionList.MenuResult)
		{
			ShoppingCartListView.this.setResult(FunctionList.MenuResult);
			ShoppingCartListView.this.finish();
		}
	}


	@Override
	public void CheckboxOnClick(boolean isCheck) {
		for (int i = 0; i<table.size(); i++)
		{
			((TableRowView)listView.getChildAt(i)).setCheckBoxIsCheck(isCheck);
		}
	}

}
