package com.shon.marketorder3;

import android.content.Context;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import com.shon.marketorder3.mk.R;

public class ConditionCheckBox extends LinearLayout implements ConditionInterface {
	CheckBox mCheckBoxConditionSetting;
	boolean mIsNotSubmit = false;

	public ConditionCheckBox(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
        inflate(context, R.layout.conditioncheckbox, this);
        mCheckBoxConditionSetting = (CheckBox)this.findViewById(R.id.checkBoxConditionSetting);
	}

	@Override
	public void setTitle(String str) {
		// TODO Auto-generated method stub
		mCheckBoxConditionSetting.setText(str);
	}

	@Override
	public String getText() {
		// TODO Auto-generated method stub
		if (mCheckBoxConditionSetting.isChecked())
			return "true";
		return "false";
	}

	@Override
	public boolean checkMandatory() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setIsNotSubmit(boolean isNotSubmit){
		mIsNotSubmit = isNotSubmit;
	}
	@Override
	public boolean getIsNotSubmit(){
		// TODO Auto-generated method stub
		return mIsNotSubmit;
	}

	@Override
	public String getTitle()
	{
		return mCheckBoxConditionSetting.getText().toString();
	}
}
