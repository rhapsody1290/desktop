package com.shon.marketorder3;

import java.math.BigDecimal;
import com.shon.marketorder3.TableAdapter.TableCell;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.CheckBox;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

public class EnterConditionView extends Activity {

	public static final int EnterConditionResult = 20001;
	public static final int ChangeConditionResult = 20002;
	public static TableRow selectTableRow;
	private int index;
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
//        selectTableRow = (TableRow)this.getIntent().getSerializableExtra(this.getString(R.string.string_key_selectTableRow));
        setContentView(R.layout.alert_dialog_text_entry); 
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
		

		TextView productName_text = (TextView)findViewById(R.id.productName_text);
		TextView productCode_text = (TextView)findViewById(R.id.productCode_text);
		TextView productLevel_text = (TextView)findViewById(R.id.productLevel_text);
		TextView salesPrice_text = (TextView)findViewById(R.id.salesPrice_text);
		if (this.getIntent().getStringExtra("codition") != null && this.getIntent().getStringExtra("codition").contentEquals("change"))
		{
			index = getIntent().getIntExtra("coditionId", 0);
			productName_text.setText("��Ʒ���ƣ�" + selectTableRow.getCellValue(2).value.toString());
			productCode_text.setText("��Ʒ���룺" + selectTableRow.getCellValue(1).value.toString());
			productLevel_text.setText("�ȼ���" + selectTableRow.getCellValue(3).value.toString());
			salesPrice_text.setVisibility(View.VISIBLE);
			salesPrice_text.setText("�۸񣨲ο��ۼۣ�" + selectTableRow.getCellValue(11).value.toString() + "��");
			if (selectTableRow.isGift.contentEquals("1"))
				((CheckBox)findViewById(R.id.checkBoxIsGift)).setChecked(true);
			((EditText)findViewById(R.id.editTextSalesVolume)).setText(selectTableRow.quantity);
			((EditText)findViewById(R.id.editTextSalesPrice)).setText(selectTableRow.price);
			((EditText)findViewById(R.id.editTextProcessCost)).setText(selectTableRow.getCellValue(6).value.toString());
			((EditText)findViewById(R.id.editTextSalesPurpose)).setText(selectTableRow.purpose);
			((EditText)findViewById(R.id.editTextSalesRemark)).setText(selectTableRow.remark);
		}
		else if (this.getIntent().getStringExtra("codition") != null && this.getIntent().getStringExtra("codition").contentEquals("orderChange"))
		{
			index = getIntent().getIntExtra("coditionId", 0);
			productName_text.setText("��Ʒ���ƣ�" + selectTableRow.getCellValue(0).value.toString());
			productCode_text.setText("��Ʒ���룺" + selectTableRow.getCellValue(10).value.toString());
			productLevel_text.setText("�ȼ���" + selectTableRow.getCellValue(1).value.toString());
			salesPrice_text.setVisibility(View.VISIBLE);
			salesPrice_text.setText("�۸�");
			if (selectTableRow.getCellValue(9).value.toString().contentEquals("��"))
				((CheckBox)findViewById(R.id.checkBoxIsGift)).setChecked(true);
			((EditText)findViewById(R.id.editTextSalesVolume)).setText(selectTableRow.getCellValue(2).value.toString());
			((EditText)findViewById(R.id.editTextSalesPrice)).setText(selectTableRow.getCellValue(3).value.toString());
			((EditText)findViewById(R.id.editTextProcessCost)).setText(selectTableRow.getCellValue(4).value.toString());
			((EditText)findViewById(R.id.editTextSalesPurpose)).setText(selectTableRow.getCellValue(6).value.toString());
			((EditText)findViewById(R.id.editTextSalesRemark)).setText(selectTableRow.getCellValue(8).value.toString());

			boolean isEnableEdit = this.getIntent().getBooleanExtra(this.getString(R.string.string_key_isEnableEdit), true);
			if (!isEnableEdit)
			{
				((EditText)findViewById(R.id.editTextSalesPrice)).setEnabled(false);
				((EditText)findViewById(R.id.editTextProcessCost)).setEnabled(false);
				((EditText)findViewById(R.id.editTextSalesPurpose)).setEnabled(false);
				((EditText)findViewById(R.id.editTextSalesRemark)).setEnabled(false);
				((CheckBox)findViewById(R.id.checkBoxIsGift)).setEnabled(false);
			}
		}
		else
		{
			productName_text.setText("��Ʒ���ƣ�" + selectTableRow.getCellValue(1).value.toString());
			productCode_text.setText("��Ʒ���룺" + selectTableRow.getCellValue(0).value.toString());
			productLevel_text.setText("�ȼ���" + selectTableRow.getCellValue(4).value.toString());
			salesPrice_text.setVisibility(View.VISIBLE);
			salesPrice_text.setText("�۸񣨱�׼��" + selectTableRow.getCellValue(8).value.toString() + "Ԫ/Ƭ��");
//			((EditText)findViewById(R.id.editTextProcessCost)).setText(selectTableRow.getCellValue(6).value.toString());
		}
        Button buttonOK = (Button)findViewById(R.id.buttonOK);
        buttonOK.setOnClickListener(buttonOnClickListener);
        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
	    		EnterConditionView.this.setResult(FunctionList.MenuResult);
	    		EnterConditionView.this.finish();
			}
        });
        
    }

    private OnClickListener buttonOnClickListener = new OnClickListener()
    {

		@Override
		public void onClick(View v) {
			selectTableRow.isGift = ((CheckBox)findViewById(R.id.checkBoxIsGift)).isChecked() ? "1" : "0";
			selectTableRow.quantity = ((EditText)findViewById(R.id.editTextSalesVolume)).getText().toString().trim();
			selectTableRow.price = selectTableRow.isGift == "1" ? "0" : ((EditText)findViewById(R.id.editTextSalesPrice)).getText().toString().trim();
			selectTableRow.purpose = ((EditText)findViewById(R.id.editTextSalesPurpose)).getText().toString().trim();
			selectTableRow.remark = ((EditText)findViewById(R.id.editTextSalesRemark)).getText().toString().trim();
			String processCost = selectTableRow.isGift == "1" ? "0" : ((EditText)findViewById(R.id.editTextProcessCost)).getText().toString().trim();
			if (selectTableRow.quantity.isEmpty())
				selectTableRow.quantity = "0";
			if (selectTableRow.price.isEmpty())
				selectTableRow.price = "0";
			if (processCost.isEmpty())
				processCost = "0";
//        	int storeVolume = Integer.valueOf((String)selectTableRow.getCellValue(7).value).intValue();
//        	int salesVolume = Integer.valueOf(selectTableRow.quantity).intValue();
//        	if (storeVolume < salesVolume)
//        	{
//				Toast.makeText(EnterConditionView, "�����������", Toast.LENGTH_SHORT).show();
//        		return;
//        	}
        	if (selectTableRow.isGift.contentEquals("0") && 
        			(selectTableRow.quantity.contentEquals("") || Float.valueOf(selectTableRow.quantity).floatValue() <= 0))
        	{
				Toast.makeText(EnterConditionView.this, "������������Ϊ��", Toast.LENGTH_SHORT).show();
        		return;
        	}
        	if (selectTableRow.isGift.contentEquals("0") && selectTableRow.quantity.contains("."))
        	{
				Toast.makeText(EnterConditionView.this, "������������С��", Toast.LENGTH_SHORT).show();
        		return;
        	}

        	if (selectTableRow.isGift.contentEquals("0") && 
        			(selectTableRow.price.contentEquals("") || Float.valueOf(selectTableRow.price).floatValue() <= 0.0f))
        	{
				Toast.makeText(EnterConditionView.this, "�۸���Ϊ��", Toast.LENGTH_SHORT).show();
        		return;
        	}
        	if (EnterConditionView.this.getIntent().getStringExtra("codition") != null && EnterConditionView.this.getIntent().getStringExtra("codition").contentEquals("change"))
    		{
        		Inventory.tableShoppingCart.get(index).isGift = selectTableRow.isGift;
        		Inventory.tableShoppingCart.get(index).quantity = selectTableRow.quantity;
        		Inventory.tableShoppingCart.get(index).getCellValue(4).value = selectTableRow.quantity;
        		Inventory.tableShoppingCart.get(index).price = selectTableRow.price;
        		Inventory.tableShoppingCart.get(index).getCellValue(5).value = selectTableRow.price;
        		Inventory.tableShoppingCart.get(index).getCellValue(6).value = processCost;
        		Inventory.tableShoppingCart.get(index).purpose = selectTableRow.purpose;
        		Inventory.tableShoppingCart.get(index).getCellValue(0).value = selectTableRow.purpose;
        		Inventory.tableShoppingCart.get(index).remark = selectTableRow.remark;
        		Inventory.tableShoppingCart.get(index).getCellValue(7).value = selectTableRow.remark;
//				float totalPrice = 0;
//				if (!selectTableRow.quantity.isEmpty() && !selectTableRow.price.isEmpty())
//					totalPrice = (Float.valueOf(selectTableRow.price).floatValue()+Float.valueOf(processCost).floatValue())*Float.valueOf(selectTableRow.quantity).intValue();
//				Inventory.tableShoppingCart.get(index).getCellValue(7).value = String.valueOf(totalPrice);

            	Inventory.saveShoppingCartTable(EnterConditionView.this);
        		EnterConditionView.this.setResult(ChangeConditionResult);
        		EnterConditionView.this.finish();
    		
				return;
    		}

        	if (EnterConditionView.this.getIntent().getStringExtra("codition") != null && EnterConditionView.this.getIntent().getStringExtra("codition").contentEquals("orderChange"))
    		{
        		ChangeOrderCustomerInfo.orderTable.get(index).getCellValue(9).value = selectTableRow.isGift.contentEquals("1")?"��":"��";
        		ChangeOrderCustomerInfo.orderTable.get(index).getCellValue(2).value = selectTableRow.quantity;
        		ChangeOrderCustomerInfo.orderTable.get(index).getCellValue(3).value = selectTableRow.price;
        		ChangeOrderCustomerInfo.orderTable.get(index).getCellValue(4).value = processCost;
        		ChangeOrderCustomerInfo.orderTable.get(index).getCellValue(6).value = selectTableRow.purpose;
        		ChangeOrderCustomerInfo.orderTable.get(index).getCellValue(8).value = selectTableRow.remark;
				float totalPrice = 0;
				if (!selectTableRow.quantity.isEmpty() && !selectTableRow.price.isEmpty())
					totalPrice += Float.valueOf(selectTableRow.price).floatValue()*Float.valueOf(selectTableRow.quantity).intValue();
				if (!selectTableRow.quantity.isEmpty() && !processCost.isEmpty())
					totalPrice += Float.valueOf(processCost).floatValue()*Float.valueOf(selectTableRow.quantity).intValue();
				BigDecimal b = new BigDecimal(totalPrice);  
				totalPrice  = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
				
        		ChangeOrderCustomerInfo.orderTable.get(index).getCellValue(5).value = String.format("%.02f", totalPrice);

            	Inventory.saveShoppingCartTable(EnterConditionView.this);
        		EnterConditionView.this.setResult(ChangeConditionResult);
        		EnterConditionView.this.finish();
    		
				return;
    		}
        	if (EnterConditionView.this.getIntent().getStringExtra("codition") != null && EnterConditionView.this.getIntent().getStringExtra("codition").contentEquals("addOrderList"))
        	{
                TableCell[] cells = new TableCell[12];
    	        String title[] = {"��Ʒ����", "�ȼ�", "Ƭ��", "�ɽ���", "�ӹ��۸�(Ƭ)", "�ܽ��", "��;", "��װ��","��ע","�Ƿ���Ʒ", "��Ʒ����", "����(����)"};
    	        int gravity[] = {Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT};
    	        int w[] = {128, 42, 72, 104, 104, 130, 240, 90, 420, 130, 260, 175};
    	        cells[0] = new TableCell(selectTableRow.getCellValue(1).value.toString(), w[0], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[0]);
    	        cells[1] = new TableCell(selectTableRow.getCellValue(4).value.toString(), w[1], LayoutParams.FILL_PARENT,TableCell.STRING,gravity[1]); 
    	        cells[2] = new TableCell(selectTableRow.quantity, w[2], LayoutParams.FILL_PARENT,TableCell.STRING,gravity[2]); 
                cells[3] = new TableCell(selectTableRow.price, w[3], LayoutParams.FILL_PARENT,TableCell.STRING,gravity[3]);  
                cells[4] = new TableCell(processCost, w[4], LayoutParams.FILL_PARENT,TableCell.STRING,gravity[4]);  
                float totalPrice = 0;
                if (!selectTableRow.quantity.isEmpty() && !selectTableRow.price.isEmpty())
					totalPrice += Float.valueOf(selectTableRow.price).floatValue()*Float.valueOf(selectTableRow.quantity).intValue();
				if (!selectTableRow.quantity.isEmpty() && !processCost.isEmpty())
					totalPrice += Float.valueOf(processCost).floatValue()*Float.valueOf(selectTableRow.quantity).intValue();
				BigDecimal b = new BigDecimal(totalPrice);  
				totalPrice  = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
				
				cells[5] = new TableCell(String.format("%.02f", totalPrice), w[5], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[5]); 
				cells[6] = new TableCell(selectTableRow.purpose, w[6], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[6]); 
				cells[7] = new TableCell(selectTableRow.getCellValue(6).value.toString(), w[7], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[7]);
				cells[8] = new TableCell(selectTableRow.remark, w[8], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[8]); 
                cells[9] = new TableCell(selectTableRow.isGift.contentEquals("1")?"��":"��", w[9], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[9]); 
                cells[10] = new TableCell(selectTableRow.getCellValue(0).value.toString(), w[10], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[10]); 
                float totalWeight = 0;
                if (!selectTableRow.quantity.isEmpty() && !selectTableRow.getCellValue(9).value.toString().isEmpty())
                	totalWeight = Float.valueOf(selectTableRow.getCellValue(9).value.toString()).floatValue()*Float.valueOf(selectTableRow.quantity).intValue();
				BigDecimal bw = new BigDecimal(totalWeight);  
				totalWeight  = bw.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
				cells[11] = new TableCell(String.format("%.02f", totalWeight), w[11], LayoutParams.FILL_PARENT, TableCell.STRING,gravity[11]); 
                
                TableRow tableRow = new TableRow(cells);
                ChangeOrderCustomerInfo.orderTable.add(tableRow);
//            	Inventory.saveShoppingCartTable(EnterConditionView.this);
    			Toast.makeText(EnterConditionView.this, "�����ӳɹ�", Toast.LENGTH_SHORT).show();
    			EnterConditionView.this.setResult(EnterConditionResult);
    			EnterConditionView.this.finish();
    			return;
        	}
        	
            TableCell[] cells = new TableCell[13];
            int w[] = {300,260,300,260,500,100,100,100,100,200,130,130,130,420,100,175};
            cells[0] = new TableCell(selectTableRow.purpose, w[0], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);  
            cells[1] = new TableCell(selectTableRow.getCellValue(0).value.toString(), w[1], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.LEFT); 
            cells[2] = new TableCell(selectTableRow.getCellValue(1).value.toString(), w[2], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.LEFT); 
            cells[3] = new TableCell(selectTableRow.getCellValue(4).value.toString(), w[5], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.LEFT);
            cells[4] = new TableCell(selectTableRow.quantity, w[10], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
            cells[5] = new TableCell(selectTableRow.price, w[11], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
            cells[6] = new TableCell(processCost, w[12], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
            cells[7] = new TableCell(selectTableRow.remark, w[13], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);  
            cells[8] = new TableCell(selectTableRow.getCellValue(2).value.toString(), w[3], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.LEFT); 
//            cells[8] = new TableCell(selectTableRow.getCellValue(3).value.toString(), w[4], LayoutParams.FILL_PARENT, TableCell.STRING); 
//            cells[9] = new TableCell(selectTableRow.getCellValue(4).value.toString(), w[6], LayoutParams.FILL_PARENT, TableCell.STRING); 
            cells[9] = new TableCell(selectTableRow.getCellValue(6).value.toString(), w[7], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.RIGHT); 
            cells[10] = new TableCell(selectTableRow.getCellValue(7).value.toString(), w[8], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.RIGHT); 
            cells[11] = new TableCell(selectTableRow.getCellValue(8).value.toString(), w[9], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.RIGHT); 

            float totalWeight = 0;
            if (!selectTableRow.quantity.isEmpty() && !selectTableRow.getCellValue(9).value.toString().isEmpty())
            	totalWeight = Float.valueOf(selectTableRow.getCellValue(9).value.toString()).floatValue()*Float.valueOf(selectTableRow.quantity).intValue();
			BigDecimal bw = new BigDecimal(totalWeight);  
			totalWeight  = bw.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
            cells[12] = new TableCell(String.format("%.02f", totalWeight), w[15], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.RIGHT);
        	TableRow tableRow = new TableRow(cells);
        	tableRow.isGift = selectTableRow.isGift;
        	tableRow.price = selectTableRow.price;
        	tableRow.quantity = selectTableRow.quantity;
        	tableRow.purpose = selectTableRow.purpose;
        	tableRow.remark = selectTableRow.remark;
        	Inventory.tableShoppingCart.add(tableRow);
        	Inventory.saveShoppingCartTable(EnterConditionView.this);
			Toast.makeText(EnterConditionView.this, "�����ӵ����ﳵ", Toast.LENGTH_SHORT).show();
			EnterConditionView.this.setResult(EnterConditionResult);
			EnterConditionView.this.finish();
		}
    };
}
