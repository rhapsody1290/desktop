package com.shon.marketorder3;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import com.shon.marketorder3.TableAdapter;
import com.shon.marketorder3.TableAdapter.TableCell;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.TableAdapter.TableRowView;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView; 
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.LinearLayout.LayoutParams; 
import android.widget.TextView;
import android.widget.Toast;

public class BaseListView extends Activity { 
    /** Called when the activity is first created. */  
	private TableRowView selectTableRowView;
	private TableRow selectTableRow;
    private ListView lvTitle; 
    private ListView lv; 
    private ArrayList<TableRow> table; 
    private String [] str = {"1","2","3","4","5","6","7"};
    private String coditionType = null;
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        
        setContentView(R.layout.baselistview); 
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
		 
//        this.setTitle("ListView����Ӧʵ�ֱ��---hellogv");  
		lvTitle = (ListView)this.findViewById(R.id.TitleListView);
//		lvTitle.setVisibility(View.INVISIBLE);
        lv = (ListView) this.findViewById(R.id.BaseListView); 
        
		coditionType = this.getIntent().getStringExtra("codition");
        
	    String listContent = getIntent().getStringExtra(getString(R.string.string_key_listcontent));
	    if (listContent == null)
//	    	return ;
	    	listContent = "[['t1','t2','t3'],['r1','r2','r3'],['r1','r2','r3'],['r1','r2','r3']]";
	    
	    JSONArray listJSON = null;
	    try {
	    	ArrayList<TableRow>tableTitle = new ArrayList<TableRow>(); 
	    	listJSON = new JSONArray(listContent); 
//	    	JSONArray titleJSON = listJSON.getJSONArray(1);
	        // �������   
	        TableCell[] titles = new TableCell[12];
//	        int width = this.getWindowManager().getDefaultDisplay().getWidth()/titles.length;
//	        for (int i = 0; i < titleJSON.length(); i++) {  
//	            titles[i] = new TableCell(titleJSON.getString(i),   
//	                                    300,  
//	                                    LayoutParams.FILL_PARENT,   
//	                                    TableCell.STRING);  
//	        }  
	        //产品编码	产品名称	仓库	批次	等级	WDR号	包装数	片数	单价
	        titles[0] = new TableCell("产品名称",300,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
	        titles[1] = new TableCell("等级",100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
	        titles[2] = new TableCell("批次",300,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
	        titles[3] = new TableCell("包装数",100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
	        titles[4] = new TableCell("片数",100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
	        titles[5] = new TableCell("仓库",260,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
	        titles[6] = new TableCell("标准价",200,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
	        titles[7] = new TableCell("WDR号",300,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
	        titles[8] = new TableCell("单片重量(公斤)",175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
	        titles[9] = new TableCell("订单号",175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
	        titles[10] = new TableCell("预留到期日",175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
	        titles[11] = new TableCell("预留人",175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
	        tableTitle.add(new TableRow(titles)); 
			
	        TableAdapter tableTitleAdapter = new TableAdapter(BaseListView.this, tableTitle, false, true);
	        lvTitle.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
	        lvTitle.setAdapter(tableTitleAdapter); 
	        

	    	table = new ArrayList<TableRow>(); 
	    	ArrayList<TableRow> tableContent = new ArrayList<TableRow>(); 
	        // ﾰ￑ﾱ￭ﾸ￱ﾵￄ￐￐ￌ￭ﾼￓﾵﾽﾱ￭ﾸ￱  
	        for (int i = 2; i < listJSON.length(); i++)  
	        {
	            // ￃ﾿￐￐ﾵￄￊ�ﾾ￝  
		    	JSONArray rawJSON = listJSON.getJSONArray(i);
	            TableCell[] cells = new TableCell[rawJSON.length()];  
	            for (int j = 0; j < cells.length; j++) {  
	                cells[j] = new TableCell(rawJSON.getString(j),  
	                                        300,   
	                                        LayoutParams.FILL_PARENT,   
	                                        TableCell.STRING, Gravity.LEFT);  
	            }
	        	table.add(new TableRow(cells)); 
	        	

		        TableCell[] cellContent = new TableCell[12];
		        cellContent[0] = new TableCell(rawJSON.getString(1),300,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
		        cellContent[1] = new TableCell(rawJSON.getString(4),100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
		        cellContent[2] = new TableCell(rawJSON.getString(3),300,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
		        cellContent[3] = new TableCell(rawJSON.getString(6),100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
		        cellContent[4] = new TableCell(rawJSON.getString(7),100,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
		        cellContent[5] = new TableCell(rawJSON.getString(2),260,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
		        cellContent[6] = new TableCell(rawJSON.getString(8),200,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
		        cellContent[7] = new TableCell(rawJSON.getString(5),300,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
		        cellContent[8] = new TableCell(rawJSON.getString(9),175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
		        cellContent[9] = new TableCell(rawJSON.getString(10),175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
		        cellContent[10] = new TableCell(rawJSON.getString(11),175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);
		        cellContent[11] = new TableCell(rawJSON.getString(12),175,LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT);
		        tableContent.add(new TableRow(cellContent)); 
	        }
			
	        TableAdapter tableAdapter = new TableAdapter(BaseListView.this, tableContent, false, false);
	        lv.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
	        lv.setAdapter(tableAdapter);  
	        //��ӵ���¼� 
//	        if (user.author_ORDCRT)
	        	lv.setOnItemClickListener(new ItemClickEvent());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
		

		Button buttonGotoShoppingCart = (Button)this.findViewById(R.id.buttonGotoShoppingCart);
		if (coditionType!= null && coditionType.contentEquals("addOrderList"))
		{
			buttonGotoShoppingCart.setText("返回");
		}
//		if (/*user != null && !user.author_ORDCRT && */(coditionType== null || !coditionType.contentEquals("addOrderList")))
//			buttonGotoShoppingCart.setVisibility(View.GONE);
		buttonGotoShoppingCart.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View arg0) {
				if (coditionType!= null && coditionType.contentEquals("addOrderList"))
				{
					BaseListView.this.finish();
				}
				else
				{
					Intent intent = new Intent(BaseListView.this,ShoppingCartListView.class);
					startActivityForResult(intent, EnterConditionView.EnterConditionResult);
				}
			}
        	
        });  

        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				BaseListView.this.setResult(FunctionList.MenuResult);
				BaseListView.this.finish();
			}
        });
    }  
    
    class ItemClickEvent implements AdapterView.OnItemClickListener {  
        @Override  
        public void onItemClick(AdapterView<?> arg0, View tableRowView, int index,  
                long arg3) {  
//        	if (index == 0)
//        		return;
        	
        	selectTableRow = BaseListView.this.table.get(index);
			selectTableRowView = (TableRowView)tableRowView;
			if (Float.valueOf(selectTableRow.getCellValue(8).value.toString()).floatValue() == 0.0)
			{
				Toast.makeText(BaseListView.this, "标准价为0，不能加入购物车", Toast.LENGTH_SHORT).show();
        		return;
			}
			if (!selectTableRowView.getChecked())
			{
		        Intent mIntent = new Intent(BaseListView.this,EnterConditionView.class);
		        EnterConditionView.selectTableRow = selectTableRow;
//		        Bundle mBundle = new Bundle();  
//		        mBundle.putSerializable(BaseListView.this.getString(R.string.string_key_selectTableRow), selectTableRow);  
		        String codition = BaseListView.this.getIntent().getStringExtra("codition");
		        if (codition!= null)
		        	mIntent.putExtra("codition", codition);
		          
		        startActivityForResult(mIntent, EnterConditionView.EnterConditionResult);
//				LayoutInflater inflater=LayoutInflater.from(BaseListView.this);
//				final View textEntryView=inflater.inflate(R.layout.alert_dialog_text_entry, null);
//				TextView productName_text = (TextView)textEntryView.findViewById(R.id.productName_text);
//				productName_text.setText("��Ʒ��ƣ�" + selectTableRow.getCellValue(1).value.toString());
//				TextView productCode_text = (TextView)textEntryView.findViewById(R.id.productCode_text);
//				productCode_text.setText("��Ʒ���룺" + selectTableRow.getCellValue(0).value.toString());
//				new AlertDialog.Builder(BaseListView.this)
//	//			.setIcon(R.drawable.alert_dialog_icon)
//				.setTitle("������")
//				.setView(textEntryView)
//				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
//					@Override
//					public void onClick(DialogInterface dialog, int which) {
//			        	selectTableRowView.setChecked(!selectTableRowView.getChecked());
//			        	selectTableRow.quantity = ((EditText)textEntryView.findViewById(R.id.editTextSalesVolume)).getText().toString().trim();
//			        	selectTableRow.price = ((EditText)textEntryView.findViewById(R.id.editTextSalesPrice)).getText().toString().trim();
//			        	selectTableRow.purpose = ((EditText)textEntryView.findViewById(R.id.editTextSalesPurpose)).getText().toString().trim();
//			        	selectTableRow.remark = ((EditText)textEntryView.findViewById(R.id.editTextSalesRemark)).getText().toString().trim();
////			        	int storeVolume = Integer.valueOf((String)selectTableRow.getCellValue(7).value).intValue();
////			        	int salesVolume = Integer.valueOf(selectTableRow.quantity).intValue();
////			        	if (storeVolume < salesVolume)
////			        	{
////							Toast.makeText(BaseListView.this, "����������", Toast.LENGTH_LONG).show();
////			        		return;
////			        	}
//
//			            TableCell[] cells = new TableCell[selectTableRow.getSize() + 4];
//			            cells[0] = new TableCell(selectTableRow.purpose,  
//                                300,   
//                                LayoutParams.FILL_PARENT,   
//                                TableCell.STRING);  
//			            int w[] = {500,500,100,500,50,200,100,100,100};
//			            for (int j = 0; j < selectTableRow.getSize(); j++) {  
//			                cells[j+1] = new TableCell(selectTableRow.getCellValue(j).value.toString(),  
//			                		w[j],   
//			                                        LayoutParams.FILL_PARENT,   
//			                                        TableCell.STRING);  
//			            }
//			            cells[selectTableRow.getSize() + 1] = new TableCell(selectTableRow.quantity,  
//                                100,   
//                                LayoutParams.FILL_PARENT,   
//                                TableCell.STRING); 
//			            cells[selectTableRow.getSize() + 2] = new TableCell(selectTableRow.price,  
//                                100,   
//                                LayoutParams.FILL_PARENT,   
//                                TableCell.STRING); 
//			            cells[selectTableRow.getSize() + 3] = new TableCell(selectTableRow.remark,  
//                                300,   
//                                LayoutParams.FILL_PARENT,   
//                                TableCell.STRING); 
//			        	TableRow tableRow = new TableRow(cells);
//			        	tableRow.price = selectTableRow.price;
//			        	tableRow.quantity = selectTableRow.quantity;
//			        	tableRow.purpose = selectTableRow.purpose;
//			        	tableRow.remark = selectTableRow.remark;
//			        	Inventory.tableShoppingCart.add(tableRow);
//						Toast.makeText(BaseListView.this, "����ӵ����ﳵ", Toast.LENGTH_LONG).show();
//					}
//				})
//				.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
//					@Override
//					public void onClick(DialogInterface dialog, int which) {
//	//					Toast.makeText(BaseListView.this, "��ѡ����ȷ��ȡ��", Toast.LENGTH_SHORT).show();
//					}
//				})
//				.show();
			}
			else
			{
				for (int i=0; i<Inventory.tableShoppingCart.size(); i++)
				{
					if (Inventory.tableShoppingCart.get(i).equals(selectTableRow))
					{
						Inventory.tableShoppingCart.remove(i);
						break;
					}
				}
	        	Inventory.saveShoppingCartTable(BaseListView.this);
				selectTableRow.quantity = "";
				Toast.makeText(BaseListView.this, "已从购物车删除", Toast.LENGTH_SHORT).show();
			}

        }  
    }  


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString("result");

			Intent returnIntent = new Intent();
			Bundle returnBundle = new Bundle();
			returnBundle.putString("result", returnResult);
			returnIntent.putExtras(returnBundle);
			BaseListView.this.setResult(Inventory.returnId, returnIntent);
			BaseListView.this.finish();
		}
		else if (resultCode == EnterConditionView.EnterConditionResult)
		{
			if (BaseListView.this.getIntent().getStringExtra("codition") !=null && BaseListView.this.getIntent().getStringExtra("codition").contentEquals("addOrderList"))
			{
				BaseListView.this.setResult(EnterConditionView.ChangeConditionResult);
				BaseListView.this.finish();
			}
//			else
//				selectTableRowView.setChecked(!selectTableRowView.getChecked());
		}
		else if(resultCode == FunctionList.MenuResult)
		{
			BaseListView.this.setResult(FunctionList.MenuResult);
			BaseListView.this.finish();
		}
	}
	

}
