package com.shon.marketorder3;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import com.shon.marketorder3.TableAdapter.TableCell;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.mk.R;
import com.zxing.activity.CaptureActivity;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.LinearLayout.LayoutParams;

public class Inventory extends Activity {
	public final static String page_tag = "inventory";

    public static ArrayList<TableRow> tableShoppingCart = new ArrayList<TableRow>();
    private String storage = "";
    private String coditionType = null;
    public static int returnId = 10001;
    private String page_owner = "OWNER";
    String page;
    EditText editTextOrderId;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		storage = this.getIntent().getStringExtra(this.getString(R.string.string_key_storage));
		coditionType = this.getIntent().getStringExtra("codition");
		page = this.getIntent().getStringExtra("page");
		
		setContentView(R.layout.inventory);
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);


		editTextOrderId = (EditText)findViewById(R.id.editTextOrderId);
		if (page == null || !page.contentEquals(page_owner))
		{
			findViewById(R.id.textViewOrderId).setVisibility(View.GONE);
			editTextOrderId.setVisibility(View.GONE);
		}
		
		findViewById(R.id.buttonTDC).setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v) {
				//��ɨ�����ɨ����������ά��
				Intent openCameraIntent = new Intent(Inventory.this,CaptureActivity.class);
				startActivityForResult(openCameraIntent, 0);
			}
		});

        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
				Inventory.this.setResult(FunctionList.MenuResult);
				Inventory.this.finish();
			}
        });
		
		findViewById(R.id.buttonSearch).setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v) {
				String inputStr = "351d5e73c605a692ea4266688f5f120d,20130504,001100,5588009,linmaosheng";      
			    String key = "abcdefg";         
			    String str = PublicMethod.HloveyRC4(inputStr,key);  
			      
			    //��ӡ���ܺ���ַ���      
			    System.out.println(str); 
			    PublicMethod.write("sdcard/rc4.txt", str);
			      
			    //��ӡ���ܺ���ַ���      
			    System.out.println(PublicMethod.HloveyRC4(str,key)); 
			    
				//��ɨ�����ɨ����������ά��
//				JSONArray params = new JSONArray();
//				params.put("INVQUERY");
//				params.put("");
				JSONArray paramsHeader = new JSONArray();
				EditText editTextProductCode = (EditText)findViewById(R.id.editTextProductCode);
				paramsHeader.put(editTextProductCode.getText().toString().trim());
				EditText editTextProductName = (EditText)findViewById(R.id.editTextProductName);
				paramsHeader.put(editTextProductName.getText().toString().trim());
				paramsHeader.put(storage);
				EditText editTextLevel = (EditText)findViewById(R.id.editTextLevel);
				paramsHeader.put(editTextLevel.getText().toString().trim());
				if (page != null && page.contentEquals(page_owner))
					paramsHeader.put(editTextOrderId.getText().toString().trim());
//				params.put(paramsHeader);
				JSONArray params = PublicMethod.postParam(Inventory.this, "INVQUERY", paramsHeader);
				String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());//"[\,\"\",[\"\",\"95322\",\"OWNER\",\"AA\"]]");
				if (result == null || result.isEmpty())
					return ;

		    	try {
		    		JSONArray jsonCheckResult = new JSONArray(result);
			        if (jsonCheckResult.length() < 2 || jsonCheckResult.getString(0).contains("ERROR"))
			        {
			        	if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).length() >=1)
			        		PublicMethod.displayToast(Inventory.this, jsonCheckResult.getJSONArray(1).getString(0));
			        	return ;
			        }
			        else
			        {
						Intent tableIntent = new Intent(Inventory.this,BaseListView.class);
						tableIntent.putExtra(Inventory.this.getString(R.string.string_key_listcontent), result);
						if (coditionType != null)
							tableIntent.putExtra("codition", coditionType);
						startActivityForResult(tableIntent, 0);
			        }
			    } catch (JSONException e) {  
			    	Log.e(FullscreenActivity.DEBUG_TAG, "error while buttonSearch OnClickListener:" + e.getMessage());
			    	PublicMethod.displayToast(Inventory.this, result);
			    }
			    
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		//����ɨ�������ڽ�������ʾ��
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String scanResult = bundle.getString("result");
			Log.i(scanResult, scanResult);
			EditText editTextProductCode = (EditText)findViewById(R.id.editTextProductName);
			editTextProductCode.setText(scanResult);
//			resultTextView.setText(scanResult);
		}
		else if (resultCode == returnId) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString("result");

			Intent returnIntent = new Intent();
			Bundle returnBundle = new Bundle();
			returnBundle.putString("result", returnResult);
			returnIntent.putExtras(returnBundle);
			Inventory.this.setResult(RESULT_OK, returnIntent);
			Inventory.this.finish();
		}
		else if(resultCode == FunctionList.MenuResult)
		{
			Inventory.this.setResult(FunctionList.MenuResult);
			Inventory.this.finish();
		}
		else if (resultCode == EnterConditionView.ChangeConditionResult)
		{
			Inventory.this.setResult(EnterConditionView.ChangeConditionResult);
			Inventory.this.finish();
		}
	}
	
	static public void saveShoppingCartTable(Activity context){
		JSONArray saveJson = new JSONArray();
		for (int i = 0; i < tableShoppingCart.size(); i++)
		{
			JSONArray itemJson = new JSONArray();
			TableRow tableRow = tableShoppingCart.get(i);
			itemJson.put(tableRow.isGift);
			itemJson.put(tableRow.price);
			itemJson.put(tableRow.purpose);
			itemJson.put(tableRow.quantity);
			itemJson.put(tableRow.remark);
			for (int j = 0; j < tableRow.getSize(); j++)
			{
				itemJson.put(tableRow.getCellValue(j).value.toString());
			}
			saveJson.put(itemJson);
		}
		SharedPreferences settings = context.getSharedPreferences("ShoppingCart", 0);  
		SharedPreferences.Editor editor = settings.edit();  
		String key = "ShoppingCartContent";
		User user = ((MarketorderApplication)context.getApplication()).getUser();
		if (user != null)
			key += "-" + user.name;
		editor.putString(key, saveJson.toString()); 
		editor.commit();  
	}

	static public void getShoppingCartTable(Activity context){
		tableShoppingCart.clear();
		SharedPreferences settings = context.getSharedPreferences("ShoppingCart", 0);
		String key = "ShoppingCartContent";
		User user = ((MarketorderApplication)context.getApplication()).getUser();
		if (user != null)
			key += "-" + user.name; 
		String saveString = settings.getString(key, "");
		if (saveString == null || saveString.contentEquals(""))
			return ;
		
		JSONArray saveJson;
		try {
			saveJson = new JSONArray(saveString);
			for (int i = 0; i < saveJson.length(); i++)
			{
				JSONArray itemJson = saveJson.getJSONArray(i);
				TableCell[] cells = new TableCell[itemJson.length() - 5];
//	            int w[] = {300,200,150,200,500,100,100,100,100,100,100,100,300,100};
	            int w[] = {300,260,300,260,500,100,100,100,100,200,130,130,130,420,100,175};
	            cells[0] = new TableCell(itemJson.getString(5), w[0], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);  
	            cells[1] = new TableCell(itemJson.getString(6), w[1], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.LEFT); 
	            cells[2] = new TableCell(itemJson.getString(7), w[2], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.LEFT); 
	            cells[3] = new TableCell(itemJson.getString(8), w[5], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.LEFT);
	            cells[4] = new TableCell(itemJson.getString(9), w[10], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
	            cells[5] = new TableCell(itemJson.getString(10), w[11], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
	            cells[6] = new TableCell(itemJson.getString(11), w[12], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.RIGHT); 
	            cells[7] = new TableCell(itemJson.getString(12), w[13], LayoutParams.FILL_PARENT,TableCell.STRING,Gravity.LEFT);  
	            cells[8] = new TableCell(itemJson.getString(13), w[3], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.LEFT); 
	//            cells[8] = new TableCell(itemJson.getString(0), w[4], LayoutParams.FILL_PARENT, TableCell.STRING); 
	//            cells[9] = new TableCell(itemJson.getString(0), w[6], LayoutParams.FILL_PARENT, TableCell.STRING); 
	            cells[9] = new TableCell(itemJson.getString(14), w[7], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.RIGHT); 
	            cells[10] = new TableCell(itemJson.getString(15), w[8], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.RIGHT); 
	            cells[11] = new TableCell(itemJson.getString(16), w[9], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.RIGHT); 
	            cells[12] = new TableCell(itemJson.getString(17), w[15], LayoutParams.FILL_PARENT, TableCell.STRING,Gravity.RIGHT);
	        	TableRow tableRow = new TableRow(cells);
	        	tableRow.isGift = itemJson.getString(0);
	        	tableRow.price = itemJson.getString(1);
	        	tableRow.purpose = itemJson.getString(2);
	        	tableRow.quantity = itemJson.getString(3);
	        	tableRow.remark = itemJson.getString(4);
	        	Inventory.tableShoppingCart.add(tableRow);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
