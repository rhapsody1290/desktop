package com.shon.marketorder3;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import com.androidquery.AQuery;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

public class GalleryImage extends Activity {
	public void onCreate(Bundle savedInstanceState) 
	 {
		  super.onCreate(savedInstanceState);
		  AQuery aq = new AQuery(this);

	      setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

	      setContentView(R.layout.galleryimage);
			User user = ((MarketorderApplication)getApplication()).getUser();
			if (user != null)
				this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
			

	      String imageFile = this.getIntent().getExtras().getString(getString(R.string.string_key_file));
//	      Uri uri = Uri.fromFile(new File(imageFile));
//          try { 
//              ContentResolver cr = this.getContentResolver(); 
//        	  InputStream bis = cr.openInputStream(uri);
        	  BitmapFactory.Options options = new BitmapFactory.Options();
        	  options.inSampleSize = 4;
              Bitmap bitmap = BitmapFactory.decodeFile(imageFile, options); 
//				bis.close();
              ImageView adv_img_show = (ImageView) findViewById(R.id.galleryimageview); 
//              aq.id(R.id.galleryimageview).image(imageFile);
              /* ��Bitmap�趨��ImageView */ 
              adv_img_show.setImageBitmap(bitmap); 
//          } catch (FileNotFoundException e) { 
//              Log.e("Exception", e.getMessage(),e); 
//              Toast.makeText(getApplicationContext(), "ѡ���ļ�û�з���", Toast.LENGTH_LONG).show();
//          } 
//			catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//	              Toast.makeText(getApplicationContext(), "ѡ���ļ�û�з���", Toast.LENGTH_LONG).show();
//			}
	 }

    @Override 
    protected void onActivityResult(int requestCode, int resultCode, Intent data) { 
        if (resultCode == RESULT_OK) { 
            Uri uri = data.getData(); 
            Log.e("uri", uri.toString()); 
            ContentResolver cr = this.getContentResolver(); 
            try { 
                Bitmap bitmap = BitmapFactory.decodeStream(cr.openInputStream(uri)); 
                ImageView adv_img_show = (ImageView) findViewById(R.id.galleryimageview); 
                /* ��Bitmap�趨��ImageView */ 
                adv_img_show.setImageBitmap(bitmap); 
            } catch (FileNotFoundException e) { 
                Log.e("Exception", e.getMessage(),e); 
                Toast.makeText(getApplicationContext(), "ѡ���ļ�û�з���", Toast.LENGTH_SHORT).show();
            } 
        } 
        super.onActivityResult(requestCode, resultCode, data);  
    }
}
