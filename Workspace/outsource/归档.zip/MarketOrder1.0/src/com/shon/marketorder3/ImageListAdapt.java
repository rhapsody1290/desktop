package com.shon.marketorder3;

import java.io.File;
import java.util.List;
import com.androidquery.AQuery;

import com.androidquery.AQuery;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ImageListAdapt extends BaseAdapter {

	List<String> mapPath;
	Context context;
	
	public ImageListAdapt(List<String> mapNameList,Context context) {
		super();
		this.mapPath = mapNameList;
		this.context = context;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mapPath.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LinearLayout linearLayout = new LinearLayout(context);
		ImageView imageView = new ImageView(context);
		
		TextView textView = new TextView(context);
		Bitmap bitmap = null;
		
		String fileName = mapPath.get(position);
		bitmap = PublicMethod.bitmap_Out_Of_Memory_Handle(fileName,90,90);
		String text = fileName.substring(fileName.lastIndexOf("/")+1, fileName.length()).toLowerCase();
		textView.setText(text);
		textView.setTextSize(20);
		imageView.setImageBitmap(bitmap);
//		AQuery aq = new AQuery(context);
//		aq.id(imageView).image(fileName);
//		aq.image(new File(fileName), 90);
//		imageView = aq.getImageView();
		linearLayout.addView(imageView);
		linearLayout.addView(textView);
		return linearLayout;
	}

}
