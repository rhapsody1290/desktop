package com.shon.marketorder3;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.shon.marketorder3.mk.R;

public class ConditionDate extends LinearLayout implements ConditionInterface {
	TextView mTextViewConditionDateTitle;
	Button mButtonConditionDateSetting;
	boolean mIsNotSubmit = false;

	public ConditionDate(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
        inflate(context, R.layout.conditiondate, this);
        mTextViewConditionDateTitle = (TextView)this.findViewById(R.id.TextViewConditionDateTitle);
        mButtonConditionDateSetting = (Button)this.findViewById(R.id.buttonConditionDateSetting);
        this.setDate(Calendar.getInstance().get(Calendar.YEAR), 
				Calendar.getInstance().get(Calendar.MONTH) + 1, 
				Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        
        mButtonConditionDateSetting.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) { 
				DatePickerDialog datePicker = new DatePickerDialog(ConditionDate.this.getContext(), new OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) {
						ConditionDate.this.setDate(year, monthOfYear + 1, dayOfMonth);
	//					Toast.makeText(AnalogDigitalClock.this, year+"year "+(monthOfYear+1)+"month "+dayOfMonth+"day", Toast.LENGTH_SHORT).show();
					}
				}, 
				Calendar.getInstance().get(Calendar.YEAR), 
				Calendar.getInstance().get(Calendar.MONTH), 
				Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
				datePicker.show();
			}
			
		});
	}
	public void setDate(String defaultValue)
	{
		if (defaultValue.isEmpty())
			return;
		Pattern p = Pattern.compile("[0-9]*");   
	    Matcher m = p.matcher(defaultValue);   
	    if(!m.matches() )
	    	 return;
	    	 
		int year = Integer.parseInt((String)defaultValue.subSequence(0, 4));
		int month = Integer.parseInt((String)defaultValue.subSequence(4, 6));
		int day = Integer.parseInt((String)defaultValue.subSequence(6, 8));
		this.setDate(year, month, day);
	}
	private void setDate(int year, int month,int day)
	{
		mButtonConditionDateSetting.setText(String.format("%04d%02d%02d", year, month, day));
	}
	
	public String getText()
	{
		return mButtonConditionDateSetting.getText().toString();
	}
	
	public void setTitle(String str)
	{
		mTextViewConditionDateTitle.setText(str);
	}
	@Override
	public String getTitle()
	{
		return mTextViewConditionDateTitle.getText().toString();
	}

	@Override
	public boolean checkMandatory() {
		return true;
	}

	@Override
	public void setIsNotSubmit(boolean isNotSubmit){
		mIsNotSubmit = isNotSubmit;
	}
	@Override
	public boolean getIsNotSubmit(){
		// TODO Auto-generated method stub
		return mIsNotSubmit;
	}

	public void setEnable(boolean isEnable)
	{
		mButtonConditionDateSetting.setEnabled(isEnable);
//		if (!isEnable)
//			mEditTextConditionTextContent.setl
	}
}
