package com.shon.marketorder3;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import com.shon.marketorder3.BaseListView.ItemClickEvent;
import com.shon.marketorder3.mk.R;
import com.zxing.activity.CaptureActivity;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.EditText;
import android.widget.TextView;

public class SearchImageView extends Activity {
	public final static String page_tag = "searchimage";
	ListView image_list;
	List<String> mapNameList = null;
	
	 public void onCreate(Bundle savedInstanceState) 
	 {
		  super.onCreate(savedInstanceState);

	      setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

	      setContentView(R.layout.searchimageview);
			User user = ((MarketorderApplication)getApplication()).getUser();
			if (user != null)
				this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
			

			findViewById(R.id.buttonTDC).setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View v) {
					//打开扫描界面扫描条形码或二维码
					Intent openCameraIntent = new Intent(SearchImageView.this,CaptureActivity.class);
					startActivityForResult(openCameraIntent, 0);
				}
			});
			
	      findViewById(R.id.buttonSearchImageOnImageView).setOnClickListener(new OnClickListener()
	      {

			@Override
			public void onClick(View v) {
				String searchText = ((EditText)findViewById(R.id.editTextSearchImage)).getText().toString();
				image_list = (ListView)findViewById(R.id.listViewFindImage);
				if (searchText == null || searchText.trim().contentEquals(""))
				{
					PublicMethod.displayToast(SearchImageView.this, "请输入查询图片名称");
					return ;
				}   
				mapNameList = getSD("storage/extSdCard/photo", searchText);
				if (mapNameList == null || mapNameList.size() == 0)
				{
					mapNameList = getSD("/sdcard/photo", searchText);
				}
				if (mapNameList == null || mapNameList.size() == 0)
				{
					PublicMethod.displayToast(SearchImageView.this, "没有查询到图片");
					return ;
				}
				
				ImageListAdapt theFirstListAdapt = new ImageListAdapt(mapNameList,SearchImageView.this);
				image_list.setAdapter(theFirstListAdapt);
				image_list.setOnItemClickListener(new ImageItemClickEvent()); 
			}
	    	  
	      });
	 }

	    class ImageItemClickEvent implements AdapterView.OnItemClickListener {  
	        @Override  
	        public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,  
	                long arg3) { 
	    		String fileName = mapNameList.get(arg2);
	    		Intent intent = new Intent(SearchImageView.this, GalleryImage.class);// 跳转到大图浏览
				Bundle bundle = new Bundle();
				bundle.putString(SearchImageView.this.getString(R.string.string_key_file), fileName);
				intent.putExtras(bundle);
	    		startActivity(intent);
//	            Toast.makeText(testMyListView.this, "选中第"+String.valueOf(arg2)+"行", 500).show();  
	        }  
	    }  

	  public static List<String> getSD(String pathName, String searchText){
		  List<String> it = new ArrayList<String>();
		 	File f = new File(pathName);
		 	File[] files = f.listFiles();
	 	
		 	if(files != null){
			    	for(int i=0;i<files.length;i++){
			    		File file = files[i];  
			    		
			    		if(file.isDirectory()){
			    			
			    			List<String> list = getSD(file.getPath(), searchText);	    			
			    			if(list != null)
			    				it.addAll(list);
			    		}
			    		else{
			    			
			        		if(getImageFile(file.getPath()))
			        		{
			        		 	String filename = "";
			        		 	if(file.getPath().lastIndexOf("/") != -1){
			        		 		filename = file.getPath().substring(file.getPath().lastIndexOf("/")+1, file.getPath().length()).toLowerCase();
			        		 	}
			        		 	
			        		 	if (filename.contains(searchText.toLowerCase()))
			        		 		it.add(file.getPath());
			        		}
			    		}
			    	}
		 	}
		 	
		 	if(files == null)
		 		return null;
		 	
		 	return it;
		 }
		 
		 public static boolean getImageFile(String fName){
		 	
		 	boolean re;
		 	String end = "";
		 	if(fName.lastIndexOf(".") != -1){
		 		end = fName.substring(fName.lastIndexOf(".")+1, fName.length()).toLowerCase();
		 	}
				
		 	if(end.equals("jpg")||end.equals("gif")||
		 			end.equals("png")||end.equals("jpeg")||
		 			end.equals("bmp"))
		 	{
		 		re = true;
		 	}
		 	else{
		 		re = false;
		 	}
		 	return re;
	 }

			@Override
			protected void onActivityResult(int requestCode, int resultCode, Intent data) {
				super.onActivityResult(requestCode, resultCode, data);
				//处理扫描结果（在界面上显示）
				if (resultCode == RESULT_OK) {
					Bundle bundle = data.getExtras();
					String scanResult = bundle.getString("result");
					Log.i(scanResult, scanResult);
					EditText editTextSearchImage = (EditText)findViewById(R.id.editTextSearchImage);
					editTextSearchImage.setText(scanResult);
//					resultTextView.setText(scanResult);
				}
			}

}
