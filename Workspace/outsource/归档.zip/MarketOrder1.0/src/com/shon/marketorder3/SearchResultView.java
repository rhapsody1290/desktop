package com.shon.marketorder3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.shon.marketorder3.BaseListView.ItemClickEvent;
import com.shon.marketorder3.TableAdapter.TableCell;
import com.shon.marketorder3.TableAdapter.TableRow;
import com.shon.marketorder3.TableAdapter.TableRowView;
import com.shon.marketorder3.mk.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

public class SearchResultView extends Activity {

    /** Called when the activity is first created. */
	final String strJsonKey_header = "header";
	final String strJsonKey_title = "title";
	final String strJsonKey_width = "width";
	final String strJsonKey_align = "align";
	final String strJsonKey_body = "body";

	private ListView lvTitle; 
    private ListView lv; 
    private ArrayList<TableRow> table; 
    private TableCell[] titles;
    private int selectOrderIndex;
	
	@Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState); 
        
        setContentView(R.layout.searchresultview);  
		User user = ((MarketorderApplication)getApplication()).getUser();
		if (user != null)
			this.setTitle(this.getString(R.string.app_name)  + "-" + user.name);
		  
		lvTitle = (ListView)this.findViewById(R.id.TitleListView);
        lv = (ListView) this.findViewById(R.id.SearchResultListView); 
        
        
	    String listContent = getIntent().getStringExtra(getString(R.string.string_key_SearchCondition_result));
	    if (listContent == null)
	    	return ;
	    
	    JSONObject listJSON = null;
	    try {
	        table = new ArrayList<TableRow>(); 
	    	listJSON = new JSONObject(listContent); 
	    	JSONArray headerJson = listJSON.getJSONArray(strJsonKey_header);
	    	JSONObject headerItem;
	    	int tGravity;
	        ArrayList<TableRow>tableTitle = new ArrayList<TableRow>(); 
	        int columns = headerJson.length();

	        boolean isLiuhuochaxun = false;
	        if (getIntent().hasExtra(getString(R.string.string_key_SearchCondition_type)) &&
	        		getIntent().getStringExtra(getString(R.string.string_key_SearchCondition_type)).contentEquals("changeRow"))
	        {
	        	isLiuhuochaxun = true;
	        	columns--;
	        }
	        
	        titles = new TableCell[columns];
	        
	        for (int i = 0; i<columns; i++)
	        {
	        	headerItem =  headerJson.getJSONObject(i);
                tGravity = Gravity.LEFT;
                if (headerItem.getString(strJsonKey_align).contentEquals("right"))
                	tGravity = Gravity.RIGHT;
                else if (headerItem.getString(strJsonKey_align).contentEquals("center"))
                	tGravity = Gravity.CENTER;
	        	titles[i] = new TableCell(headerItem.getString(strJsonKey_title), 
	        			headerItem.getInt(strJsonKey_width),
	        			LayoutParams.FILL_PARENT,
	        			TableCell.STRING,
	        			tGravity);
	        }
	        tableTitle.add(new TableRow(titles)); 
			
	        TableAdapter tableTitleAdapter = new TableAdapter(SearchResultView.this, tableTitle, false, true);
	        lvTitle.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
	        lvTitle.setAdapter(tableTitleAdapter); 
	        
	        //body
	    	JSONArray bodyJson = listJSON.getJSONArray(strJsonKey_body);
	    	JSONArray bodyRow;
	    	TableCell[] cells;
	    	
	        for (int i = 0; i < bodyJson.length(); i++)  
	        {
	        	bodyRow = bodyJson.getJSONArray(i);
	            cells = new TableCell[columns];  
	            for (int j = 0; j < cells.length; j++) {

//		        	if (isLiuhuochaxun && j+1 == bodyRow.length())
//		        		continue;
		        	
		        	headerItem =  headerJson.getJSONObject(j);
	                tGravity = Gravity.LEFT;
	                if (headerItem.getString(strJsonKey_align).contentEquals("right"))
	                	tGravity = Gravity.RIGHT;
	                else if (headerItem.getString(strJsonKey_align).contentEquals("center"))
	                	tGravity = Gravity.CENTER;
	                
	                cells[j] = new TableCell(bodyRow.getString(j),
	                						headerItem.getInt(strJsonKey_width),   
	                                        LayoutParams.FILL_PARENT,   
	                                        TableCell.STRING,
	                                        tGravity);  
	            }
	        	table.add(new TableRow(cells)); 
	        }
			
	        TableAdapter tableAdapter = new TableAdapter(SearchResultView.this, table, false, false);
	        lv.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
	        lv.setAdapter(tableAdapter);  

	        if (getIntent().hasExtra(getString(R.string.string_key_SearchCondition_type)) && 
	        		getIntent().getStringExtra(getString(R.string.string_key_SearchCondition_type)).contentEquals("R80000"))
	        	lv.setOnItemClickListener(new ORDERLISTItemClickEvent());
	        // ���񿨲�ѯ
	        else if (getIntent().hasExtra(getString(R.string.string_key_SearchCondition_type)) && 
	        		getIntent().getStringExtra(getString(R.string.string_key_SearchCondition_type)).contentEquals("R80900"))
	        	lv.setOnItemClickListener(new FWKLISTItemClickEvent());
	        else if (getIntent().hasExtra(getString(R.string.string_key_SearchCondition_type)) &&
	        		getIntent().getStringExtra(getString(R.string.string_key_SearchCondition_type)).contentEquals("changeRow"))
	        {
	        	lv.setOnItemClickListener(new changeRowItemClickEvent());
	        	Button buttonMenu = (Button)findViewById(R.id.buttonMenu);
	        	buttonMenu.setVisibility(View.INVISIBLE);
//	        	buttonMenu.setText("����");
//	        	buttonMenu.setOnClickListener(savechangeRow);
	        }
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
		

        findViewById(R.id.buttonBack).setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v) {
//				SearchResultView.this.setResult(FunctionList.MenuResult);
				SearchResultView.this.finish();
			}
        });
    }  
//	private TableRowView selectTableRowView;
//	private TableRow selectTableRow;
//	private ListView lvTitle; 
//    private ListView lv; 
//    private ArrayList<TableRow> table; 
//    private String [] str = {"1","2","3","4","5","6","7"};
//    @Override  
//    public void onCreate(Bundle savedInstanceState) {  
//        super.onCreate(savedInstanceState); 
//        
//        setContentView(R.layout.searchresultview);  
//		User user = ((MarketorderApplication)getApplication()).getUser();
//		if (user != null)
//			this.setTitle(this.getString(R.string.app_name) + "-" + FullscreenActivity.mLinkAddressName + "-" + user.name);
//		
////        this.setTitle("ListView����Ӧʵ�ֱ���---hellogv");  
//		lvTitle = (ListView)this.findViewById(R.id.TitleListView);
//        lv = (ListView) this.findViewById(R.id.SearchResultListView); 
//        
//        String titleORDERLIST[] = {"״̬", "������", "�к�", "�ͻ�����", "�ͻ��绰", "��Ʒ����", "��Ʒ����", "��װ��", "�ȼ�", "Ƭ��", "��ש�ۣ�Ƭ��", "�ӹ��ۣ�Ƭ��", "���", "��;", "��ע", "�ͻ���ַ", "��������", "�������","�׵���", "������","ҵ��Ա","�ŵ�","����(����)","��������"};
//        int gravityORDERLIST[] = {Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT};
//        int widthORDERLIST[] = {125, 250, 125, 250, 250, 250, 250, 150, 100, 125, 175, 175, 200, 250, 500, 500, 175, 175, 175, 175, 175, 175, 150, 150};
//        String titlePICKLIST[] = {"������", "�������", "�ᵥ�к�", "�ͻ�����", "�ͻ��绰", "��Ʒ����", "��Ʒ����", "��װ��", "�ȼ�", "�������", "��;", "��ע", "�ͻ���ַ", "��������", "����(����)","����"};
//        int gravityPICKLIST[] = {Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT};
//        int widthPICKLIST[] = {250, 200, 175, 250, 250, 250, 250, 150, 100, 150, 250, 500, 500, 175, 150, 175};
//        String titleORDERISSUE[] = {"������", "�������", "�������ݺ�", "����������", "�ͻ�����", "�ͻ��绰", "��Ʒ����", "��Ʒ����", "��װ��", "�ȼ�", "��������", "��;", "��ע", "�ͻ���ַ", "��������","����"};
//        int gravityORDERISSUE[] = {Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT};
//        int widthORDERISSUE[] = {250, 175, 200, 200, 250, 250, 250, 250, 150, 100, 150, 250, 500, 500, 175, 175};
//        String titleORDERPAY[] = {"״̬", "������", "�����", "�ͻ�����", "�ͻ��绰", "�ͻ���ַ", "���", "��ע", "��������"};
//        int gravityORDERPAY[] = {Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.LEFT};
//        int widthORDERPAY[] = {125, 250, 150, 250, 250, 500, 200, 500, 175};
//        String titleORDERTRACE[] = {"�ŵ�", "�ͻ�����", "�ͻ��绰", "�ͻ���ַ", "����״̬", "��������", "������", "�ֹ�����", "�������", "������", "����δ�������", "�տ���", "Ĩ����", "����Ӧ�տ����","����Ա"};
//        int gravityORDERTRACE[] = {Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT,Gravity.RIGHT};
//        int widthORDERTRACE[] = {250, 250, 250, 500, 125, 175, 250, 150, 200, 200, 300, 200, 200, 300, 200};
//        String titleREBATELIST[] = {"��������", "��������", "״̬", "�ŵ�", "�ͻ�����", "�ͻ���ַ", "��װ��˾", "���ʦ1", "���ʦ2", "������", "��������", "������", "��������", "��ע", "�ظ���������", "ԭ��������"};
//        int gravityREBATELIST[] = {Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT};
//        int widthREBATELIST[] = {125, 250, 120, 250, 250, 500, 250, 250, 250, 250, 175, 250, 175, 500, 250, 250};
//        String titlePLANLIST[] = {"����","������","Ʒ��","��Ʒϵ��","��Ʒ���","��Ʒ����","���ϼ�ש��","�Ų�����(M2)","��ɫ","�Ų�����","��������","Ҫ����λ","�ͻ�/����","��������(M2)","��װ������Ҫ��","���ڶ�������","ʵ��������","��ע"};
//        int gravityPLANLIST[] = {Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.LEFT,Gravity.RIGHT,Gravity.LEFT,Gravity.RIGHT,Gravity.RIGHT,Gravity.LEFT};
//        int widthPLANLIST[] = {250, 250, 250, 250, 250, 250, 250, 150, 125, 175, 175, 250, 250, 150, 500, 150, 150, 500};
//        
//        
//	    String listContent = getIntent().getStringExtra(getString(R.string.string_key_listcontent));
//	    if (listContent == null)
////	    	return ;
//	    	listContent = "[['t1','t2','t3'],['r1','r2','r3'],['r1','r2','r3'],['r1','r2','r3']]";
//	    
//	    JSONArray listJSON = null;
//	    try {
//	        table = new ArrayList<TableRow>(); 
//	    	listJSON = new JSONArray(listContent); 
//	    	String title[];
//	    	int width[];
//	    	int gravity[];
//	    	if (listJSON.getString(0).contentEquals("ORDERLIST"))
//	    	{
//	    		title = titleORDERLIST;
//	    		width = widthORDERLIST;
//	    		gravity = gravityORDERLIST;
//	    	}
//	    	else if (listJSON.getString(0).contentEquals("PICKLIST"))
//	    	{
//	    		title = titlePICKLIST;
//	    		width = widthPICKLIST;
//	    		gravity = gravityPICKLIST;
//	    	} 
//	    	else if (listJSON.getString(0).contentEquals("ORDERISSUE"))
//	    	{
//	    		title = titleORDERISSUE;
//	    		width = widthORDERISSUE;
//	    		gravity = gravityORDERISSUE;
//	    	} 
//	    	else if (listJSON.getString(0).contentEquals("ORDERPAY"))
//	    	{
//	    		title = titleORDERPAY;
//	    		width = widthORDERPAY;
//	    		gravity = gravityORDERPAY;
//	    	} 
//	    	else if (listJSON.getString(0).contentEquals("ORDERTRACE"))
//	    	{
//	    		title = titleORDERTRACE;
//	    		width = widthORDERTRACE;
//	    		gravity = gravityORDERTRACE;
//	    	} 
//	    	else if (listJSON.getString(0).contentEquals("REBATELIST"))
//	    	{
//	    		title = titleREBATELIST;
//	    		width = widthREBATELIST;
//	    		gravity = gravityREBATELIST;
//	    	} 
//	    	else if (listJSON.getString(0).contentEquals("PLANLIST"))
//	    	{
//	    		title = titlePLANLIST;
//	    		width = widthPLANLIST;
//	    		gravity = gravityPLANLIST;
//	    	} 
//	    	else
//	    		return;
//	    		
//	        ArrayList<TableRow>tableTitle = new ArrayList<TableRow>(); 
//	        TableCell[] titles = new TableCell[title.length];
//	        for (int i = 0; i<title.length; i++)
//	        	titles[i] = new TableCell(title[i],width[i],LayoutParams.FILL_PARENT,TableCell.STRING,gravity[i]);
//	        tableTitle.add(new TableRow(titles)); 
//			
//	        TableAdapter tableTitleAdapter = new TableAdapter(SearchResultView.this, tableTitle, false, true);
//	        lvTitle.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
//	        lvTitle.setAdapter(tableTitleAdapter); 
//	        
//	    	
////	    	JSONArray titleJSON = listJSON.getJSONArray(1);
////	    	TableCell[] titles = null;
////	        // �������   
////	    	if (titleJSON.length() > 0)
////	    	{
////	    		titles = new TableCell[titleJSON.length()];
////		        int width = this.getWindowManager().getDefaultDisplay().getWidth()/titles.length;
////		        for (int i = 0; i < titleJSON.length(); i++) { 
////		        	int w = 250;
////		        	if (titleJSON.getString(i).contains("��ַ"))
////		        		w = 500;
////		            titles[i] = new TableCell(titleJSON.getString(i),   
////		                                    w,  
////		                                    LayoutParams.FILL_PARENT,   
////		                                    TableCell.STRING);  
////		        }  
////		        table.add(new TableRow(titles)); 
////		    }
//	        
//	        // �ѱ���������ӵ�����  
//	        for (int i = 2; i < listJSON.length(); i++)  
//	        {
//	            // ÿ�е�����  
//		    	JSONArray rawJSON = listJSON.getJSONArray(i);
//	            TableCell[] cells = new TableCell[rawJSON.length()];  
//	            for (int j = 0; j < cells.length; j++) { 
//		        	int w = width[j];
////		        	if (titleJSON.length() > 0)
////		        		w = titles[j].width;
//	                cells[j] = new TableCell(rawJSON.getString(j),  
//	                		w,   
//	                                        LayoutParams.FILL_PARENT,   
//	                                        TableCell.STRING,gravity[j]);  
//	            }
//	        	table.add(new TableRow(cells)); 
//	        }
//			
//	        TableAdapter tableAdapter = new TableAdapter(SearchResultView.this, table, false, false);
//	        lv.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
//	        lv.setAdapter(tableAdapter);  
////	        //���ӵ���¼� 
//	        if (listJSON.getString(0).contentEquals("ORDERLIST"))
//	        	lv.setOnItemClickListener(new ItemClickEvent());
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}   
//		
//
//        findViewById(R.id.buttonMenu).setOnClickListener(new OnClickListener()
//        {
//
//			@Override
//			public void onClick(View v) {
//				SearchResultView.this.setResult(FunctionList.MenuResult);
//				SearchResultView.this.finish();
//			}
//        });
//    }

	
	
	
    class ORDERLISTItemClickEvent implements AdapterView.OnItemClickListener {  
        

		@Override  
        public void onItemClick(AdapterView<?> arg0, View tableRowView, int index,  
                long arg3) {  
        	selectOrderIndex = index;
        	ArrayList<String> choices = new ArrayList<String>(); 
        	MarketorderApplication app = (MarketorderApplication)SearchResultView.this.getApplicationContext();
        	String userAuthor = app.getUser().author;
        	try {
				JSONObject userAuthorJSONObject = new JSONObject(userAuthor);
				JSONArray modifyorderJSONArray = userAuthorJSONObject.getJSONArray("modifyorder");
				for (int i=0; i<modifyorderJSONArray.length(); i++)
				{
					JSONObject modifyorderItem = modifyorderJSONArray.getJSONObject(i);
					String listStatus = SearchResultView.this.table.get(selectOrderIndex).getCellValue(0).value.toString();
		        	if (modifyorderItem.getString("page").contains("RESINV") && (listStatus.contains("ȡ��") || listStatus.contains("����") || listStatus.contains("���")))
		        		continue;
		        	if (modifyorderItem.getString("page").contains("DSK") &&(listStatus.contains("ȡ��") || listStatus.contains("����")))
		        		continue;
		        	if (modifyorderItem.getString("page").contains("FWK") || modifyorderItem.getString("page").contains("PDATE")
//		        			|| modifyorderItem.getString("page").contains("RESINV")
		        			)
		        	{
		        		if (listStatus.contains("������") ||
//		        				listStatus.contains("������") ||
//		        				listStatus.contains("��������") ||
		        				listStatus.contains("�ѱ���") ||
		        				listStatus.contains("���ֱ���") ||
		        				listStatus.contains("���ֽ���"))
		        			;
		        		else
		        			continue;
		        	}
					choices.add(modifyorderItem.getString("title"));
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
//        	choices.add("�����������");
//        	choices.add("���տ�");
//        	choices.add("�޸Ķ���");
//        	choices.add("����");
//        	String listStatus = SearchResultView.this.table.get(index).getCellValue(0).value.toString();
//        	if (listStatus.contains("������"))
//        		choices.add("������ѯ");
        	String[] array =new String[choices.size()];
        	choices.toArray(array);
        	AlertDialog dialog = new AlertDialog.Builder(SearchResultView.this)   
             .setTitle("ѡ��")  
             .setItems(array, onselect)
             .create();  
    dialog.show(); 
        	
        }  
        
    }  
    
    class FWKLISTItemClickEvent implements AdapterView.OnItemClickListener {  
        

		@Override  
        public void onItemClick(AdapterView<?> arg0, View tableRowView, int index,  
                long arg3) {  
        	selectOrderIndex = index;
        	String listStatus = SearchResultView.this.table.get(selectOrderIndex).getCellValue(0).value.toString();
        	if (!listStatus.contains("����") || SearchResultView.this.table.get(index).getSize()<14)
        		return;
        	
        	TableRow row = SearchResultView.this.table.get(index);
        	String formatJson = "{    \"condition\": [        {            \"type\": \"text\",            \"title\": \"������\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },{            \"type\": \"text\",            \"title\": \"���񿨺�\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ͻ�����\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ͻ��绰\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"С������\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"date\",            \"title\": \"�ͻ�����\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ͻ���ַ\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ջ���\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ջ��绰\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����·��\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"radio\",            \"title\": \"���޵���\",            \"selectItem\": [                \"��\",                \"��\"            ],            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����Ҫ��\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ӹ�˵��\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����˵��\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�����վݺ�\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"��������\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�������\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"������\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"���ս��\",            \"defaultvalue\": \"%s\"        }    ],    \"type\": \"FWKCHG\"}";
        	formatJson = String.format(formatJson, 
        			row.getCellValue(1).value.toString(),
        			row.getCellValue(2).value.toString(),
        			row.getCellValue(3).value.toString(),
        			row.getCellValue(4).value.toString(),
        			row.getCellValue(5).value.toString(),
        			row.getCellValue(6).value.toString(),
        			row.getCellValue(7).value.toString(),
        			row.getCellValue(8).value.toString(),
        			row.getCellValue(9).value.toString(),
        			row.getCellValue(10).value.toString(),
        			row.getCellValue(11).value.toString(),
        			row.getCellValue(12).value.toString(),
        			row.getCellValue(13).value.toString(),
        			row.getCellValue(14).value.toString(),
        			row.getCellValue(15).value.toString(),
        			row.getCellValue(16).value.toString(),
        			row.getCellValue(17).value.toString(),
        			row.getCellValue(18).value.toString(),
        			row.getCellValue(19).value.toString(),
        			row.getCellValue(20).value.toString(),
        			row.getCellValue(21).value.toString());
        	
            Intent ChangeSaveIntent = new Intent(SearchResultView.this, ChangeSave.class);
            ChangeSaveIntent.putExtra(SearchResultView.this.getString(R.string.string_key_SearchCondition_condition), formatJson.toString());
            SearchResultView.this.startActivityForResult(ChangeSaveIntent, 0);
        }  
        
    }  
    android.content.DialogInterface.OnClickListener onselect = new android.content.DialogInterface.OnClickListener() {  

		@Override
		public void onClick(DialogInterface dialog, int which) {
			MarketorderApplication app = (MarketorderApplication)SearchResultView.this.getApplicationContext();
        	String userAuthor = app.getUser().author;
        	int whichcount=0;
        	String page = null;
        	try {
				JSONObject userAuthorJSONObject = new JSONObject(userAuthor);
				JSONArray modifyorderJSONArray = userAuthorJSONObject.getJSONArray("modifyorder");
				for (int i=0; i<modifyorderJSONArray.length(); i++)
				{
					JSONObject modifyorderItem = modifyorderJSONArray.getJSONObject(i);
					String listStatus = SearchResultView.this.table.get(selectOrderIndex).getCellValue(0).value.toString();
					if (modifyorderItem.getString("page").contains("RESINV") && (listStatus.contains("ȡ��") || listStatus.contains("����") || listStatus.contains("���")))
		        		continue;
		        	if (modifyorderItem.getString("page").contains("DSK") &&(listStatus.contains("ȡ��") || listStatus.contains("����")))
		        		continue;
		        	if (modifyorderItem.getString("page").contains("FWK") || modifyorderItem.getString("page").contains("PDATE")
//		        			|| modifyorderItem.getString("page").contains("RESINV")
		        			)
		        	{
		        		if (listStatus.contains("������") ||
//		        				listStatus.contains("������") ||
//		        				listStatus.contains("��������") ||
		        				listStatus.contains("�ѱ���") ||
		        				listStatus.contains("���ֱ���") ||
		        				listStatus.contains("���ֽ���"))
		        			;
		        		else
		        			continue;
		        	}
		        	
		        	if (whichcount == which)
		        	{
		        		page = modifyorderItem.getString("page");
		        		break;
		        	}
		        	else
		        		whichcount ++;
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//�����������
			if (page.contains("PDATE"))  
				changeDate(selectOrderIndex);
			//���տ�
			else if (page.contains("DSK")) 
				dskCreate(selectOrderIndex);
			//�޸Ķ���
			else if (page.contains("ORDCHG")) 
				changeOrder(selectOrderIndex);
			//����
			else if (page.contains("FWK")) 
				FWK(selectOrderIndex);
			//������ѯ
			else if (page.contains("RESINV")) 
				ORDERSTOCK(selectOrderIndex);
		}
    };
     
    public void ORDERSTOCK(int index)
    {
    	//��Ʒ����
    	String productnumber = SearchResultView.this.table.get(index).getCellValue(5).value.toString();
    	//��װ��
    	String packagecount = SearchResultView.this.table.get(index).getCellValue(7).value.toString();
    	//�ȼ�
    	String level = SearchResultView.this.table.get(index).getCellValue(8).value.toString();
    	//������
    	String listnumber = SearchResultView.this.table.get(index).getCellValue(1).value.toString();
    	//�к�
    	String rownumber = SearchResultView.this.table.get(index).getCellValue(2).value.toString();
    	JSONArray paramsHeader = new JSONArray();
		paramsHeader.put(productnumber);
		paramsHeader.put(packagecount);
		paramsHeader.put(level);
		paramsHeader.put(listnumber);
		paramsHeader.put(rownumber);
		
		JSONArray params = PublicMethod.postParam(SearchResultView.this, "ORDERSTOCK", paramsHeader);
		String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
		if (result == null || result.isEmpty())
		{
        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "error while ORDERSTOCK :" + result);
			return;
		}
		
		
//    	//�������
//    	String Date = SearchResultView.this.table.get(index).getCellValue(16).value.toString();
//    	
//    	String formatJson = "{    \"condition\": [        {            \"type\": \"text\",            \"title\": \"������\",            \"mandatory\": true,            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"date\",            \"title\": \"�ƻ��������\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����˵��\",            \"mandatory\": true        },        {            \"type\": \"radio\",            \"title\": \"�Ƿ���AM��Ϣ\",            \"selectItem\": [                \"��\",                \"��\"            ]        },        {            \"type\": \"radio\",            \"title\": \"��Ա����\",            \"selectItem\": %s}    ],    \"type\": \"PICKDATECHG\"}";
//    	formatJson = String.format(formatJson, listnumber, Date,getEMPLIST());
    	
        Intent SearchResultViewIntent = new Intent(SearchResultView.this, SearchResultView.class);
        SearchResultViewIntent.putExtra(SearchResultView.this.getString(R.string.string_key_SearchCondition_result), result);
        SearchResultViewIntent.putExtra(SearchResultView.this.getString(R.string.string_key_SearchCondition_type), "changeRow");
        SearchResultView.this.startActivityForResult(SearchResultViewIntent, 0);
	    
	    
    }
    
    public void FWK(int index) {

    	//������
    	String listnumber = SearchResultView.this.table.get(index).getCellValue(1).value.toString();
    	//�ͻ�����
    	String name = SearchResultView.this.table.get(index).getCellValue(3).value.toString();//getIntent().getStringExtra("ORDERLIST_name");
    	//�ͻ��绰
    	String tel = SearchResultView.this.table.get(index).getCellValue(4).value.toString();//getIntent().getStringExtra("ORDERLIST_tel");
    	//�������
    	String Date = SearchResultView.this.table.get(index).getCellValue(16).value.toString();
    	//�ͻ���ַ
    	String address = SearchResultView.this.table.get(index).getCellValue(14).value.toString();//getIntent().getStringExtra("ORDERLIST_address");
    	//������ϵ��
    	String othername = SearchResultView.this.table.get(index).getCellValue(26).value.toString();//getIntent().getStringExtra("ORDERLIST_tel");
    	//������ϵ�绰
    	String othertel = SearchResultView.this.table.get(index).getCellValue(27).value.toString();//getIntent().getStringExtra("ORDERLIST_address");
    	
    	JSONArray paramsHeader = new JSONArray();
		paramsHeader.put(listnumber);
		JSONArray params = PublicMethod.postParam(SearchResultView.this, "FWKORDER", paramsHeader);
		String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
		if (result == null || result.isEmpty())
		{
        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "error while FWKORDER:" + result);
			return;
		}
		
		String formatJson = "{    \"condition\": [        {            \"type\": \"text\",            \"title\": \"������\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ͻ�����\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ͻ��绰\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"С������\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"date\",            \"title\": \"�ͻ�����\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ͻ���ַ\",            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ջ���\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ջ��绰\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����·��\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"radio\",            \"title\": \"���޵���\",            \"selectItem\": [                \"��\",                \"��\"            ],            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����Ҫ��\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�ӹ�˵��\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����˵��\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�����վݺ�\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"��������\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"�������\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"������\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"���ս��\",            \"defaultvalue\": \"%s\"        }    ],    \"type\": \"FWKCRT\"}";

    	try {
    		JSONArray jsonCheckResult = new JSONArray(result);
    		JSONArray jsonResult = jsonCheckResult.getJSONArray(1);
	        if (result.contains("ERROR"))
	        {
	        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), result);
	        	return;
	        }


//	    	formatJson = String.format(formatJson, listnumber, name, tel, Date, address, othername, othertel);
	    	formatJson = String.format(formatJson, 
	    			jsonResult.getString(0), 
	    			jsonResult.getString(1), 
	    			jsonResult.getString(2), 
	    			jsonResult.getString(3), 
	    			jsonResult.getString(4), 
	    			jsonResult.getString(5), 
	    			jsonResult.getString(6), 
	    			jsonResult.getString(7), 
	    			jsonResult.getString(8), 
	    			jsonResult.getString(9), 
	    			jsonResult.getString(10), 
	    			jsonResult.getString(11), 
	    			jsonResult.getString(12), 
	    			jsonResult.getString(13), 
	    			jsonResult.getString(14), 
	    			jsonResult.getString(15), 
	    			jsonResult.getString(16), 
	    			jsonResult.getString(17), 
	    			jsonResult.getString(18), 
	    			jsonResult.getString(19));
	    } catch (JSONException e) {  
	    	Log.e(FullscreenActivity.TAG, "error while login:" + e.getMessage());
        	return;
	    }
    	
    	
    	
        Intent ChangeSaveIntent = new Intent(SearchResultView.this, ChangeSave.class);
        ChangeSaveIntent.putExtra(SearchResultView.this.getString(R.string.string_key_SearchCondition_condition), formatJson.toString());
        SearchResultView.this.startActivityForResult(ChangeSaveIntent, 0);
	    
	}

	public void changeDate(int index)
    {
    	//������
    	String listnumber = SearchResultView.this.table.get(index).getCellValue(1).value.toString();
    	//�������
    	String Date = SearchResultView.this.table.get(index).getCellValue(16).value.toString();
    	
    	String formatJson = "{    \"condition\": [        {            \"type\": \"text\",            \"title\": \"������\",            \"mandatory\": true,            \"isOnlyRead\": true,            \"defaultvalue\": \"%s\"        },        {            \"type\": \"date\",            \"title\": \"�ƻ��������\",            \"defaultvalue\": \"%s\"        },        {            \"type\": \"text\",            \"title\": \"����˵��\",            \"mandatory\": true        },        {            \"type\": \"radio\",            \"title\": \"�Ƿ���AM��Ϣ\",            \"selectItem\": [                \"��\",                \"��\"            ]        },        {            \"type\": \"radio\",            \"title\": \"��Ա����\",            \"selectItem\": %s}    ],    \"type\": \"DATECHG\"}";
    	formatJson = String.format(formatJson, listnumber, Date,getEMPLIST());
    	
        Intent ChangeSaveIntent = new Intent(SearchResultView.this, ChangeSave.class);
        ChangeSaveIntent.putExtra(SearchResultView.this.getString(R.string.string_key_SearchCondition_condition), formatJson.toString());
        SearchResultView.this.startActivityForResult(ChangeSaveIntent, 0);
	    
	    
    }
    
    public void dskCreate(int index)
    {
    	//�ͻ�����
    	String name = SearchResultView.this.table.get(index).getCellValue(3).value.toString();//getIntent().getStringExtra("ORDERLIST_name");
    	//�ͻ��绰
    	String tel = SearchResultView.this.table.get(index).getCellValue(4).value.toString();//getIntent().getStringExtra("ORDERLIST_tel");
    	//�ͻ���ַ
    	String address = SearchResultView.this.table.get(index).getCellValue(14).value.toString();//getIntent().getStringExtra("ORDERLIST_address");
    	//������
    	String listnumber = SearchResultView.this.table.get(index).getCellValue(1).value.toString();
    	//ʣ�����
    	String amount = SearchResultView.this.table.get(index).getCellValue(28).value.toString();
    	//��ע
    	String note = SearchResultView.this.table.get(index).getCellValue(13).value.toString();
    	
    	String formatJson = "{   \"condition\": [       {           \"type\": \"text\",           \"title\": \"������\",           \"mandatory\": true,           \"isOnlyRead\": true,           \"defaultvalue\": \"%s\"       },       {           \"type\": \"text\",           \"title\": \"�ͻ�����\",           \"isOnlyRead\": true,           \"defaultvalue\": \"%s\",           \"isNotSubmit\": true       },       {           \"type\": \"text\",           \"title\": \"�ͻ��绰\",           \"isOnlyRead\": true,           \"defaultvalue\": \"%s\",           \"isNotSubmit\": true       },       {           \"type\": \"text\",           \"title\": \"�ͻ���ַ\",           \"isOnlyRead\": true,           \"defaultvalue\": \"%s\",           \"isNotSubmit\": true       },       {           \"type\": \"text\",           \"title\": \"���ս��\",           \"mandatory\": true,           \"defaultvalue\": \"%s\"       },       {           \"type\": \"text\",           \"title\": \"��ע\",         \"defaultvalue\": \"%s\"       }   ],   \"type\": \"DSKCRT\"}";
    	formatJson = String.format(formatJson, listnumber,name,tel,address, amount, note);

        Intent ChangeSaveIntent = new Intent(SearchResultView.this, ChangeSave.class);
        ChangeSaveIntent.putExtra(SearchResultView.this.getString(R.string.string_key_SearchCondition_condition), formatJson.toString());
        SearchResultView.this.startActivityForResult(ChangeSaveIntent, 0);
	    
    }
    
    public void changeOrder(int index)
    {
    	String listStatus = SearchResultView.this.table.get(index).getCellValue(0).value.toString();
    	if (!listStatus.contains("����") && !listStatus.contains("����") && !listStatus.contains("������"))
    	{
    		Toast.makeText(SearchResultView.this, "�����޸ĸö���", Toast.LENGTH_SHORT).show();
    		return;
    	}
    	String listnumber = SearchResultView.this.table.get(index).getCellValue(1).value.toString();
	    

		JSONArray paramsHeader = new JSONArray();
		paramsHeader.put(listnumber);
		JSONArray params = PublicMethod.postParam(SearchResultView.this, "ORDERQUERY", paramsHeader);

		String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
		if (result == null || result.isEmpty())
			return ;

    	try {
    		JSONArray jsonCheckResult = new JSONArray(result);
	        if (jsonCheckResult.length() < 2 || jsonCheckResult.getString(0).contains("ERROR"))
	        {
	        	if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).length() >=1)
	        		PublicMethod.displayToast(SearchResultView.this, jsonCheckResult.getJSONArray(1).getString(0));
	        	return ;
	        }
	        else
	        {
	        	Intent SearchViewIntent = new Intent(SearchResultView.this, ChangeOrderCustomerInfo.class);
	        	SearchViewIntent.putExtra(SearchResultView.this.getString(R.string.string_key_listcontent), result);
	        	SearchViewIntent.putExtra(SearchResultView.this.getString(R.string.string_key_orderCode), listnumber);
	        	SearchResultView.this.startActivityForResult(SearchViewIntent, 0);
	        }
	    } catch (JSONException e) {  
	    	Log.e(FullscreenActivity.DEBUG_TAG, "error while buttonSearchBook OnClickListener:" + e.getMessage());
	    	PublicMethod.displayToast(SearchResultView.this, result);
	    }
    }
    
    LinearLayout alert_dialog_linearContent;
    int tableRowViewSelectRow;
    
    class changeRowItemClickEvent implements AdapterView.OnItemClickListener {  
        @Override  
        public void onItemClick(AdapterView<?> arg0, View tableRowView, int index,  
                long arg3) {  
        	LayoutInflater factory = LayoutInflater.from(SearchResultView.this);  
        	//����Զ���Ի���  
        	View view = factory.inflate(R.layout.alert_dialog_change_row, null);
        	alert_dialog_linearContent = (LinearLayout)view.findViewById(R.id.linearContent);
        	tableRowViewSelectRow = index;
        	ConditionText conditionText;
        	for (int i = 0; i<titles.length; i++)
        	{
        		conditionText = new ConditionText(SearchResultView.this);
        		if (i == titles.length -1)
        			conditionText.setEnable(true);
        		else 
        			conditionText.setEnable(false);
        		conditionText.setTitle((String)titles[i].value);
        		conditionText.setText(SearchResultView.this.table.get(index).getCellValue(i).value.toString());
        		alert_dialog_linearContent.addView(conditionText);
        	}
        	ConditionDate conditionDate = new ConditionDate(SearchResultView.this);
        	conditionDate.setTitle("Ԥ������");
        	
        	String listContent = getIntent().getStringExtra(getString(R.string.string_key_SearchCondition_result));
    	    if (listContent == null)
    	    	return ;
    	    
    	    JSONObject listJSON = null;
    	    try {
    	    	listJSON = new JSONObject(listContent);
        	
    	    	//body
    	    	JSONArray bodyJson = listJSON.getJSONArray(strJsonKey_body);
    	    	JSONArray bodyRow = bodyJson.getJSONArray(index);
    	    	conditionDate.setDate(bodyRow.getString(bodyRow.length()-1));
	        } catch (JSONException e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	        }
    		alert_dialog_linearContent.addView(conditionDate);
        	
        	AlertDialog dialog = new AlertDialog.Builder(SearchResultView.this)  
        	     .setIcon(android.R.drawable.btn_star)  
        	     .setTitle("Ԥ��Ƭ��")  
        	       .setView(view)  
        	       .setPositiveButton("����", onsaveclick)  
        	       .setNegativeButton("ȡ��", oncancelclick).create();  
        	dialog.show();
        	
        }  
        
    }
    DialogInterface.OnClickListener onsaveclick = new DialogInterface.OnClickListener()
    {

		@Override
		public void onClick(DialogInterface dialog, int which) {
			// TODO Auto-generated method stub
			ConditionInterface conditionInterface;
//			for (int i=0; i<alert_dialog_linearContent.getChildCount(); i++)
//			{
				conditionInterface = (ConditionInterface) alert_dialog_linearContent.getChildAt(alert_dialog_linearContent.getChildCount()-2);
				SearchResultView.this.table.get(tableRowViewSelectRow).getCellValue(titles.length-1).value = conditionInterface.getText();
				
//			}
				JSONArray paramsHeader = new JSONArray();
				JSONArray params = PublicMethod.postParam(SearchResultView.this, "ORDERRES", paramsHeader);
				
//				for (int i = 0; i < SearchResultView.this.table.size(); i++)
//				{
					TableRow tableRow = SearchResultView.this.table.get(tableRowViewSelectRow);
					JSONArray paramsRow = new JSONArray();
					for (int j=0;j<tableRow.getSize();j++)
						paramsRow.put(tableRow.getCellValue(j).value);
					
					//Ԥ������
					conditionInterface = (ConditionInterface) alert_dialog_linearContent.getChildAt(alert_dialog_linearContent.getChildCount()-1);
					paramsRow.put(conditionInterface.getText());
					params.put(paramsRow);
//				}
				
				//Ԥ��Ƭ��
				//���� Ԥ��Ƭ�� �� ���� ���� ������ѯ �е� ʣ��Ƭ��
				
				//����Ҫ��һ������ѡ��
				
				String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
				if (result == null || result.isEmpty())
				{
		        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "error while ORDERRES :" + result);
					return;
				}

				if (result.contains("ERROR"))
		        {
		        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), result);
		        	return;
		        }
		        	
		        JSONArray jsonCheckResult;
					
		        try {
		        	jsonCheckResult = new JSONArray(result);
		        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "�޸����," + jsonCheckResult.getJSONArray(1).getString(0));
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				    PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "�޸����");
				}

		        SearchResultView.this.table.remove(tableRowViewSelectRow);

				TableAdapter tableAdapter = new TableAdapter(SearchResultView.this, table, false, false);
		        lv.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
		        lv.setAdapter(tableAdapter); 
		        return;
		}
    	
    };
    DialogInterface.OnClickListener oncancelclick = new DialogInterface.OnClickListener()
    {

		@Override
		public void onClick(DialogInterface dialog, int which) {
			// TODO Auto-generated method stub
			
		}
    	
    };
    
//    OnClickListener savechangeRow = new OnClickListener()
//    {
//
//		@Override
//		public void onClick(View v) {
//			// TODO Auto-generated method stub
//			JSONArray paramsHeader = new JSONArray();
//			JSONArray params = PublicMethod.postParam(SearchResultView.this, "ORDERRES", paramsHeader);
//			
//			for (int i = 0; i < SearchResultView.this.table.size(); i++)
//			{
//				TableRow tableRow = SearchResultView.this.table.get(i);
//				JSONArray paramsRow = new JSONArray();
//				for (int j=0;j<tableRow.getSize();j++)
//					paramsRow.put(tableRow.getCellValue(j).value);
//				
//				params.put(paramsRow);
//			}
//			
//			//Ԥ��Ƭ��
//			//���� Ԥ��Ƭ�� �� ���� ���� ������ѯ �е� ʣ��Ƭ��
//			
//			//����Ҫ��һ������ѡ��
//			
//			String result = PublicMethod.httpPost(FullscreenActivity.mAddress, params.toString());
//			if (result == null || result.isEmpty())
//			{
//	        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "error while ORDERRES :" + result);
//				return;
//			}
//
//			if (result.contains("ERROR"))
//	        {
//	        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), result);
//	        	return;
//	        }
//	        	
//	        JSONArray jsonCheckResult;
//				
//	        try {
//	        	jsonCheckResult = new JSONArray(result);
//	        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "�޸����," + jsonCheckResult.getJSONArray(1).getString(0));
//			} catch (JSONException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			    PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "�޸����");
//			}
//	        SearchResultView.this.finish();
//	        return;
//		}
//    	
//    };
    
    public String getEMPLIST()
    {
    	JSONArray paramsHeaderEMPLIST = new JSONArray();
		
		JSONArray paramsEMPLIST = PublicMethod.postParam(SearchResultView.this, "EMPLIST", paramsHeaderEMPLIST);
		String resultEMPLIST = PublicMethod.httpPost(FullscreenActivity.mAddress, paramsEMPLIST.toString());
		if (resultEMPLIST == null || resultEMPLIST.isEmpty())
		{
        	PublicMethod.displayToast(SearchResultView.this.getApplicationContext(), "error while EMPLIST :" + resultEMPLIST);
			return null;
		}
		JSONArray returnJSONArray = new JSONArray();
		JSONArray resultJSONArray;
		try {
			resultJSONArray = new JSONArray(resultEMPLIST);
			for(int index=2;index<resultJSONArray.length();index++)
			{
				JSONArray item = resultJSONArray.getJSONArray(index);
				returnJSONArray.put(item.getString(0) + " " + item.getString(1));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return returnJSONArray.toString();
    }
    
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String returnResult = bundle.getString("result");
			Intent resultIntent = new Intent();
			Bundle newbundle = new Bundle();
			newbundle.putString(getString(R.string.string_key_orderCode), returnResult);
			newbundle.putString(getString(R.string.string_key_searchType), "ORDERLIST");
			resultIntent.putExtras(newbundle);
			SearchResultView.this.setResult(RESULT_OK, resultIntent);
			SearchResultView.this.finish();
		}
		else if(resultCode == FunctionList.MenuResult)
		{
			SearchResultView.this.setResult(FunctionList.MenuResult);
			SearchResultView.this.finish();
		}
	}
}
