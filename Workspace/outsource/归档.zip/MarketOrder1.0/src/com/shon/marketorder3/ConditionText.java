package com.shon.marketorder3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.shon.marketorder3.mk.R;

public class ConditionText extends LinearLayout implements ConditionInterface {
	TextView mTextViewConditionTextTitle;
	EditText mEditTextConditionTextContent;
	boolean mIsNotSubmit = false;

	public boolean isMandatory = false;
//	public boolean isOnlyRead = false;
	
	public ConditionText(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
        inflate(context, R.layout.conditiontext, this);
        mTextViewConditionTextTitle = (TextView)this.findViewById(R.id.TextViewConditionTextTitle);
        mEditTextConditionTextContent = (EditText)this.findViewById(R.id.EditTextConditionTextContent);
//        if (isOnlyRead)
//        	mEditTextConditionTextContent.setEnabled(false);
	}

	public void setTitle(String str)
	{
		mTextViewConditionTextTitle.setText(str);
	}
	
	public void setText(String str)
	{
		mEditTextConditionTextContent.setText(str);
	}

	public String getTitle()
	{
		return mTextViewConditionTextTitle.getText().toString();
	}

	public String getText()
	{
		return mEditTextConditionTextContent.getText().toString();
	}
	
	public void setEnable(boolean isEnable)
	{
		mEditTextConditionTextContent.setEnabled(isEnable);
//		if (!isEnable)
//			mEditTextConditionTextContent.setl
	}

	@SuppressLint("NewApi")
	@Override
	public boolean checkMandatory() {
		if (isMandatory && getText().isEmpty())
		{
			Toast.makeText(ConditionText.this.getContext(), mTextViewConditionTextTitle.getText() + "����Ϊ��", Toast.LENGTH_LONG).show();
			return false;
		}
		else
			return true;
	}

	@Override
	public void setIsNotSubmit(boolean isNotSubmit){
		mIsNotSubmit = isNotSubmit;
	}
	@Override
	public boolean getIsNotSubmit(){
		// TODO Auto-generated method stub
		return mIsNotSubmit;
	}
}
