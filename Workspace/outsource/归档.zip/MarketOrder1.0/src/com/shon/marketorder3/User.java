package com.shon.marketorder3;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.shon.marketorder3.PublicMethod;

public class User {
	public static final int FALSE 		= 0;	
	public static final int TRUE 		= 1;
	
	public static final String randNumber = "32908457";
	
    public Application application = null;   
    public String name = "";  
    public String phone = "";  
    public String MD5Password = "";
    public String nineListJson = "";
    public String sessionKey = "";
    public int isLogin = User.FALSE;  
    

    public String author = null;
//    public boolean author_INVOWNER = false;//ANDR.INVOWNER	BASE  ���п���ѯ
//    public boolean author_INVPLANT = false;//ANDR.INVPLANT	BASE  ��������ѯ
//    public boolean author_ORDCRT = false;//ANDR.ORDCRT	BASE  ��������
//    public boolean author_ORDISSUE = false;//ANDR.ORDISSUE	BASE  ���������ѯ
//    public boolean author_ORDLIST = false;//ANDR.ORDLIST	BASE  ������ѯ
//    public boolean author_ORDPAY = false;//ANDR.ORDPAY	BASE  ���������ѯ
//    public boolean author_PICKLIST = false;//ANDR.PICKLIST	BASE  �ᵥ��ѯ
//    public boolean author_ORDTRACE = false;//ANDR.ORDTRACE	BASE  ���۶���ִ�и��ٱ���ѯ
//    public boolean author_REBLIST = false;//ANDR.REBLIST	BASE  ��������ѯ
//    public boolean author_PLANLIST = false;//ANDR.PLANLIST	BASE  �����ƻ���ѯ
    
    public User(Application app)
    {
    	application = app;
    }
    
    public void copy(User user)
    {
        name = user.name;  
        phone = user.phone;  
        MD5Password = user.MD5Password;
        nineListJson = user.nineListJson;
        sessionKey = user.sessionKey;
        author = user.author;
//        author_INVOWNER = user.author_INVOWNER;
//        author_INVPLANT = user.author_INVPLANT;
//        author_ORDCRT = user.author_ORDCRT;
//        author_ORDISSUE = user.author_ORDISSUE;
//        author_ORDLIST = user.author_ORDLIST;
//        author_ORDPAY = user.author_ORDPAY;
//        author_PICKLIST = user.author_PICKLIST;
//        author_ORDTRACE = user.author_ORDTRACE;
//        author_REBLIST = user.author_REBLIST;
//        author_PLANLIST = user.author_PLANLIST;
        isLogin = user.isLogin;         
    }
    
    public void logout()
    {
//        author_INVOWNER = false;//ANDR.INVOWNER	BASE  ���п���ѯ
//        author_INVPLANT = false;//ANDR.INVPLANT	BASE  ��������ѯ
//        author_ORDCRT = false;//ANDR.ORDCRT	BASE  ��������/�鿴���ﳵ
//        author_ORDISSUE = false;//ANDR.ORDISSUE	BASE  ���������ѯ
//        author_ORDLIST = false;//ANDR.ORDLIST	BASE  ������ѯ
//        author_ORDPAY = false;//ANDR.ORDPAY	BASE  ���������ѯ
//        author_PICKLIST = false;//ANDR.PICKLIST	BASE  �ᵥ��ѯ
//        author_ORDTRACE = false;//ANDR.ORDTRACE	BASE  ���۶���ִ�и��ٱ���ѯ
//        author_REBLIST = false;//ANDR.REBLIST	BASE  ��������ѯ
//        author_PLANLIST = false;//ANDR.PLANLIST	BASE  �����ƻ���ѯ

    	author = null;
    	isLogin = User.FALSE;	
    }
    
    @SuppressLint("NewApi") public boolean login(Context context) {    
        String address = FullscreenActivity.mAddress;
                
        logout();
        
        JSONArray paramsHeader = new JSONArray();
        paramsHeader.put(name);
        paramsHeader.put(MD5Password);
		JSONArray params = PublicMethod.postParam(application, "LOGIN", paramsHeader);
		String result = PublicMethod.httpPost(address, params.toString());//"[\,\"\",[\"\",\"95322\",\"OWNER\",\"AA\"]]");
		if (result == null || result.isEmpty())
			return false;

    	try {
    		JSONObject jsonCheckResult = new JSONObject(result);
	        if (jsonCheckResult.has("ERROR"))
	        {
	        	PublicMethod.displayToast(context, jsonCheckResult.getString("ERROR"));
	        	return false;
	        }

			author = result;
			
	    } catch (JSONException e) {  
	    	Log.e(FullscreenActivity.DEBUG_TAG, "error while login:" + e.getMessage());
        	return false;
	    }

//    	try {
//    		JSONArray jsonCheckResult = new JSONArray(result);
//	        if (jsonCheckResult.length() < 2 || jsonCheckResult.getString(0).contains("ERROR"))
//	        {
//	        	if (jsonCheckResult.length() >= 2 && jsonCheckResult.getJSONArray(1) != null && jsonCheckResult.getJSONArray(1).length() >=1)
//	        		PublicMethod.displayToast(context, jsonCheckResult.getJSONArray(1).getString(0));
//	        	else if (jsonCheckResult.length() >= 2)
//	        		PublicMethod.displayToast(context, jsonCheckResult.getString(1));
//	        	return false;
//	        }
//	        
//	        for (int i=2; i<jsonCheckResult.length(); i++)
//	        {
//	        	JSONArray item = jsonCheckResult.getJSONArray(i);
//	        	if (item != null && item.length()>=1)
//	        	{
//	        		if (item.getString(0).contains("INVOWNER"))
//	        			author_INVOWNER = true; 
//	        		else if (item.getString(0).contains("INVPLANT"))
//	        			author_INVPLANT = true; 
//	        		else if (item.getString(0).contains("ORDCRT"))
//	        			author_ORDCRT = true; 
//	        		else if (item.getString(0).contains("ORDISSUE"))
//	        			author_ORDISSUE = true; 
//	        		else if (item.getString(0).contains("ORDLIST"))
//	        			author_ORDLIST = true; 
//	        		else if (item.getString(0).contains("ORDPAY"))
//	        			author_ORDPAY = true; 
//	        		else if (item.getString(0).contains("PICKLIST"))
//	        			author_PICKLIST = true; 
//	        		else if (item.getString(0).contains("ORDTRACE"))
//	        			author_ORDTRACE = true; 
//	        		else if (item.getString(0).contains("REBLIST"))
//	        			author_REBLIST = true; 
//	        		else if (item.getString(0).contains("PLANLIST"))
//	        			author_PLANLIST = true;
//	        	}
//	        }
//	        
//	    } catch (JSONException e) {  
//	    	Log.e(FullscreenActivity.DEBUG_TAG, "error while login:" + e.getMessage());
//        	return false;
//	    }

//        if (loginReturn.contentEquals(application.getString(R.string.string_en_error)))
//        {
//        	author = USER_AUTHOR_FREE;
//        	isLogin = User.FALSE;
//        	return false;
//        }
        
        isLogin = User.TRUE;
        return true;
    }   
    
    public String getUserArg()
    {
//    	[��½��Ϣ]=["�ʺ�","�����","����YYYYMMDD","ʱ��HH24MMSS","MD5��"] 
//    	MD5����MD5("�ʺ�","�����","����YYYYMMDD","ʱ��HH24MMSS","�û������MD5") 
//
//		JSONArray ret = new JSONArray();
//		ret.put(this.name);
//		ret.put(rand());
//		ret.put(System.currentTimeMillis()-timeOffset);
//		ret.put(this.MD5Password);
//    	if (isLogin != User.TRUE)
//    		return "";
		
		String loginStr = getTimeArg() + "," + randNumber + "," + this.name;
		String md5Str = loginStr + "," + this.MD5Password; 
		
		return PublicMethod.md5(md5Str) + "," + loginStr;
//		if (author == User.USER_AUTHOR_FREE)
//			return "t=1&uid=" + deviceId + "&utype=" + author;
//		else
//			return "t=2&uid=" + name + "&utype=" + author + "&sessionKey=" + sessionKey;
    }
    
    @SuppressLint("NewApi") public String getTimeArg()
    {
    	String result = PublicMethod.httpPost(FullscreenActivity.mAddress, "[\"\",\"GETTIME\",[\"\"]]");

		Date curDate  = new Date(System.currentTimeMillis());//��ȡ��ǰʱ�� 
		SimpleDateFormat formatterDate = new SimpleDateFormat ("yyyyMMdd,HHmmss");  
//		SimpleDateFormat formatterTime = new SimpleDateFormat ("");     
		String strDate = formatterDate.format(curDate);         
//		String strTime = formatterTime.format(curDate);  
		if (result != null && !result.isEmpty())
		{
			try
			{
				JSONArray serverTimeRet = new JSONArray(result);
				if (serverTimeRet.length() >= 2 && serverTimeRet.getString(0).equals("GETTIME"))
				{
					JSONArray serverTime = serverTimeRet.getJSONArray(1);
					if (serverTime.length() >= 2)
						strDate = serverTime.getString(0) + "," + serverTime.getString(1);
					else
				    	Log.e(FullscreenActivity.DEBUG_TAG, "error while gettime:");
				}
				else
			    	Log.e(FullscreenActivity.DEBUG_TAG, "error while gettime:");
			}
			catch(JSONException	e)
			{
		    	Log.e(FullscreenActivity.DEBUG_TAG, "error while gettime:" + e.getMessage());
			}
		}
		return strDate;
    }

}
