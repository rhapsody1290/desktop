/** Automatically generated file. DO NOT MODIFY */
package com.aibeile_diaper.mm.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}