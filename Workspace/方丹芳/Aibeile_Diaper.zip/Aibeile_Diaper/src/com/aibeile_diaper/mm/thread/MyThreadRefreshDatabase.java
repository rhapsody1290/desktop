package com.aibeile_diaper.mm.thread;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import android.util.Log;

public class MyThreadRefreshDatabase implements Runnable
{
	public boolean isflag;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Log.v("test","thread start");
//		isflag=refreshDataBase();
	//	getNewsList(Url.HOTPAGEURL0,0);
		
	
	}
	
}
