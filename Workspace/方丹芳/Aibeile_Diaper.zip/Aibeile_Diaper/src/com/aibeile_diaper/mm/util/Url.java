package com.aibeile_diaper.mm.util;


public class Url {
	public static String BASEURL="http://10.105.54.72:9001/";
	public static String DETECTURL = Url.BASEURL + "test/detect?";

}
