package com.aibeile_diaper.mm.util;

import java.io.Serializable;

public	class rgb implements Serializable {  
		public int key = 0; 
	    public int r = 0;    
	    public int g = 0;  
	    public int b = 0;  
	} 