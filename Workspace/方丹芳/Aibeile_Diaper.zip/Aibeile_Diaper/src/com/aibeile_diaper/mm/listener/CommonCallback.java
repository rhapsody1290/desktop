package com.aibeile_diaper.mm.listener;

public interface CommonCallback {

	public void callback(Object obj);
}
