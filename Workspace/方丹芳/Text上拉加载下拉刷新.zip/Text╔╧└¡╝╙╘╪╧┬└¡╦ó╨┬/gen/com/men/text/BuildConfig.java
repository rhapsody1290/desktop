/** Automatically generated file. DO NOT MODIFY */
package com.men.text;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}